import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { runInNewContext } from "node:vm";

const page = readFileSync(resolve(import.meta.dirname, "../dist/index.html"), "utf8");
function sourceBetween(startName, nextName) {
  const start = page.indexOf(`function ${startName}(`);
  const end = page.indexOf(`function ${nextName}(`, start);
  assert.ok(start >= 0 && end > start, `${startName} must be present`);
  return page.slice(start, end);
}

const context = {
  copy: (value, fallback) => JSON.parse(JSON.stringify(value === undefined ? fallback : value)),
  resetStamp: (value) => Date.parse(value || "") || 0,
  mergeDeletedQuestions: (local, remote) => ({ ...local, ...remote }),
  mergeQuestionRecords: () => [],
  mergeProgress: () => ({}),
  pruneProgress: () => ({}),
  mergeRecords: (local, remote) => [...new Map([...(local || []), ...(remote || [])].map((item) => [String(item.id), item])).values()],
  mergeActivity: () => ({}),
  mergeDailyGoals: () => ({}),
  mergeAppearance: () => ({}),
  pruneRecords: () => [],
};
runInNewContext(
  sourceBetween("mergeDeletedNotes", "withoutDeletedNotes") +
  sourceBetween("withoutDeletedNotes", "mergeProgress") +
  sourceBetween("mergeSnapshots", "applySnapshot") +
  "globalThis.noteDeletion = { mergeDeletedNotes, withoutDeletedNotes, mergeSnapshots };",
  context,
);

const { mergeDeletedNotes, withoutDeletedNotes, mergeSnapshots } = context.noteDeletion;
const deletedAt = "2026-09-30T00:00:00.000Z";
const base = { questions: [], progress: {}, notes: [], tasks: [], testRecords: [] };
const localDelete = mergeSnapshots(
  { ...base, deletedNotes: { "note-1": deletedAt } },
  { ...base, notes: [{ id: "note-1" }, { id: "note-2" }] },
);
assert.deepEqual(Array.from(localDelete.notes, (note) => note.id), ["note-2"]);
assert.equal(localDelete.deletedNotes["note-1"], deletedAt);

const remoteDelete = mergeSnapshots(
  { ...base, notes: [{ id: 9 }, { id: 10 }] },
  { ...base, deletedNotes: { "9": deletedAt } },
);
assert.deepEqual(Array.from(remoteDelete.notes, (note) => note.id), [10]);

const inFlight = mergeSnapshots({ ...base, notes: [{ id: "late" }] }, base);
const latestDeleted = mergeDeletedNotes(inFlight.deletedNotes, { late: deletedAt });
assert.equal(withoutDeletedNotes(inFlight.notes, latestDeleted).length, 0);
console.log("PASS note deletion: local, remote, and in-flight sync cannot restore a deleted note");
