import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";
import { resolve } from "node:path";
import { Script } from "node:vm";
import { execFileSync } from "node:child_process";

const workerModule = await import(pathToFileURL(resolve("dist/server/index.js")).href + "?check=" + Date.now());
const worker = workerModule.default;
assert.equal(typeof worker?.fetch, "function", "Worker must export fetch(request, env, ctx)");

function createEnvironment() {
  const profiles = new Map();
  const blobs = new Map();
  return {
    DB: {
      prepare(statement) {
        return {
          bind(...values) {
            return {
              async first() {
                return /SELECT snapshot_key/.test(statement) ? profiles.get(values[0]) || null : null;
              },
              async run() {
                if (/INSERT INTO memory_profiles/.test(statement)) {
                  const previous = profiles.get(values[0]);
                  profiles.set(values[0], {
                    user_id: values[0],
                    snapshot_key: values[1],
                    updated_at: values[2],
                    revision: (previous?.revision || 0) + 1,
                  });
                }
                return { success: true };
              },
            };
          },
        };
      },
    },
    BUCKET: {
      async put(key, body, options = {}) {
        const bytes = await new Response(body).arrayBuffer();
        blobs.set(key, { bytes, ...options });
      },
      async get(key) {
        const entry = blobs.get(key);
        if (!entry) return null;
        return {
          body: new Blob([entry.bytes]).stream(),
          text: async () => new TextDecoder().decode(entry.bytes),
          httpMetadata: entry.httpMetadata || {},
          customMetadata: entry.customMetadata || {},
        };
      },
      async head(key) {
        const entry = blobs.get(key);
        return entry ? { httpMetadata: entry.httpMetadata || {}, customMetadata: entry.customMetadata || {} } : null;
      },
    },
  };
}

const env = createEnvironment();
env.ADMIN_OWNER_EMAIL = "owner@example.test";
const userHeaders = { "oai-authenticated-user-id": "test-user", "oai-authenticated-user-email": "reader@example.test" };
let response = await worker.fetch(new Request("https://example.test/"), env, {});
assert.equal(response.status, 200);
const homeHtml = await response.text();
assert.match(homeHtml, /Physio Atlas/);
assert.match(homeHtml, /rel="manifest" href="\/site\.webmanifest"/);
assert.match(homeHtml, /rel="apple-touch-icon" sizes="180x180"/);

response = await worker.fetch(new Request("https://example.test/site.webmanifest"), env, {});
assert.equal(response.status, 200);
assert.match(response.headers.get("content-type"), /application\/manifest\+json/);
const manifest = await response.json();
assert.equal(manifest.name, "Physio Atlas｜物理治療學習平台");
assert.equal(manifest.icons.length, 2);
for (const size of [64, 180, 192, 512]) {
  response = await worker.fetch(new Request(`https://example.test/icons/app-icon-${size}.png`), env, {});
  assert.equal(response.status, 200, `The ${size}px icon must be served`);
  assert.equal(response.headers.get("content-type"), "image/png");
  const bytes = Buffer.from(await response.arrayBuffer());
  assert.deepEqual([...bytes.subarray(0, 8)], [137, 80, 78, 71, 13, 10, 26, 10]);
  assert.equal(bytes.readUInt32BE(16), size);
  assert.equal(bytes.readUInt32BE(20), size);
}

response = await worker.fetch(new Request("https://example.test/api/memory"), env, {});
assert.equal(response.status, 401);

response = await worker.fetch(new Request("https://example.test/admin-client.js"), env, {});
assert.equal(response.status, 200);
assert.match(await response.text(), /題庫後台/);

response = await worker.fetch(new Request("https://example.test/api/memory", { headers: userHeaders }), env, {});
assert.equal(response.status, 200);
assert.equal((await response.json()).snapshot, null);

const snapshot = { version: 1, savedAt: "2026-09-28T00:00:00.000Z", questions: [{ id: 1 }], progress: {}, notes: [] };
response = await worker.fetch(new Request("https://example.test/api/memory", {
  method: "PUT",
  headers: { ...userHeaders, "content-type": "application/json" },
  body: JSON.stringify({ snapshot }),
}), env, {});
assert.equal(response.status, 200);

response = await worker.fetch(new Request("https://example.test/api/memory", { headers: userHeaders }), env, {});
assert.deepEqual((await response.json()).snapshot, snapshot);

response = await worker.fetch(new Request("https://example.test/api/memory/assets/asset-1", {
  method: "PUT",
  headers: { ...userHeaders, "content-type": "image/png", "x-memory-asset-name": encodeURIComponent("題圖測試.png") },
  body: new Blob(["image-bytes"], { type: "image/png" }),
}), env, {});
assert.equal(response.status, 201);
response = await worker.fetch(new Request("https://example.test/api/memory/assets/asset-1", { headers: userHeaders }), env, {});
assert.equal(response.status, 200);
assert.equal(decodeURIComponent(response.headers.get("x-memory-asset-name")), "題圖測試.png");
assert.equal(await response.text(), "image-bytes");

// Sites forwards a Site-scoped visitor ID, not the owner's project account ID.
const adminHeaders = { "oai-authenticated-user-id": "site-scoped-owner-id", "oai-authenticated-user-email": "OWNER@EXAMPLE.TEST" };
const wrongAccountHeaders = { "oai-authenticated-user-id": "project-owner-account-id", "oai-authenticated-user-email": "reader@example.test" };
const publicQuestion = { id: 101, questionNumber: 1, q: "測試公開題目？", answers: ["甲", "乙", "丙", "丁"], correct: 0 };
response = await worker.fetch(new Request("https://example.test/api/memory", {
  method: "PUT", headers: { ...adminHeaders, "content-type": "application/json" },
  body: JSON.stringify({ snapshot: { questions: [publicQuestion], notes: [] } }),
}), env, {});
assert.equal(response.status, 200);
response = await worker.fetch(new Request("https://example.test/api/admin/me"), env, {});
assert.deepEqual(await response.json(), { authenticated: false, isAdmin: false });
response = await worker.fetch(new Request("https://example.test/api/admin/me", { headers: adminHeaders }), env, {});
assert.deepEqual(await response.json(), { authenticated: true, isAdmin: true });
response = await worker.fetch(new Request("https://example.test/api/admin/me", { headers: wrongAccountHeaders }), env, {});
assert.deepEqual(await response.json(), { authenticated: true, isAdmin: false }, "a project account ID alone must not grant admin rights");
response = await worker.fetch(new Request("https://example.test/api/admin/me", { headers: { "oai-authenticated-user-email": "owner@example.test" } }), env, {});
assert.deepEqual(await response.json(), { authenticated: false, isAdmin: false }, "an email without a signed-in visitor ID must not grant admin rights");
response = await worker.fetch(new Request("https://example.test/api/admin/me", { headers: adminHeaders }), createEnvironment(), {});
assert.deepEqual(await response.json(), { authenticated: true, isAdmin: false }, "missing owner configuration must fail closed");
response = await worker.fetch(new Request("https://example.test/api/admin/legacy-bank", { headers: userHeaders }), env, {});
assert.equal(response.status, 403, "a reader cannot inspect the owner's old bank");
response = await worker.fetch(new Request("https://example.test/api/admin/legacy-bank", { headers: adminHeaders }), env, {});
assert.deepEqual((await response.json()).questions, [publicQuestion]);
response = await worker.fetch(new Request("https://example.test/api/bank"), env, {});
assert.equal((await response.json()).snapshot, null);
response = await worker.fetch(new Request("https://example.test/api/bank", {
  method: "PUT", headers: { ...userHeaders, "content-type": "application/json" },
  body: JSON.stringify({ questions: [publicQuestion], baseRevision: null }),
}), env, {});
assert.equal(response.status, 403, "a reader cannot publish questions");
response = await worker.fetch(new Request("https://example.test/api/bank", {
  method: "PUT", headers: { ...wrongAccountHeaders, "content-type": "application/json" },
  body: JSON.stringify({ questions: [publicQuestion], baseRevision: null }),
}), env, {});
assert.equal(response.status, 403, "a signed-in user with the wrong email cannot publish questions");
response = await worker.fetch(new Request("https://example.test/api/bank", {
  method: "PUT", headers: { ...adminHeaders, "content-type": "application/json" },
  body: JSON.stringify({ questions: [publicQuestion], baseRevision: null }),
}), env, {});
assert.equal(response.status, 200, "the owner can publish questions");
const firstPublication = await response.json();
assert.equal(firstPublication.questionCount, 1);
assert.ok(firstPublication.revision);
response = await worker.fetch(new Request("https://example.test/api/bank"), env, {});
assert.deepEqual((await response.json()).snapshot.questions, [publicQuestion], "the published bank is public and canonical");
response = await worker.fetch(new Request("https://example.test/api/bank", {
  method: "PUT", headers: { ...adminHeaders, "content-type": "application/json" },
  body: JSON.stringify({ questions: [publicQuestion], baseRevision: null }),
}), env, {});
assert.equal(response.status, 409, "an older editor cannot overwrite a newer publication");
response = await worker.fetch(new Request("https://example.test/api/bank/assets/image-1", {
  method: "PUT", headers: { ...userHeaders, "content-type": "image/png" }, body: new Blob(["blocked"]),
}), env, {});
assert.equal(response.status, 403, "a reader cannot publish images");
response = await worker.fetch(new Request("https://example.test/api/bank/assets/image-1", {
  method: "PUT", headers: { ...adminHeaders, "content-type": "image/png", "x-bank-asset-name": encodeURIComponent("題圖.png") }, body: new Blob(["published-image"]),
}), env, {});
assert.equal(response.status, 201);
response = await worker.fetch(new Request("https://example.test/api/bank/assets/image-1"), env, {});
assert.equal(response.status, 200);
assert.equal(await response.text(), "published-image");
assert.equal(decodeURIComponent(response.headers.get("x-bank-asset-name")), "題圖.png");

const imageQuestion = {
  id: 102, questionNumber: 2, q: "依圖選出正確移位方法？", answers: ["", "", "", ""],
  optionImages: ["A", "B", "C", "D"].map((letter) => [{ assetId: `option-${letter}`, name: `${letter} 選項圖`, kind: "option-image" }]),
  correct: 1,
};
response = await worker.fetch(new Request("https://example.test/api/bank", {
  method: "PUT", headers: { ...adminHeaders, "content-type": "application/json" },
  body: JSON.stringify({ questions: [publicQuestion, imageQuestion], baseRevision: firstPublication.revision }),
}), env, {});
assert.equal(response.status, 200, "the owner can publish picture-only choices");
response = await worker.fetch(new Request("https://example.test/api/bank"), env, {});
assert.deepEqual((await response.json()).snapshot.questions[1], imageQuestion, "published option image bindings survive storage");

const require = createRequire(import.meta.url);
const parser = require(resolve("dist/parser-pipeline.js"));
const regressions = parser.runRegressionTests();
assert.equal(regressions.failed, 0, "all PDF parsing regressions pass, including picture-only choices");
const html = readFileSync(resolve("dist/index.html"), "utf8");
let inlineCount = 0;
for (const match of html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)) {
  if (!match[1].trim()) continue;
  new Script(match[1], { filename: `dist/index.html:inline-${++inlineCount}` });
}
assert.ok(inlineCount > 0, "inline browser scripts were syntax checked");
const optionMedia = readFileSync(resolve("dist/option-media.js"), "utf8");
new Script(optionMedia, { filename: "dist/option-media.js" });
response = await worker.fetch(new Request("https://example.test/option-media.js"), env, {});
assert.equal(response.status, 200);
assert.equal(await response.text(), optionMedia, "the deployed Worker serves the current option editor");
execFileSync(process.execPath, ["tests/pdf-import-integration.cjs"], { stdio: "inherit" });
execFileSync(process.execPath, ["tests/option-media.cjs"], { stdio: "inherit" });
execFileSync(process.execPath, ["tests/question-image-display.cjs"], { stdio: "inherit" });
execFileSync(process.execPath, ["tests/crop-ownership.cjs"], { stdio: "inherit" });
execFileSync(process.execPath, ["tests/manual-import-review.cjs"], { stdio: "inherit" });
execFileSync(process.execPath, ["tests/scientific-text-import.cjs"], { stdio: "inherit" });
execFileSync(process.execPath, ["tests/real-112-2-import.cjs"], { stdio: "inherit" });

console.log(`PASS Worker memory and bank routes, picture-only option records, ${regressions.total} PDF regressions, and browser script syntax`);
