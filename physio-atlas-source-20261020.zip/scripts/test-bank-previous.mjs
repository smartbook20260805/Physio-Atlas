import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { runInNewContext } from "node:vm";

const page = readFileSync(resolve(import.meta.dirname, "../dist/index.html"), "utf8");
const start = page.indexOf("/* 題庫題目導覽：沿用目前科目、梯次與篩選後的題號順序。 */");
const end = page.indexOf("</script>", start);
assert.ok(start >= 0 && end > start);

const items = [{ id: 11 }, { id: 22 }, { id: 33 }];
const state = { id: 11, ans: 2 };
let previousButton = null;
let clickHandler;
let renders = 0;
const nextButton = { parentNode: { insertBefore(button) { previousButton = button; } } };
const pane = { querySelector(selector) { return selector === ".qfoot [data-a=\"next\"]" ? nextButton : previousButton; } };
const document = {
  getElementById() { return pane; },
  createElement() { return { setAttribute() {}, textContent: "" }; },
  addEventListener(type, handler) { if (type === "click") clickHandler = handler; },
};
const context = {
  document,
  st: state,
  list: () => items,
  cur: () => items.find((item) => item.id === state.id),
  renderBank() { renders++; previousButton = null; },
};
runInNewContext(page.slice(start, end), context);
assert.equal(previousButton.textContent, "← 上一題");

function clickPrevious() {
  clickHandler({
    target: { closest: () => previousButton },
    preventDefault() {},
    stopImmediatePropagation() {},
  });
}
clickPrevious();
assert.equal(state.id, 33, "first item wraps to the last in the current filtered list");
assert.equal(state.ans, null, "changing question clears only the transient answer selection");
clickPrevious();
assert.equal(state.id, 22);
assert.equal(renders, 2);
console.log("PASS previous-question navigation follows the current list order and wraps safely");
