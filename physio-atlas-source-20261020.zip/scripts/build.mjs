import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const template = readFileSync(resolve(root, "worker/template.js"), "utf8");
const page = readFileSync(resolve(root, "dist/index.html"), "utf8");
const parserPipeline = readFileSync(resolve(root, "dist/parser-pipeline.js"), "utf8");
const optionMedia = readFileSync(resolve(root, "dist/option-media.js"), "utf8");
const adminClient = readFileSync(resolve(root, "src/admin-client.js"), "utf8");
const appManifest = readFileSync(resolve(root, "dist/site.webmanifest"), "utf8");
const appIcons = Object.fromEntries([64, 180, 192, 512].map((size) => [
  `/icons/app-icon-${size}.png`,
  readFileSync(resolve(root, `dist/icons/app-icon-${size}.png`)).toString("base64"),
]));
const output = template
  .replace("__INDEX_HTML__", JSON.stringify(page))
  .replace("__PARSER_PIPELINE__", JSON.stringify(parserPipeline))
  .replace("__OPTION_MEDIA__", JSON.stringify(optionMedia))
  .replace("__ADMIN_CLIENT__", JSON.stringify(adminClient))
  .replace("__APP_MANIFEST__", JSON.stringify(appManifest))
  .replace("__APP_ICONS__", JSON.stringify(appIcons));
const destination = resolve(root, "dist/server/index.js");

mkdirSync(dirname(destination), { recursive: true });
writeFileSync(destination, output);
writeFileSync(resolve(root, "dist/server/package.json"), JSON.stringify({ type: "module" }) + "\n");
console.log("Built Worker with the current Physio Atlas interface.");
