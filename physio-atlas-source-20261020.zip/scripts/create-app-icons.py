"""Make exact-size PNG app icons from the user-provided artwork."""

from pathlib import Path

from PIL import Image, ImageOps


ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "assets" / "app-icon-source.jpg"
OUTPUT = ROOT / "dist" / "icons"


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    with Image.open(SOURCE) as original:
        artwork = ImageOps.exif_transpose(original).convert("RGB")
        if artwork.width != artwork.height:
            raise ValueError("App icon artwork must be square")
        for size in (64, 180, 192, 512):
            icon = artwork.resize((size, size), Image.Resampling.LANCZOS)
            icon.save(OUTPUT / f"app-icon-{size}.png", format="PNG", optimize=True)
            print(f"Created app-icon-{size}.png")


if __name__ == "__main__":
    main()
