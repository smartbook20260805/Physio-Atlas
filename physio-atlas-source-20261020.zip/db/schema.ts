/**
 * Canonical server-side schema for the cross-device memory profile.
 * The matching D1 migration lives in drizzle/0000_memory_sync.sql.
 */
export type MemoryProfileRow = {
  user_id: string;
  snapshot_key: string;
  updated_at: string;
  revision: number;
};

export const memoryProfilesTable = "memory_profiles";
