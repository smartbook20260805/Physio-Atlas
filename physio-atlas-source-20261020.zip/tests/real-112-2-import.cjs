const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const Parser = require('../dist/parser-pipeline.js');
const fixture = require('./fixtures/moex-112-2-physio-base.json');

// Unlike scientific-text-import.cjs, every geometry record here came from the
// actual 16-page PDF supplied by the user, extracted by the deployed PDF.js
// version. Raster/image extraction is deliberately out of this text regression.
const copy = (value) => JSON.parse(JSON.stringify(value));
const compact = (value) => String(value).replace(/\s+/g, '');
const allNumbers = Array.from({ length: 80 }, (_, index) => index + 1);
const subjects = ['物理治療基礎學', '物理治療學概論', '物理治療技術學', '神經疾病物理治療學', '骨科疾病物理治療學', '心肺疾病與小兒疾病物理治療學'];
const meta = { subject: subjects[0], subjectExplicit: true, examYear: '112', examSession: '2', examName: '112-2 物理治療基礎學' };
const sequences = ['①③④②⑤', '①②③④⑤', '①④②③⑤', '①④③②⑤'];
// Independently transcribed from all four rows of the actual corrected answer
// sheet. #56 is not an unknown answer: the note accepts A, D, or AD.
const officialRows = [
  'A C B B D C C D C D C D A D A D A B C C',
  'B C C D D D C D B B A A B C A C C C A A',
  'A B C D C D B B A C C B D C A # B C C C',
  'A B D C A D C D A B C D C C D B A D D D',
];
const official = officialRows.join(' ').split(' ');
function unpack(document) {
  return document.pages.map((page) => ({
    ...page,
    items: page.items.map(([str, transform, width, height, fontName]) => ({ str, transform: transform.slice(), width, height, fontName })),
  }));
}
const questionPages = unpack(fixture.questions);
const answerPages = unpack(fixture.answers);

const html = fs.readFileSync(path.join(__dirname, '../dist/index.html'), 'utf8');
const marker = '<script src="parser-pipeline.js"></script><script>';
const start = html.indexOf(marker) + marker.length;
const end = html.indexOf('</script><style>', start);
assert.ok(start >= marker.length && end >= 0, 'actual deployed PDF controller is available');
const controller = html.slice(start, end);
function harness(sourcePages) {
  const elements = new Map();
  const toasts = [];
  let saved = null;
  let ocrAttempted = false;
  function $(selector) {
    if (!elements.has(selector)) elements.set(selector, { textContent: '', innerHTML: '', disabled: false, onclick: null });
    return elements.get(selector);
  }
  const pdf = {
    numPages: sourcePages.length,
    async getPage(number) {
      const page = sourcePages[number - 1];
      return {
        getTextContent: async () => ({ items: copy(page.items) }),
        getViewport: ({ scale }) => ({ width: page.width * scale, height: page.height * scale }),
        getOperatorList: async () => ({ fnArray: [], argsArray: [] }),
        render: () => ({ promise: Promise.reject(new Error('Optional raster intentionally excluded from real-text fixture')) }),
      };
    },
  };
  const context = {
    console, Promise, Set, Date, Math, Uint8Array, $, Q: [], S: subjects,
    importDraft: null, pdfQuestionFile: null, pdfAnswerFile: null,
    window: { PhysioPdfPipeline: Parser },
    document: {
      addEventListener() {}, querySelector: () => null, querySelectorAll: () => [],
      createElement: () => ({ width: 0, height: 0, getContext: () => ({}) }),
    },
    canonicalSubject: (value) => subjects.includes(value) ? value : subjects[0],
    qSubject: (item) => item.subject || subjects[0], qSession: (item) => String(item.examSession || ''), qKeywords: () => [],
    detectExamMeta: () => meta, findExactDuplicate: () => null,
    loadPdfJs: async () => ({ OPS: {}, getDocument: () => ({ promise: Promise.resolve(pdf) }) }),
    loadTesseract: async () => { ocrAttempted = true; throw new Error('This source PDF has real selectable text; OCR must not be required'); },
    saveAsset: async () => null, saveAll: () => { saved = JSON.stringify(context.Q); },
    renderBank() {}, renderSubjects() {}, renderSimilar() {}, renderTrack() {}, view() {},
    toast: (message) => toasts.push(message), esc: (value) => String(value),
  };
  context.window.window = context.window;
  vm.createContext(context);
  vm.runInContext(controller, context, { filename: 'actual-112-2-pdf-import-controller.js' });
  context.renderImport = () => {};
  const api = context.window.__physioImportPipeline;
  assert.ok(api);
  return {
    context, api, toasts,
    file: { name: sourcePages.length === 1 ? '112-2基答.pdf' : '112-2基題.pdf', arrayBuffer: async () => new ArrayBuffer(8) },
    get stored() { return saved ? JSON.parse(saved) : []; },
    get ocrAttempted() { return ocrAttempted; },
  };
}

let runPromise;
function realPipeline() {
  if (!runPromise) runPromise = (async () => {
    const questionHarness = harness(questionPages), answerHarness = harness(answerPages);
    const questionData = await questionHarness.api.readPdf(questionHarness.file, 'question');
    const answerData = await answerHarness.api.readPdf(answerHarness.file, 'answer');
    const questions = questionHarness.api.parseQuestionPdf(questionData, meta, 'actual-moex-112-2-source', questionHarness.file.name, 80);
    const answersByNumber = answerHarness.api.parseAnswersPdf(answerData);
    const answerDiagnostics = questionHarness.api.answerDiagnostics(answersByNumber, questions);
    const items = questions.map((question) => questionHarness.api.buildImportItem(question, meta, answersByNumber[String(Number(question.questionNumber))], answerDiagnostics));
    return { questionHarness, answerHarness, questionData, answerData, questions, answersByNumber, answerDiagnostics, items };
  })();
  return runPromise;
}
function byNumber(questions, number) {
  const question = questions.find((item) => String(item.questionNumber) === String(number));
  assert.ok(question, 'actual question ' + number + ' is detected');
  return question;
}
const cases = [];
function test(name, run) { cases.push({ name, run }); }

test('fixture retains real PDF provenance, all 16 question pages, answer page, and unmodified geometry', () => {
  assert.equal(fixture.pdfJsVersion, '3.11.174');
  assert.equal(questionPages.length, 16);
  assert.equal(answerPages.length, 1);
  assert.equal(official.length, 80);
  for (const [kind, source] of [['questions', fixture.questions], ['answers', fixture.answers]]) {
    assert.match(source.url, /^https:\/\/wwwq\.moex\.gov\.tw\/exam\/wHandExamQandA_File\.ashx\?/);
    assert.match(source.sha256, /^[a-f0-9]{64}$/);
    const localOriginal = path.join(__dirname, '../.sites-runtime/real-pdf-112-2', kind + '.pdf');
    if (fs.existsSync(localOriginal)) {
      const bytes = fs.readFileSync(localOriginal);
      assert.equal(bytes.length, source.byteLength);
      assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), source.sha256, 'stored fixture provenance matches the actual downloaded ' + kind + ' PDF');
    }
  }
  assert.ok(questionPages[4].items.some((item) => item.str.includes('①')));
  assert.ok(questionPages[4].items.some((item) => item.str === '2+'), 'real PDF contains separate plain superscript glyphs before reconstruction');
  assert.ok(questionPages.every((page) => page.items.every((item) => item.transform.length === 6 && Number.isFinite(item.width) && item.fontName)));
});

test('actual readPdf reconstructs the single-column fifth page without moving continuations/options behind later questions', async () => {
  const result = await realPipeline();
  assert.equal(result.questionData.pageCount, 16);
  assert.equal(result.answerData.pageCount, 1);
  assert.equal(result.questionHarness.ocrAttempted, false);
  const pageFive = result.questionData.pages[4];
  const grouped = Parser.groupPdfItemsIntoText(questionPages[4].items, questionPages[4].width);
  assert.equal(grouped.usedColumns, false, 'short options + scientific scripts are not independent question columns');
  assert.deepEqual(copy(pageFive.items), questionPages[4].items.map(({ str, transform, width, height }) => ({ str, transform, width, height })), 'controller preserves every original glyph and coordinate');
  for (const sequence of sequences) assert.ok(pageFive.text.includes(sequence));
  assert.ok(pageFive.rawText.includes('Ca²⁺'));
});

test('all 80 real question numbers survive cleanPages and structural validation without omissions or phantom questions', async () => {
  const result = await realPipeline();
  assert.equal(result.questions.length, 80);
  assert.equal(new Set(result.questions.map((item) => Number(item.questionNumber))).size, 80);
  assert.deepEqual(copy(result.questions.diagnostics.detectedQuestionNumbers), allNumbers);
  assert.deepEqual(copy(result.questions.diagnostics.missingQuestionNumbers), []);
  assert.deepEqual(result.questions.filter((question) => question.structureStatus !== 'parsed').map((question) => question.questionNumber), [], 'every real source question has a stem and all four bounded options');
  const cleanedAgain = result.questionHarness.api.cleanPages(result.questionData.pages);
  const reparsed = Parser.parseQuestionPages(cleanedAgain, 'actual-moex-112-2-source', '112-2基題.pdf', 80);
  assert.equal(reparsed.length, 80);
  assert.equal(reparsed.filter((question) => question.structureStatus === 'parsed').length, 80);
});

test('real question 22 retains all five stem enumerations, three Ca²⁺ compounds, Na⁺, and exact A-D circle sequences', async () => {
  const { questions } = await realPipeline();
  const question = byNumber(questions, 22);
  assert.equal(question.structureStatus, 'parsed');
  assert.deepEqual(copy(question.answers), sequences);
  assert.equal((question.q.match(/Ca²⁺/g) || []).length, 3);
  assert.equal((question.q.match(/Na⁺/g) || []).length, 1);
  for (const number of '①②③④⑤') assert.ok(question.q.includes(number));
  assert.ok(compact(question.q).endsWith('⑤肌原纖維內Ca²⁺與旋轉素結合'));
  assert.ok(!/[A-D][.．、]/.test(question.q), 'option labels never leak into the stem');
  for (const sequence of sequences) assert.ok(question.ocrRawText.includes(sequence));
  assert.equal(question.originalPage, 5);
});

test('real questions 23/24/25/26 keep their own options and cross-page continuations, not a merely nonempty corrupted D', async () => {
  const { questions } = await realPipeline();
  const q23 = byNumber(questions, 23), q24 = byNumber(questions, 24), q25 = byNumber(questions, 25), q26 = byNumber(questions, 26);
  assert.ok(compact(q23.q).endsWith('④有氧系統'));
  assert.deepEqual(copy(q23.answers), ['僅①', '僅①②', '僅①②③', '①②③④']);
  assert.deepEqual(copy(q24.answers.map(compact)), ['肌絲（myofilament）', '肌節（sarcomere）', '肌原纖維（myofibril）', '肌纖維（musclefiber）']);
  assert.ok(compact(q25.answers[0]).endsWith('肌纖維（slow-twitchfibers）'));
  assert.ok(compact(q25.answers[1]).endsWith('（neighboring）分布'));
  assert.ok(compact(q25.answers[3]).endsWith('可能轉變成為快縮肌型態'));
  assert.ok(!q25.answers[3].includes('升糖素') && !q25.answers[3].includes('腎上腺素'), 'Q26 options do not leak into Q25 D');
  assert.deepEqual(copy(q26.answers), ['升糖素', '副甲狀腺素', '雌激素', '腎上腺素']);
  assert.equal(compact(q26.q), '下列何種激素是屬於酪胺酸（tyrosine）的衍生物？');
  assert.equal(q26.originalPage, 5, 'Q26 stem begins on page 5 and options continue onto page 6');
  assert.ok(q26.ocrRawText.includes('26.') && q26.ocrRawText.includes('腎上腺素'));
});

test('real corrected answer PDF yields all 80 keys, all 79 single letters, and accepts A/D/AD for corrected question 56', async () => {
  const { answersByNumber } = await realPipeline();
  assert.equal(Object.keys(answersByNumber).length, 80);
  assert.deepEqual(copy(answersByNumber.diagnostics.answerNumbers), allNumbers);
  official.forEach((letter, index) => {
    const entry = answersByNumber[String(index + 1)];
    assert.ok(entry && !entry.conflict);
    if (letter !== '#') assert.equal(entry.letter, letter, 'actual official answer for question ' + (index + 1));
  });
  const corrected = answersByNumber['56'];
  assert.ok(Array.isArray(corrected.acceptedAnswerLetters), 'the actual correction note must become accepted answer letters, not remain an unresolved # cell');
  assert.deepEqual(copy(corrected.acceptedAnswerLetters), ['A', 'D']);
  assert.ok(corrected.rawText.includes('56') && /[ＡA].*[ＤD]/.test(corrected.rawText), 'the original correction note is retained');
  assert.notEqual(corrected.allAnswersAccepted, true, 'B and C are not accepted by the official correction');
  assert.equal(answersByNumber['22'].letter, 'C');
});

test('actual controller pairs all answers by normalized question number, including #56 and deliberately reordered questions', async () => {
  const result = await realPipeline();
  assert.equal(result.answerDiagnostics.answerCount, 80);
  assert.deepEqual(copy(result.answerDiagnostics.matchedQuestionNumbers), allNumbers);
  assert.deepEqual(copy(result.answerDiagnostics.missingAnswerNumbers), []);
  const shuffled = result.questions.slice().reverse().map((question, index) => ({ ...question, questionNumber: index % 2 ? String(question.questionNumber) : Number(question.questionNumber) }));
  const items = shuffled.map((question) => result.questionHarness.api.buildImportItem(question, meta, result.answersByNumber[String(Number(question.questionNumber))], result.answerDiagnostics));
  for (const item of items) {
    const number = Number(item.questionNumber);
    assert.equal(item.structureStatus, 'parsed');
    assert.equal(typeof item.questionNumber, 'string');
    if (number === 56) {
      assert.deepEqual(copy(item.correctAnswers), [0, 3]);
      assert.equal(item.correct, null, 'do not manufacture a single official letter for the multi-accepted answer');
      assert.notEqual(item.allAnswersAccepted, true);
    } else {
      assert.equal(item.correctAnswer, official[number - 1]);
      assert.equal(item.correct, official[number - 1].charCodeAt(0) - 65);
    }
    assert.equal(item.answerStatus, 'matched');
    assert.ok(item.answerRawText);
  }
});

test('actual assessment grading accepts A or D, rejects B/C for corrected #56, and grades the complete real 80-question exam', async () => {
  const result = await realPipeline();
  const feature = html.match(/var R=read\('physio-atlas-test-records',\[\]\);[\s\S]*?<\/script>(?=\s*<style>\s*\/\* 錯題模式)/);
  assert.ok(feature, 'actual assessment scoring controller is available');
  const context = {
    console, Date, Math, JSON, Array, Number, String, Object, setTimeout, clearTimeout,
    Q: [], P: {}, st: {}, $: () => null, read: () => [], put() {}, saveAll() {},
    renderTrack() {}, renderBank() {}, renderBranchLanding() {},
    qSubject: (question) => question.subject || '', examBranch: () => '', pr: () => ({}), today: () => 0,
    esc: (value) => String(value || ''), toast() {}, view() {}, confirm: () => true,
    document: { querySelector: () => null, querySelectorAll: () => [], addEventListener() {} },
    window: { scrollTo() {} },
  };
  context.globalThis = context;
  vm.createContext(context);
  vm.runInContext(feature[0].replace(/<\/script>$/, ''), context, { filename: 'actual-assessment-for-real-112-2.js' });
  const calculate = context.window.PhysioAssessment.calculate;
  const q56 = byNumber(result.items, 56);
  for (const selected of [0, 1, 2, 3]) {
    const score = calculate({ questions: [q56], answers: [selected] });
    assert.equal(score.graded, 1, 'the corrected official answer is gradable for selected option ' + String.fromCharCode(65 + selected));
    assert.equal(score.correct, selected === 0 || selected === 3 ? 1 : 0);
  }
  const score = calculate({ questions: result.items, answers: result.items.map((item) => Number(item.questionNumber) === 56 ? 0 : item.correct) });
  assert.equal(score.total, 80);
  assert.equal(score.graded, 80);
  assert.equal(score.correct, 80);
  assert.equal(score.percent, 100);
});

test('all 80 actual source records pass applyImport and JSON persistence without losing raw text, choices, or accepted answers', async () => {
  const result = await realPipeline(), h = result.questionHarness;
  h.context.importDraft = { busy: false, selected: 0, items: result.items, answers: result.answersByNumber, meta };
  h.context.applyImport();
  assert.equal(h.context.importDraft === null, true, 'no failed actual question remains in the import draft');
  assert.equal(h.context.Q.length, 80);
  assert.equal(h.stored.length, 80);
  assert.equal(new Set(h.stored.map((question) => question.id)).size, 80);
  for (const stored of h.stored) {
    const parsed = byNumber(result.questions, stored.questionNumber);
    assert.equal(stored.structureStatus, 'parsed');
    assert.equal(stored.q, parsed.q);
    assert.deepEqual(stored.answers, copy(parsed.answers));
    assert.equal(stored.ocrRawText, parsed.ocrRawText);
    assert.equal(stored.parsedQuestion, parsed.q);
    assert.deepEqual(stored.parsedOptions, copy(parsed.parsedOptions));
    assert.equal(stored.answerStatus, 'matched');
    assert.ok(stored.answerRawText);
  }
  assert.deepEqual(byNumber(h.stored, 22).answers, sequences);
  assert.deepEqual(byNumber(h.stored, 56).correctAnswers, [0, 3]);
  assert.equal(byNumber(h.stored, 56).correct, null);
  assert.notEqual(byNumber(h.stored, 56).allAnswersAccepted, true);
});

(async () => {
  let passed = 0;
  for (const entry of cases) {
    try { await entry.run(); passed++; console.log('PASS ' + entry.name); }
    catch (error) { process.exitCode = 1; console.error('FAIL ' + entry.name); console.error(error); }
  }
  const result = await realPipeline();
  console.log(JSON.stringify({ source: 'Actual user-supplied MOEX 112-2 physical therapy foundations PDFs', pages: result.questionData.pageCount, detected: result.questions.length, missingQuestionNumbers: result.questions.diagnostics.missingQuestionNumbers, structureParsed: result.questions.filter((question) => question.structureStatus === 'parsed').length, failedStructure: result.questions.filter((question) => question.structureStatus !== 'parsed').map((question) => question.questionNumber), answerCount: Object.keys(result.answersByNumber).length, matchedAnswers: result.answerDiagnostics.matchedQuestionNumbers.length, missingAnswerNumbers: result.answerDiagnostics.missingAnswerNumbers }));
  console.log(`${passed === cases.length ? 'PASS' : 'FAIL'} ${passed}/${cases.length} real 112-2 PDF import regressions (all 80 questions; original PDF.js geometry, not synthetic)`);
})().catch((error) => { console.error(error); process.exitCode = 1; });
