const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { File: BufferFile } = require('node:buffer');
const parser = require('../dist/parser-pipeline.js');

const code = fs.readFileSync(path.join(__dirname, '../dist/option-media.js'), 'utf8');
const FileClass = globalThis.File || BufferFile;
const copy = (value) => JSON.parse(JSON.stringify(value));
const photo = (name = 'choice.png') => new FileClass(['image bytes'], name, { type: 'image/png' });
const image = (assetId) => ({ assetId, name: assetId + '.png', kind: 'option-image' });
const tick = async () => { for (let i = 0; i < 6; i++) await Promise.resolve(); };

function harness() {
  const listeners = new Map();
  const zones = [];
  const crops = [];
  const assets = new Map();
  const toasts = [];
  let assetCounter = 0;
  let savePolicy = null;
  let importRenders = 0;
  let applied = 0;
  const context = {
    File: FileClass, Blob, Promise, Set, WeakMap,
    URL: { createObjectURL: (blob) => 'blob:test-' + blob.size },
    MutationObserver: class { observe() {} },
    esc: (value) => String(value),
    toast: (value) => toasts.push(value),
    qmodal() {}, renderBank() {}, renderImport() { importRenders++; },
    applyImport() { applied++; },
    cur: () => null,
    st: {}, importDraft: null,
    getAssetDb: () => Promise.resolve(null),
    openCropper: (file, use) => crops.push({ file, use }),
    saveAsset(file, kind) {
      if (savePolicy) return savePolicy(file, kind);
      const id = 'saved-' + (++assetCounter);
      assets.set(id, { id, name: file.name, blob: file, type: file.type });
      return Promise.resolve(id);
    },
    document: {
      body: { dataset: { bankAccess: 'admin' } },
      addEventListener(type, listener) {
        if (!listeners.has(type)) listeners.set(type, []);
        listeners.get(type).push(listener);
      },
      getElementById: () => null,
      querySelector: () => null,
      querySelectorAll(selector) {
        const type = /data-option-media-context="([^"]+)"/.exec(selector);
        return type && !selector.startsWith('#qmodal') ? zones.filter((zone) => zone.dataset.optionMediaContext === type[1]) : [];
      },
    },
  };
  context.window = {
    PhysioPublishedAssetRecord: (id) => assets.get(id) || null,
    __physioImportPipeline: { validate: parser.validateQuestionStructure },
  };
  vm.createContext(context);
  vm.runInContext(code, context, { filename: 'dist/option-media.js' });
  function zone(type, index) {
    const preview = { innerHTML: '', querySelectorAll: () => [] };
    const input = {
      files: [], value: '',
      matches: (selector) => selector === '[data-option-media-file]',
      click() { input.clicked = true; },
      closest: (selector) => selector === '[data-option-media-context]' ? result : null,
    };
    const result = {
      dataset: { optionMediaContext: type, optionMediaIndex: String(index) },
      classList: { add() {}, remove() {} },
      contains: () => false,
      closest: (selector) => selector === '[data-option-media-context]' ? result : null,
      querySelector: (selector) => selector === '.option-media-preview' ? preview : selector === '[data-option-media-file]' ? input : null,
      querySelectorAll: () => [],
      input,
    };
    zones.push(result);
    return result;
  }
  function dispatch(type, target, extra = {}) {
    const event = { target, preventDefault() { event.prevented = true; }, ...extra };
    for (const listener of listeners.get(type) || []) listener(event);
    return event;
  }
  function action(zone, name, at = 0) {
    const button = {
      dataset: { optionMediaAction: name, optionMediaAt: String(at) },
      closest: (selector) => selector === '[data-option-media-action]' ? button : selector === '[data-option-media-context]' ? zone : null,
    };
    return dispatch('click', button);
  }
  function upload(zone, file = photo()) {
    action(zone, 'pick');
    zone.input.files = [file];
    dispatch('change', zone.input);
  }
  function useCrop(file = photo('cropped.png')) {
    const crop = crops.shift();
    assert.ok(crop, 'image action opens the existing crop dialog');
    crop.use(file);
    return crop;
  }
  return {
    context, api: context.window.PhysioOptionMedia, crops, assets, toasts,
    zone, dispatch, action, upload, useCrop,
    setSavePolicy: (policy) => { savePolicy = policy; },
    get importRenders() { return importRenders; },
    get applied() { return applied; },
  };
}

const cases = [];
function test(name, run) { cases.push({ name, run }); }

test('creation accepts uploaded, pasted and dropped image choices in the correct A-D slots', async () => {
  const h = harness();
  h.context.qmodal();
  h.upload(h.zone('create', 0)); h.useCrop();
  const paste = h.dispatch('paste', h.zone('create', 1), {
    clipboardData: { items: [{ type: 'image/png', getAsFile: () => photo('B.png') }] },
  });
  assert.equal(paste.prevented, true); h.useCrop();
  h.dispatch('drop', h.zone('create', 2), { dataTransfer: { files: [photo('C.png')] } }); h.useCrop();
  h.upload(h.zone('create', 3)); h.useCrop();
  const images = await h.api.finish(h.api.captureCreate());
  assert.deepEqual(copy(images).map((slot) => slot.length), [1, 1, 1, 1]);
  assert.deepEqual(copy(images).map((slot) => slot[0].name), ['A 選項圖片', 'B 選項圖片', 'C 選項圖片', 'D 選項圖片']);
  assert.equal(parser.validateQuestionStructure('依圖選出正確移位方法？', ['', '', '', ''], images).ok, true,
    'four image-only choices pass the actual question parser validation');
});

test('editor image edits remain staged and reopening discards canceled changes', async () => {
  const h = harness();
  const question = { id: 7, correct: 2, optionImages: [[image('original-A')], [], [], []] };
  const original = copy(question);
  h.api.beginEditor(question);
  h.action(h.zone('edit', 0), 'remove');
  h.upload(h.zone('edit', 1)); h.useCrop();
  await tick();
  assert.deepEqual(question, original, 'removal and addition must not mutate Q before Save succeeds');
  assert.equal(h.api.captureEditor(8), null, 'a different question cannot capture this editor draft');
  h.api.beginEditor(question);
  const reset = await h.api.finish(h.api.captureEditor(7));
  assert.deepEqual(copy(reset).map((slot) => slot.map((item) => item.assetId)), [['original-A'], [], [], []]);
  assert.equal(question.correct, 2, 'editing image choices must preserve the official correct option');
});

test('failed asset writes prevent finish without modifying the original question', async () => {
  const h = harness();
  const question = { id: 8, correct: 1, optionImages: [[image('original-A')], [], [], []] };
  const original = copy(question);
  h.api.beginEditor(question);
  h.setSavePolicy(() => Promise.resolve(null));
  h.upload(h.zone('edit', 2)); h.useCrop();
  await tick();
  await assert.rejects(h.api.finish(h.api.captureEditor(8)), /未能儲存/);
  assert.deepEqual(question, original);
  assert.ok(h.toasts.some((text) => /未能儲存/.test(text)));
});

test('finish waits for an in-flight image asset before returning the draft', async () => {
  const h = harness();
  h.context.qmodal();
  let resolveAsset;
  h.setSavePolicy((file, kind) => kind === 'option-image-source' ? Promise.resolve('source-D') : new Promise((resolve) => { resolveAsset = resolve; }));
  h.upload(h.zone('create', 3)); h.useCrop();
  await tick();
  let done = false;
  const completion = h.api.finish(h.api.captureCreate()).then((images) => { done = true; return images; });
  await tick();
  assert.equal(done, false, 'Save cannot outrun the image write');
  resolveAsset('pending-D');
  const images = await completion;
  assert.equal(images[3][0].assetId, 'pending-D');
});

test('switching the import preview does not lose the image for the original question', async () => {
  const h = harness();
  const first = { id: 'draft-1', questionNumber: 1, q: '一？', answers: ['A', 'B', '', 'D'], correct: 2 };
  const second = { id: 'draft-2', questionNumber: 2, q: '二？', answers: ['A', 'B', 'C', 'D'], correct: 0 };
  h.context.importDraft = { busy: false, selected: 0, items: [first, second] };
  let resolveAsset;
  h.setSavePolicy((file, kind) => kind === 'option-image-source' ? Promise.resolve('source-first-C') : new Promise((resolve) => { resolveAsset = resolve; }));
  h.upload(h.zone('import', 2)); h.useCrop();
  await tick();
  h.context.importDraft.selected = 1;
  resolveAsset('first-question-C');
  await tick();
  assert.equal(first.optionImages[2][0].assetId, 'first-question-C');
  assert.equal(first.structureStatus, 'parsed');
  assert.equal(second.optionImages, undefined, 'the selected second question must not receive the first question image');
  assert.equal(first.correct, 2);
});

test('replace, recrop and remove operate on the selected image within the selected option', async () => {
  const h = harness();
  const question = { id: 9, correct: 3, optionImages: [[image('A')], [image('B-0'), image('B-1')], [image('C')], [image('D')]] };
  const original = copy(question);
  h.api.beginEditor(question);
  const bZone = h.zone('edit', 1);
  h.action(bZone, 'replace', 1);
  assert.equal(bZone.input.clicked, true);
  bZone.input.files = [photo('replacement-B.png')];
  h.dispatch('change', bZone.input); h.useCrop(); await tick();
  let owner = h.api.captureEditor(9);
  let images = await h.api.finish(owner); h.api.release(owner);
  assert.deepEqual(copy(images).map((slot) => slot.map((item) => item.assetId)), [['A'], ['B-0', 'saved-2'], ['C'], ['D']]);
  h.action(bZone, 'crop', 1); await tick();
  const recrop = h.useCrop(photo('recropped-B.png'));
  assert.equal(recrop.file.name, 'replacement-B.png', 'recrop reloads the original uncut source asset');
  await tick();
  images = await h.api.finish(owner); h.api.release(owner);
  assert.equal(images[1][1].sourceAssetId, 'saved-1', 'recrop retains the source asset binding');
  assert.equal(images[1][1].assetId, 'saved-3');
  h.action(bZone, 'remove', 0);
  images = await h.api.finish(owner);
  assert.deepEqual(copy(images).map((slot) => slot.map((item) => item.assetId)), [['A'], ['saved-3'], ['C'], ['D']]);
  assert.deepEqual(question, original, 'all editor actions leave original data untouched until committed by saveQuestion');
});

test('reopening creation discards an earlier draft and its late asset result', async () => {
  const h = harness();
  h.context.qmodal();
  const earlier = h.api.captureCreate();
  let resolveAsset;
  h.setSavePolicy(() => new Promise((resolve) => { resolveAsset = resolve; }));
  h.upload(h.zone('create', 0)); h.useCrop();
  h.context.qmodal();
  const current = h.api.captureCreate();
  assert.notEqual(current, earlier);
  resolveAsset('orphaned-result'); await tick();
  assert.deepEqual(copy(await h.api.finish(current)), [[], [], [], []]);
  await assert.rejects(h.api.finish(earlier), /已取消/);
});

test('reader accounts cannot add or remove option images', async () => {
  const h = harness();
  const question = { id: 10, optionImages: [[image('keep')], [], [], []] };
  h.api.beginEditor(question);
  h.context.document.body.dataset.bankAccess = 'reader';
  const aZone = h.zone('edit', 0);
  h.action(aZone, 'remove');
  h.dispatch('paste', aZone, { clipboardData: { items: [{ type: 'image/png', getAsFile: () => photo() }] } });
  assert.equal(h.crops.length, 0);
  const result = await h.api.finish(h.api.captureEditor(10));
  assert.equal(result[0][0].assetId, 'keep');
});

test('Save during recrop preparation is rejected and the original image remains available for cropping', async () => {
  const h = harness();
  const question = { id: 11, correct: 0, optionImages: [[image('source-A')], [], [], []] };
  h.assets.set('source-A', { blob: photo('source-A.png'), name: 'source-A.png' });
  h.api.beginEditor(question);
  const owner = h.api.captureEditor(11);
  h.action(h.zone('edit', 0), 'crop');
  await assert.rejects(h.api.finish(owner), /正在準備裁切/);
  await tick();
  assert.equal(h.crops.length, 1, 'the pending recrop is not silently discarded by Save');
  h.useCrop(); await tick();
  const result = await h.api.finish(owner);
  assert.equal(result[0][0].sourceAssetId, 'source-A');
  assert.equal(question.optionImages[0][0].assetId, 'source-A');
});

(async () => {
  for (const entry of cases) {
    let timer;
    try {
      await Promise.race([entry.run(), new Promise((resolve, reject) => {
        timer = setTimeout(() => reject(new Error('Timed out: ' + entry.name)), 3000);
      })]);
    } finally { clearTimeout(timer); }
    console.log('PASS ' + entry.name);
  }
  console.log(`PASS ${cases.length} option-media regressions`);
})().catch((error) => { console.error(error); process.exitCode = 1; });
