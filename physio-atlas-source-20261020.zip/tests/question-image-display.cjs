const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const html = fs.readFileSync(path.join(__dirname, '../dist/index.html'), 'utf8');
const copy = (value) => JSON.parse(JSON.stringify(value));
const escapeHtml = (value) => String(value == null ? '' : value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
function scriptAfter(comment) {
  const start = html.indexOf(comment), end = html.indexOf('</script>', start);
  assert.ok(start >= 0 && end > start, 'the actual image display script is present');
  return html.slice(start, end);
}
const displayScript = scriptAfter('/* 題圖與照片不再只留在 PDF 中');
const editorScript = scriptAfter('/* 題庫中的題圖也可直接由使用者更換。');
const ruleStart = html.indexOf('  function imageQuestionTargets(');
const ruleEnd = html.indexOf(';', html.indexOf('  window.PhysioQuestionImageRules=', ruleStart)) + 1;
assert.ok(ruleStart >= 0 && ruleEnd > ruleStart, 'the actual required-image ownership rules are present');
const ruleScript = html.slice(ruleStart, ruleEnd);
function requiredQuestion(number = 41) {
  return {
    id: 'question-' + number, questionNumber: number, q: '下圖中甲乙丙丁的位置，何者正確？',
    answers: ['甲', '乙', '丙', '丁'], requiresQuestionImage: true,
    questionImages: ['first', 'second'].map((name) => ({
      assetId: 'asset-' + name, name: 'private-file-' + name + '.jpg',
      kind: 'question-visual', assignment: 'question-band', requiresAnswer: true, questionNumbers: [number],
    })),
  };
}
function classes() {
  const values = new Set();
  return { add: (name) => values.add(name), contains: (name) => values.has(name), toggle(name) { if (values.has(name)) values.delete(name); else values.add(name); return values.has(name); } };
}
function imageNodes(markup) {
  return Array.from(markup.matchAll(/data-question-image-asset="([^"]+)"/g), (match) => {
    const card = { classList: classes() };
    return { dataset: { questionImageAsset: match[1] }, src: '', closest: (selector) => selector === '.question-source-image' ? card : null, card };
  });
}
function harness(initialQuestion = requiredQuestion()) {
  let current = initialQuestion, saved = 0, cropCalls = 0, pickerClicks = 0;
  const events = {}, assetRequests = [], createdUrls = [], fileInputs = new Map();
  let parts = [], bankImages = [], previewMarkup = '', previewImages = [], actionMarkup = '';
  const list = { scrollTop: 137 };
  const actions = {
    querySelector: (selector) => selector === '[data-question-image-edit]' && actionMarkup.includes('data-question-image-edit') ? {} : null,
    insertAdjacentHTML(position, markup) { assert.equal(position, 'beforeend'); actionMarkup += markup; },
  };
  const title = {
    insertAdjacentHTML(position, markup) {
      const at = parts.findIndex((part) => part.kind === 'stem');
      assert.ok(at >= 0);
      assert.ok(['beforebegin', 'afterend'].includes(position));
      parts.splice(position === 'afterend' ? at + 1 : at, 0, { kind: markup.includes('data-question-images') ? 'images' : 'number', markup });
      if (markup.includes('data-question-images')) bankImages = imageNodes(markup);
    },
  };
  const pane = {
    querySelector(selector) {
      if (selector === '.qtitle') return title;
      if (selector === '.qacts') return actions;
      if (selector === '[data-question-images]') return parts.some((part) => part.kind === 'images') ? {} : null;
      if (selector === '[data-question-number-label]') return parts.some((part) => part.kind === 'number') ? {} : null;
      return null;
    },
    querySelectorAll: (selector) => selector === '[data-question-image-asset]' ? bankImages : [],
    insertAdjacentHTML(position, markup) { assert.equal(position, 'beforeend'); parts.push({ kind: 'images', markup }); bankImages = imageNodes(markup); },
  };
  const preview = {
    querySelector: (selector) => selector === '[data-question-images]' && previewMarkup.includes('data-question-images') ? {} : null,
    querySelectorAll: (selector) => selector === '[data-question-image-asset]' ? previewImages : [],
    insertAdjacentHTML(position, markup) { assert.equal(position, 'beforeend'); previewMarkup += markup; previewImages = imageNodes(markup); },
  };
  const context = {
    console, Promise, Q: [], importDraft: null, st: { ans: null }, startMock: { t: null },
    window: { PhysioPublishedAssetRecord(assetId) { assetRequests.push(assetId); return { blob: { assetId } }; } },
    URL: { createObjectURL(blob) { createdUrls.push(blob.assetId); return 'blob:test-' + blob.assetId; } },
    document: {
      addEventListener(type, listener) { (events[type] ||= []).push(listener); },
      querySelector(selector) { if (selector === '#importResult .preview-editor') return preview; if (selector === '#importResult .preview-list') return list; return null; },
      getElementById: (id) => id === 'qpane' ? pane : fileInputs.get(id) || null,
      createElement: () => ({ click() { pickerClicks++; } }),
      body: { appendChild(input) { fileInputs.set(input.id, input); } },
    },
    $: (selector) => selector === '#qpane' ? pane : null, cur: () => current,
    esc: escapeHtml, getAssetDb: async () => null,
    renderBank() { parts = [{ kind: 'stem', markup: '<h2 class="qtitle">' + escapeHtml(current.q) + '</h2>' }, { kind: 'options', markup: '<div class="opts">A B C D</div>' }]; bankImages = []; actionMarkup = ''; },
    renderImport() { previewMarkup = ''; previewImages = []; },
    saveAll() { saved++; }, saveAsset: async (file, kind) => { assert.equal(kind, 'manual-question-image'); assert.equal(file.name, 'cropped.jpg'); return 'manual-new-image'; },
    openCropper(file, done) { cropCalls++; assert.equal(file.type, 'image/jpeg'); done({ name: 'cropped.jpg', type: 'image/jpeg' }); },
    answer() {}, submit() {}, setpr() {}, pr: () => ({}), today: () => 0,
    renderTrack() {}, renderMock() {}, toast() {}, clearInterval() {},
  };
  vm.createContext(context);
  vm.runInContext(ruleScript, context, { filename: 'actual-question-image-ownership-rules.js' });
  vm.runInContext(displayScript, context, { filename: 'actual-question-image-display.js' });
  return {
    context, events, pane, preview, list, api: context.window.__physioQuestionImages,
    assetRequests, createdUrls, setQuestion(question) { current = question; },
    get parts() { return parts; }, get previewMarkup() { return previewMarkup; }, get actionMarkup() { return actionMarkup; },
    get saved() { return saved; }, get cropCalls() { return cropCalls; }, get pickerClicks() { return pickerClicks; },
  };
}
const flush = () => new Promise((resolve) => setImmediate(resolve));
const cases = [];
function test(name, run) { cases.push({ name, run }); }

test('shared markup shows only images, retains ordered assets and numbered accessible labels, and never rewrites source data', () => {
  const question = requiredQuestion(), original = copy(question), h = harness(question);
  for (const preview of [false, true]) {
    const markup = h.api.markup(question, preview);
    assert.equal(markup.replace(/<[^>]*>/g, '').trim(), '', 'no visible header, instruction, filename, or caption remains');
    assert.ok(!markup.includes('question-source-images-head') && !markup.includes('<figcaption'));
    for (const removed of ['題圖｜作答必需', '點擊圖片可放大', 'private-file-first.jpg', 'private-file-second.jpg']) assert.ok(!markup.includes(removed));
    assert.deepEqual(Array.from(markup.matchAll(/data-question-image-asset="([^"]+)"/g), (match) => match[1]), ['asset-first', 'asset-second']);
    assert.deepEqual(Array.from(markup.matchAll(/data-question-image-toggle="([^"]+)"/g), (match) => match[1]), ['0', '1']);
    assert.equal((markup.match(/alt="第 41 題題圖"/g) || []).length, 2);
    assert.equal((markup.match(/aria-label="放大第 41 題題圖"/g) || []).length, 2);
    assert.equal((markup.match(/<button type="button"/g) || []).length, 2, 'native keyboard-operable image buttons remain');
    assert.ok(markup.includes('data-question-images'));
    assert.equal(markup.includes('preview-question-images'), preview);
  }
  assert.deepEqual(question, original, 'the presentation change does not crop, reassign, or erase assets or diagram annotations');
  assert.equal(h.saved, 0);
});

test('ownership and required-image rules still reject no-image, optional, wrong-question, and unverified automatic images', () => {
  const h = harness();
  assert.equal(h.api.markup({ questionNumber: 42, q: '不需要題圖', questionImages: [] }, false), '');
  const optional = requiredQuestion(); optional.requiresQuestionImage = false; optional.questionImages.forEach((image) => { image.requiresAnswer = false; });
  assert.equal(h.api.markup(optional, false), '');
  const wrongQuestion = requiredQuestion(42); wrongQuestion.questionImages.forEach((image) => { image.questionNumbers = [41]; });
  assert.equal(h.api.markup(wrongQuestion, false), '');
  const unverified = requiredQuestion(); unverified.questionImages.forEach((image) => { delete image.assignment; });
  assert.equal(h.api.markup(unverified, false), '');
  const manual = requiredQuestion(); manual.questionImages = [{ assetId: 'manual-reviewed', name: 'do-not-show.jpg', assignment: 'manual', userReviewed: true }];
  assert.ok(h.api.markup(manual, false).includes('data-question-image-asset="manual-reviewed"'), 'explicit reviewed manual mode remains usable');
});

test('hydration loads the exact retained assets without filename text or any storage writes', async () => {
  const h = harness(), nodes = imageNodes(h.api.markup(requiredQuestion(), false));
  h.api.hydrate({ querySelectorAll: (selector) => selector === '[data-question-image-asset]' ? nodes : [] });
  await flush();
  assert.deepEqual(h.assetRequests, ['asset-first', 'asset-second']);
  assert.deepEqual(h.createdUrls, ['asset-first', 'asset-second']);
  assert.deepEqual(nodes.map((node) => node.src), ['blob:test-asset-first', 'blob:test-asset-second']);
  assert.equal(h.saved, 0);
});

test('the existing delegated image click expands and collapses its own figure', () => {
  const h = harness(), card = { classList: classes() };
  const button = { closest: (selector) => selector === '.question-source-image' ? card : null };
  const event = { target: { closest: (selector) => selector === '[data-question-image-toggle]' ? button : null } };
  assert.equal(h.events.click.length, 1);
  h.events.click[0](event); assert.equal(card.classList.contains('expanded'), true);
  h.events.click[0](event); assert.equal(card.classList.contains('expanded'), false);
  h.events.click[0]({ target: { closest: () => null } });
  assert.equal(card.classList.contains('expanded'), false);
});

test('bank inserts the shared image block after the stem and before options, and preview keeps manual review scroll position', () => {
  const h = harness(), question = requiredQuestion();
  h.context.renderBank();
  assert.deepEqual(h.parts.map((part) => part.kind), ['number', 'stem', 'images', 'options']);
  assert.equal(h.parts[2].markup, h.api.markup(question, false));
  h.context.importDraft = { busy: false, selected: 0, items: [question] };
  h.context.renderImport();
  assert.equal(h.previewMarkup, h.api.markup(question, true));
  assert.equal(h.list.scrollTop, 137);
  h.setQuestion({ id: 'plain', questionNumber: 42, q: '純文字題', questionImages: [] });
  h.context.renderBank();
  assert.deepEqual(h.parts.map((part) => part.kind), ['stem', 'options']);
});

test('assessment calls the same image markup and hydration functions between its title and options', () => {
  const h = harness(), start = html.indexOf('  function assessmentImage('), end = html.indexOf('  function completion(', start);
  assert.ok(start >= 0 && end > start);
  vm.runInContext('(function(){' + html.slice(start, end) + '\nwindow.__testAssessmentImages={markup:assessmentImage,hydrate:hydrateAssessmentImages};})();', h.context);
  const question = requiredQuestion();
  assert.equal(h.context.window.__testAssessmentImages.markup(question), h.api.markup(question, false));
  const root = {}; let hydrated = null;
  h.api.hydrate = (value) => { hydrated = value; };
  h.context.window.__testAssessmentImages.hydrate(root);
  assert.equal(hydrated, root);
  assert.match(html, /<h2 class="assessment-title">[\s\S]*?assessmentImage\(question\)[\s\S]*?<div class="opts assessment-options">/);
});

test('late scoped styles remove the dark card and letterboxing while preserving visible focus and desktop/mobile assessment expansion', () => {
  const at = html.indexOf('/* 題圖只顯示圖片本身；'), end = html.indexOf('</style>', at);
  assert.ok(at > html.indexOf('.assessment-source .question-source-image img'), 'neutral styles follow the old required-image and assessment overrides');
  const css = html.slice(at, end);
  function rule(selector) {
    const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const match = css.match(new RegExp(escaped + '\\s*\\{([^}]+)\\}'));
    assert.ok(match, 'style rule retained: ' + selector);
    return Object.fromEntries(match[1].split(';').filter(Boolean).map((declaration) => declaration.split(':').map((part) => part.trim())));
  }
  const section = rule('.question-source-images.question-required-image');
  assert.equal(section.padding, '0'); assert.equal(section.border, '0'); assert.equal(section.background, 'transparent');
  const figure = rule('.question-required-image .question-source-image');
  assert.equal(figure.width, 'fit-content'); assert.equal(figure.border, '0'); assert.equal(figure.background, 'transparent');
  const button = rule('.question-required-image .question-source-image button');
  assert.equal(button.width, 'auto'); assert.equal(button.padding, '0'); assert.equal(button.border, '0'); assert.equal(button.background, 'transparent');
  const image = rule('.question-required-image .question-source-image img');
  assert.equal(image.width, 'auto'); assert.equal(image['max-width'], '100%'); assert.equal(image.height, 'auto'); assert.equal(image.background, 'transparent');
  assert.equal(rule('.question-required-image .question-source-image.expanded')['max-width'], '900px');
  assert.equal(rule('.question-required-image .question-source-image.expanded img')['max-height'], 'none');
  assert.equal(rule('.assessment-source .question-required-image .question-source-image.expanded')['max-width'], '900px');
  assert.equal(rule('.assessment-source .question-required-image .question-source-image.expanded img')['max-height'], 'none');
  assert.match(rule('.question-required-image .question-source-image button:focus-visible').outline, /^2px solid/);
  assert.ok(!css.includes('object-fit:cover') && !css.includes('overflow:hidden'), 'the neutral presentation does not crop diagram annotations');
  assert.ok(!css.includes('.question-image-review') && !css.includes('data-question-image-edit'), 'only display wrappers are restyled, not admin controls');
});

test('manual bank replacement still opens the cropper and saves the selected question image; import upload/drop/paste hooks remain', async () => {
  const question = requiredQuestion(), h = harness(question);
  h.context.Q = [question];
  vm.runInContext(editorScript, h.context, { filename: 'actual-manual-question-image-editor.js' });
  assert.ok(h.actionMarkup.includes('data-question-image-edit="question-41"') && h.actionMarkup.includes('更換題圖'));
  assert.ok(h.actionMarkup.includes('data-question-image-remove="question-41"'), 'manual removal remains available');
  const edit = { dataset: { questionImageEdit: question.id } };
  h.events.click[1]({ preventDefault() {}, target: { closest: (selector) => selector === '[data-question-image-edit]' ? edit : null } });
  assert.equal(h.pickerClicks, 1);
  h.events.change[0]({ target: { id: 'bankQuestionImagePicker', files: [{ name: 'replacement.jpg', type: 'image/jpeg' }], value: 'chosen' } });
  await flush();
  assert.equal(h.cropCalls, 1); assert.equal(h.saved, 1);
  assert.equal(question.questionImages.length, 1);
  assert.equal(question.questionImages[0].assetId, 'manual-new-image');
  assert.equal(question.questionImageManualOverride, 'manual');
  assert.equal(question.requiresQuestionImage, true);
  assert.ok(h.api.markup(question, false).includes('data-question-image-asset="manual-new-image"'));
  assert.ok(h.actionMarkup.includes('data-question-image-remove'));
  assert.ok(html.includes('data-question-image-select') && html.includes('data-question-image-review tabindex="0"'));
  assert.ok(html.includes('imageFromTransfer(event.dataTransfer)') && html.includes('imageFromTransfer(event.clipboardData)'));
  assert.ok(html.includes('<script src="/admin-client.js"></script>'), 'owner permission enforcement is unchanged');
});

(async () => {
  let passed = 0;
  for (const entry of cases) {
    try { await entry.run(); passed++; console.log('PASS ' + entry.name); }
    catch (error) { process.exitCode = 1; console.error('FAIL ' + entry.name); console.error(error); }
  }
  console.log(`${passed === cases.length ? 'PASS' : 'FAIL'} ${passed}/${cases.length} question-image display regressions (actual shared display/editor scripts; no real browser or raster assertions)`);
})().catch((error) => { console.error(error); process.exitCode = 1; });
