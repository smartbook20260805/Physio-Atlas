/* Rebuild only from the user's actual downloaded MOEX source files.
 * This mechanical generator never fabricates PDF glyphs or answer content.
 * Run: node tests/generate-real-112-2-fixture.cjs <extraction-directory>
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');

const sourceDir = path.resolve(process.argv[2] || '.sites-runtime/real-pdf-112-2');
const questionUrl = 'https://wwwq.moex.gov.tw/exam/wHandExamQandA_File.ashx?t=Q&code=112100&c=311&s=44&q=1';
const answerUrl = 'https://wwwq.moex.gov.tw/exam/wHandExamQandA_File.ashx?t=M&code=112100&c=311&s=44&q=1';
function document(kind, url, expectedPages) {
  const bytes = fs.readFileSync(path.join(sourceDir, kind + '.pdf'));
  assert.equal(bytes.subarray(0, 5).toString('ascii'), '%PDF-', 'fixture provenance must be an actual PDF');
  const pages = JSON.parse(fs.readFileSync(path.join(sourceDir, kind + '-extracted.json'), 'utf8'));
  assert.equal(pages.length, expectedPages);
  return {
    url,
    sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
    byteLength: bytes.length,
    // Original double values are preserved without rounding; all six PDF.js
    // transform entries, width, height, and font name are retained losslessly.
    pages: pages.map((page) => ({
      page: page.page,
      width: page.width,
      height: page.height,
      items: page.items.map((item) => [item.str, item.transform, item.width, item.height, item.fontName]),
    })),
  };
}
const fixture = {
  description: 'Actual MOEX 112-2 physical therapy foundations 80-question PDF and corrected answer PDF supplied by the user; not synthetic.',
  pdfJsVersion: '3.11.174',
  itemColumns: ['str', 'transform', 'width', 'height', 'fontName'],
  questions: document('questions', questionUrl, 16),
  answers: document('answers', answerUrl, 1),
};
const fixtureDir = path.join(__dirname, 'fixtures');
fs.mkdirSync(fixtureDir, { recursive: true });
const destination = path.join(fixtureDir, 'moex-112-2-physio-base.json');
fs.writeFileSync(destination, JSON.stringify(fixture) + '\n');
console.log('Created lossless real-PDF fixture: ' + destination);
console.log(JSON.stringify({ questionSha256: fixture.questions.sha256, answerSha256: fixture.answers.sha256, byteLength: fs.statSync(destination).size }));
