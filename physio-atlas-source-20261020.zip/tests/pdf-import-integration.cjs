const assert=require('assert');
const fs=require('fs');
const vm=require('vm');
const Parser=require('../dist/parser-pipeline.js');

const html=fs.readFileSync(require('path').join(__dirname,'../dist/index.html'),'utf8');
const marker='<script src="parser-pipeline.js"></script><script>';
const start=html.indexOf(marker)+marker.length;
const end=html.indexOf('</script><style>',start);
if(start<marker.length||end<0)throw new Error('Cannot find import integration script');

const elements={};
function element(){return {textContent:'',disabled:false,onclick:null}}
function $(selector){return elements[selector]||(elements[selector]=element())}
const subjects=['物理治療基礎學','物理治療學概論','物理治療技術學','神經疾病物理治療學','骨科疾病物理治療學','心肺疾病與小兒疾病物理治療學'];
const sandbox={
  window:{PhysioPdfPipeline:Parser},document:{addEventListener:function(){},querySelector:function(){return null}},console:console,$:$,Q:[],S:subjects,
  canonicalSubject:function(value){return subjects.indexOf(value)>=0?value:subjects[0]},qSubject:function(q){return q.subject||q.topic||subjects[0]},qSession:function(q){return String(q.examSession||'')},qKeywords:function(q){return Array.isArray(q.keywords)?q.keywords:[]},
  detectExamMeta:function(){return {examYear:'115',examSession:'1',subject:subjects[4],examName:'115-1 骨科疾病物理治療學'}},findExactDuplicate:function(){return null},
  loadPdfJs:async function(){throw new Error('not used in integration test')},loadTesseract:async function(){throw new Error('not used in integration test')},saveAsset:async function(){return null},
  saveAll:function(){},renderBank:function(){},renderSubjects:function(){},renderSimilar:function(){},renderTrack:function(){},view:function(){},toast:function(){},
  esc:function(value){return String(value)},pdfQuestionFile:null,pdfAnswerFile:null,importDraft:null
};
sandbox.window.window=sandbox.window;
vm.runInNewContext(html.slice(start,end),sandbox,{filename:'pdf-import-integration.js'});
const api=sandbox.window.__physioImportPipeline;
assert(api,'Import integration API is unavailable');

const ninthRaw='9. 根據任務導向模式評估原則，下列那一個敘述最不符合其概念？ A. 應評估個案在執行功能性動作時所採用的動作策略 B. 應了解個案的功能限制與環境脈絡 C. 應只依單一肌力分數決定治療 D. 應觀察代償與任務表現';
const parsed=api.parseQuestionPdf({pages:[{page:1,text:ninthRaw}]},{},null,'question.pdf');
assert.strictEqual(parsed.length,1,'The ninth question must be discovered');
assert.strictEqual(parsed[0].q.includes('A.'),false,'A option must not remain in the stem');
assert.deepStrictEqual(Array.from(parsed[0].answers),['應評估個案在執行功能性動作時所採用的動作策略','應了解個案的功能限制與環境脈絡','應只依單一肌力分數決定治療','應觀察代償與任務表現']);
assert.strictEqual(parsed[0].structureStatus,'parsed');

const answers=api.parseAnswersPdf({pages:[{page:1,text:'9.C　10 A　11：D　12、B　13 (C)　14.Correct Answer A'}]});
assert.strictEqual(answers['9'].letter,'C','Answers must pair by question number');
assert.strictEqual(answers['10'].letter,'A','Space-separated answers must parse');
assert.strictEqual(answers['11'].letter,'D','Full-width-colon answers must parse');
assert.strictEqual(answers['12'].letter,'B','Enumeration-comma answers must parse');
assert.strictEqual(answers['13'].letter,'C','Parenthesized answers must parse');
assert.strictEqual(answers['14'].letter,'A','Correct Answer format must parse');
const item=api.buildImportItem(parsed[0],{subject:'骨科疾病物理治療學',subjectExplicit:true,examYear:'115',examSession:'1',examName:'115-1 骨科疾病物理治療學'},answers['9']);
assert.strictEqual(item.correctAnswer,'C');
assert.strictEqual(item.answerStatus,'matched');
assert.strictEqual(item.answerRawText,'9.C');
assert.strictEqual(item.subject,'骨科疾病物理治療學','The selected subject must remain authoritative');
assert.strictEqual(Object.prototype.hasOwnProperty.call(item,'category'),false,'Knowledge classification must not be stored');
assert.strictEqual(Object.prototype.hasOwnProperty.call(item,'keywords'),false,'Keywords must not be stored');
assert.strictEqual(Object.prototype.hasOwnProperty.call(item,'tags'),false,'Legacy tag fields must not be stored');
assert.strictEqual(item.q.includes('A.'),false);
assert(item.answers.every(Boolean));

const fullWidthQuestion=api.parseQuestionPdf({pages:[{page:1,text:'１．全形題號？ Ａ. 甲 Ｂ. 乙 Ｃ. 丙 Ｄ. 丁'}]},{},null,'full-width.pdf',1);
assert.strictEqual(fullWidthQuestion.length,1,'Full-width question numbering must be detected');
assert.strictEqual(String(fullWidthQuestion[0].questionNumber),'1','Full-width question numbers must normalize to a shared key');

const targetedVisual=api.parseQuestionPdf({pages:[{page:13,text:'41. 圖片題？ A. 一 B. 二 C. 三 D. 四 42. 文字題？ A. 甲 B. 乙 C. 丙 D. 丁',questionVisuals:[{assetId:'question-41-figure',kind:'question-visual',requiresAnswer:true,questionNumbers:[41],assignment:'question-band',assignmentConfidence:'high'}]}]},{},null,'targeted-visual.pdf',42);
assert.strictEqual(targetedVisual[0].questionImages[0].assignment,'question-band','A verified crop must keep its question-band assignment');
assert.strictEqual(targetedVisual[0].questionImages[0].assignmentConfidence,'high','A verified crop must keep its assignment confidence');
assert.strictEqual(targetedVisual[1].questionImages.length,0,'A verified crop must not leak into the next question');
const imageRules=sandbox.window.PhysioQuestionImageRules;
assert.strictEqual(imageRules.isRequired({assetId:'legacy-nearest',kind:'question-visual',requiresAnswer:true,questionNumbers:['41']},'41'),false,'Legacy nearest-page mappings must not render as a question image');
assert.strictEqual(imageRules.isRequired({assetId:'strict-band',kind:'question-visual',requiresAnswer:true,questionNumbers:['41'],assignment:'question-band'},'41'),true,'A question-band crop must render only for its own number');
assert.strictEqual(imageRules.isRequired({assetId:'question-region',kind:'question-visual',requiresAnswer:true,questionNumbers:['41'],assignment:'question-region'},'41'),true,'A same-question region crop must render when A-option coordinates are unavailable');
assert.strictEqual(imageRules.isRequired({assetId:'manual-image',kind:'image-scan-source',requiresAnswer:true,questionNumbers:['41'],assignment:'manual',userReviewed:true},'41'),true,'A user-reviewed image must retain manual rendering');
assert(html.includes('data-question-image-select'),'Import preview must offer manual question-image replacement');
assert(html.includes('data-question-image-review tabindex="0"'),'Import preview question-image area must accept keyboard focus for paste');
assert(html.includes("imageFromTransfer(event.dataTransfer)"),'Import preview must accept dragged question images');
assert(html.includes("imageFromTransfer(event.clipboardData)"),'Import preview must accept pasted question images');
assert(html.includes('data-question-image-edit'),'Question view must offer manual question-image replacement');

const quotedBoundary=api.parseQuestionPdf({pages:[{page:1,text:'20. 前一題？ A. 甲 B. 乙 C. 丙 D. 丁 21. 「陳小姐為 30 歲患者」下列何者正確？ A. 一 B. 二 C. 三 D. 四'}]},{},null,'quoted-boundary.pdf',21);
assert.deepStrictEqual(Array.from(quotedBoundary.map(item=>item.questionNumber)),[20,21],'A Chinese opening quote after the question number must start a new question');
assert.strictEqual(quotedBoundary[0].answers[3],'丁','The following quoted question must not remain in the previous D option');

const numericBoundary=api.parseQuestionPdf({pages:[{page:1,text:'46. 前一題？ A. T10 B. C7 C. L3 D. T12 47. 45 歲男性因車禍受傷，下列何者正確？ A. 一 B. 二 C. 三 D. 四'}]},{},null,'numeric-boundary.pdf',47);
assert.deepStrictEqual(Array.from(numericBoundary.map(item=>item.questionNumber)),[46,47],'A stem beginning with an age must not hide its question number');
assert.strictEqual(numericBoundary[0].answers[3],'T12','The following numeric stem must not remain in the previous D option');

const answerGridItems=[];
['A','D','B','C'].forEach((letter,index)=>{
  const y=700-index*22;
  answerGridItems.push({str:String(index+1),transform:[1,0,0,1,60,y],width:10});
  answerGridItems.push({str:'答案',transform:[1,0,0,1,260,y],width:22});
  answerGridItems.push({str:letter,transform:[1,0,0,1,310,y],width:10});
});
const tableAnswers=api.parseAnswersPdf({pages:[{page:1,text:'1 2 3 4 答案 A D B C',items:answerGridItems}]});
assert.deepStrictEqual(Array.from([1,2,3,4].map(number=>tableAnswers[String(number)].letter)),['A','D','B','C'],'Answer-table coordinates must pair every question number with its own letter');
assert.strictEqual(tableAnswers.diagnostics.sourceMode,'spatial','The table parser must win when it yields more answer records');

const officialAnswerTable=api.parseAnswersPdf({pages:[{page:1,text:'題序 01 02 03 04 05\n答案 Ｂ Ｂ Ｃ Ａ Ｄ\n題序 06 07 08 09 10\n答案 Ｃ Ａ Ｄ Ｂ Ｃ'}]});
assert.strictEqual(officialAnswerTable.diagnostics.answerCount,10,'A 題序/答案 table must expose every answer');
assert.strictEqual(officialAnswerTable.diagnostics.sourceMode,'table_text','The 題序/答案 row parser must be preferred for official answer sheets');
assert.deepStrictEqual(Array.from([1,2,3,4,5,6,7,8,9,10].map(number=>officialAnswerTable[String(number)].letter)),['B','B','C','A','D','C','A','D','B','C']);

const officialCorrectionTable=api.parseAnswersPdf({pages:[{page:1,text:'題序 01 02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20\n答案 Ｂ Ｂ Ｂ Ｂ Ｃ Ａ Ｃ Ｃ Ｃ Ｄ Ａ Ｃ Ｂ Ｃ ＃ Ｃ Ａ Ｂ Ａ Ｄ\n備註：第15題一律給分，第47題答Ｃ給分'}]});
assert.strictEqual(officialCorrectionTable['1'].letter,'B','# in a later cell must not shift the first answer');
assert.strictEqual(officialCorrectionTable['10'].letter,'D','# in a later cell must not shift any preceding answer');
assert.strictEqual(officialCorrectionTable['15'].allAnswersAccepted,true,'An official all-accepted correction must be retained');
assert.strictEqual(officialCorrectionTable['47'].letter,'C','A corrected note answer must override the # marker');
const allAcceptedItem=api.buildImportItem(parsed[0],{subject:'神經疾病物理治療學',subjectExplicit:true,examYear:'115',examSession:'1'},officialCorrectionTable['15']);
assert.strictEqual(allAcceptedItem.answerStatus,'all_answers_accepted','All-accepted corrections must not become a guessed A–D answer');

const expectedNumbers=Array.from({length:80},(_,index)=>index+1);
const intentionallyMissing=[17,28,46,59,63,77];
const eightyQuestionText=expectedNumbers.filter(number=>!intentionallyMissing.includes(number)).map(number=>`${number}. 第 ${number} 題題幹？ A. 甲 B. 乙 C. 丙 D. 丁`).join('\n');
const eightyQuestions=api.parseQuestionPdf({pages:[{page:1,text:eightyQuestionText}]},{},null,'80-questions.pdf',80);
const questionDiagnostics=api.questionDiagnostics(eightyQuestions,80);
assert.strictEqual(questionDiagnostics.detectedQuestionNumbers.length,74,'Question diagnostics must count every detected question');
assert.deepStrictEqual(Array.from(questionDiagnostics.missingQuestionNumbers),intentionallyMissing,'Question diagnostics must list the exact missing numbers');

const eightyAnswerText=expectedNumbers.map(number=>`${number}.${['A','B','C','D'][(number-1)%4]}`).join('　');
const eightyAnswers=api.parseAnswersPdf({pages:[{page:1,text:eightyAnswerText},{page:2,text:'第 １ 題：Ｂ  2 (C)  3.Correct Answer D'}]});
const answerDiagnostics=api.answerDiagnostics(eightyAnswers,eightyQuestions);
assert.strictEqual(answerDiagnostics.answerCount,80,'Answer parser must create an answersByNumber map for all 80 answers');
assert.strictEqual(answerDiagnostics.matchedQuestionNumbers.length,74,'Answers must match detected questions by normalized question-number key');
assert.strictEqual(eightyAnswers['9'].letter,'A','Number-string keys must remain matchable');
assert.strictEqual(eightyAnswers['1'].letter,'B','Full-width "第 １ 題：Ｂ" must normalize and replace the first answer');
assert.strictEqual(api.answerDiagnostics({},eightyQuestions).parseStatus,'parse_failed','Zero answers must be surfaced as an answer-PDF parsing failure');

function importVisualLayout(items,name){
  const grouped=Parser.groupPdfItemsIntoText(items,600);
  const markers=grouped.lines.filter(line=>/^\d+\./.test(line.text)).map(line=>({number:Number(line.text.match(/^\d+/)[0]),x:line.minX,y:line.y}));
  const plans=Parser.planOptionVisualRegions(grouped.lines,markers,600,800,grouped.usedColumns);
  const optionVisuals=plans.map(plan=>({assetId:`${name}-${plan.number}-${plan.letter}`,sourceAssetId:`${name}-${plan.number}-${plan.letter}-source-band`,letter:plan.letter,questionNumbers:[plan.number],assignment:plan.assignment}));
  return {grouped,plans,questions:api.parseQuestionPdf({pages:[{page:1,text:grouped.text,optionVisuals}]},{},null,name+'.pdf')};
}
function pdfText(str,x,y,width=12){return {str,transform:[1,0,0,1,x,y],width}}
const gridItems=[pdfText('31. 請依圖選擇正確姿勢？',40,760,340),pdfText('A.',50,690),pdfText('B.',330,690),pdfText('C.',50,420),pdfText('D.',330,420)];
const gridImport=importVisualLayout(gridItems,'wide-picture-grid');
assert.strictEqual(gridImport.plans.length,4,'Layout detection must plan all four A/B, C/D image-choice cells');
assert.deepStrictEqual(gridImport.plans.map(plan=>plan.letter),['A','B','C','D'],'The detected grid must preserve letter order through option planning');
assert.strictEqual(gridImport.plans[0].region.right,300,'A image crop must reach the page gutter instead of cutting the drawing at the midpoint of A/B labels');
assert.strictEqual(gridImport.plans[1].region.left,300,'B image crop must start at the page gutter');
assert.strictEqual(gridImport.questions[0].structureStatus,'parsed','The real layout-detection output must parse image-only choices successfully');
assert.strictEqual(gridImport.questions[0].q,'請依圖選擇正確姿勢？','A grid must not leave choice labels in the question stem');
assert.deepStrictEqual(gridImport.questions[0].optionImages.map(images=>images[0].assetId),['wide-picture-grid-31-A','wide-picture-grid-31-B','wide-picture-grid-31-C','wide-picture-grid-31-D'],'Every planned crop must map to its own option letter');
assert.deepStrictEqual(gridImport.questions[0].optionImages.map(images=>images[0].sourceAssetId),['wide-picture-grid-31-A-source-band','wide-picture-grid-31-B-source-band','wide-picture-grid-31-C-source-band','wide-picture-grid-31-D-source-band'],'Each option must retain its original full-band source for manual re-cropping');

const mixedGrid=importVisualLayout(gridItems.concat([
  pdfText('32. 左欄文字題？',40,260,160),pdfText('A. 甲 B. 乙 C. 丙 D. 丁',40,230,180),
  pdfText('33. 右欄文字題？',340,260,160),pdfText('A. 一 B. 二 C. 三 D. 四',340,230,180)
]),'grid-and-columns');
assert.strictEqual(mixedGrid.grouped.usedColumns,true,'A wide image grid must preserve the page\'s separate question columns');
assert.deepStrictEqual(mixedGrid.questions.map(question=>question.questionNumber),[31,32,33],'The grid and neighboring independent column questions must all remain distinct');
assert(mixedGrid.questions.every(question=>question.structureStatus==='parsed'),'Both image-grid and text-column questions must parse');
assert(mixedGrid.questions.slice(1).every(question=>question.optionImages.every(images=>images.length===0)),'Grid crops must not leak into neighboring column questions');

const separateColumnItems=[pdfText('34. 左欄圖片題？',40,760,160),pdfText('35. 右欄圖片題？',340,760,160)];
['A','B','C','D'].forEach((letter,index)=>{separateColumnItems.push(pdfText(letter+'.',40,690-index*110),pdfText(letter+'.',340,690-index*110))});
const separateColumns=importVisualLayout(separateColumnItems,'independent-picture-columns');
assert.strictEqual(separateColumns.grouped.usedColumns,true,'Two independently numbered question columns must retain column reading order');
assert.strictEqual(separateColumns.plans.length,8,'Each of two independent columns must retain all four image-choice regions');
assert(separateColumns.plans.filter(plan=>plan.number===34).every(plan=>plan.region.right<=300),'Left-column image choices must not extend into the right question');
assert(separateColumns.plans.filter(plan=>plan.number===35).every(plan=>plan.region.left>=300),'Right-column image choices must not extend into the left question');
assert(separateColumns.questions.every(question=>question.structureStatus==='parsed'&&question.optionImages.every(images=>images.length===1)),'Every separate-column image-only choice must map and validate');

console.log('PASS integration: #9 is structurally split, matched by number, without knowledge classification or keywords');
console.log('PASS integration: 74/80 detection reports the six exact missing numbers; 80 answer keys pair by normalized number');
console.log('PASS integration: Chinese-quote boundaries and coordinate answer tables retain every question and answer key');
console.log('PASS integration: numeric stems and official 題序／答案 rows preserve all 80-style records');
console.log('PASS integration: same-question image crops render automatically; manual image overrides remain available');
console.log('PASS integration: A/B,C/D image grids preserve crop boundaries, option mapping, and neighboring independent columns');
