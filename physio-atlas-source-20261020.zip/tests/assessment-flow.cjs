const assert = require('assert');
const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('dist/index.html', 'utf8');
const feature = html.match(/var R=read\('physio-atlas-test-records',\[\]\);[\s\S]*?<\/script>(?=\s*<style>\s*\/\* 錯題模式)/);
assert(feature, '找不到交卷式測驗功能程式');

const context = {
  console,
  Date,
  Math,
  JSON,
  Array,
  Number,
  String,
  Object,
  setTimeout,
  clearTimeout,
  Q: [],
  P: {},
  st: {},
  $: () => null,
  read: () => [],
  put: () => {},
  saveAll: () => {},
  renderTrack: () => {},
  renderBank: () => {},
  renderBranchLanding: () => {},
  qSubject: question => question.subject || '',
  examBranch: question => question.branch || '',
  pr: () => ({}),
  today: () => 0,
  esc: value => String(value || ''),
  toast: () => {},
  view: () => {},
  confirm: () => true,
  document: {
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener: () => {},
  },
  window: {
    scrollTo: () => {},
  },
};
context.globalThis = context;
vm.createContext(context);
vm.runInContext(feature[0].replace(/<\/script>$/, ''), context);

const test = {
  questions: [
    { id: 1, questionNumber: 1, q: '第一題', correct: 0 },
    { id: 2, questionNumber: 2, q: '第二題', correct: 1 },
    { id: 3, questionNumber: 3, q: '第三題', allAnswersAccepted: true },
    { id: 4, questionNumber: 4, q: '第四題', correct: null },
  ],
  answers: [0, 0, 2, null],
};
const result = context.window.PhysioAssessment.calculate(test);
assert.deepStrictEqual(JSON.parse(JSON.stringify({
  total: result.total,
  graded: result.graded,
  correct: result.correct,
  answered: result.answered,
  percent: result.percent,
  firstGood: result.details[0].good,
  secondGood: result.details[1].good,
  thirdGood: result.details[2].good,
  fourthGradable: result.details[3].gradable,
})), {
  total: 4,
  graded: 3,
  correct: 2,
  answered: 3,
  percent: 67,
  firstGood: true,
  secondGood: false,
  thirdGood: true,
  fourthGradable: false,
});

assert(html.includes('data-exam-start'), '開始作答沒有獨立測驗入口');
assert(html.includes('data-test-submit'), '缺少交卷按鈕');
assert(html.includes('testRecords:copy('), '測驗紀錄沒有加入同步快照');
assert(html.includes('testRecords:mergeRecords('), '測驗紀錄沒有加入同步合併');
assert(html.includes('data-v="wrongmode"'), '缺少錯題模式入口');
assert(html.includes("correctRate(question)<.67"), '常錯題目沒有依正確率篩選');
assert(html.includes("lastWrongAt"), '錯題模式沒有保存最近答錯時間');
assert(html.includes('latestWrongAt'), '最近答錯時間沒有納入跨裝置同步合併');
assert(html.includes('sandbox:!!config.sandbox'), '測試模式沒有建立獨立狀態');
assert(html.includes("if(test.sandbox){renderAssessment();toast('測試完成；本次結果不會影響學習紀錄。');return;}"), '測試模式交卷仍可能寫入正式紀錄');
assert(html.includes('data-learning-reset'), '缺少重新開始累積按鈕');
assert(html.includes('learningResetAt'), '清除紀錄沒有納入跨裝置同步');
assert(html.includes('pruneProgress'), '清除紀錄沒有排除舊的作答資料');

const wrongFeature = html.match(/\/\* 錯題模式保留歷史錯題，並用既有作答進度計算今日、近期與常錯清單。 \*\/[\s\S]*?<\/script>(?=\s*<style>\s*\/\* 獨立測試模式)/);
assert(wrongFeature, '找不到錯題模式功能程式');
const now = new Date().toISOString();
const wrongContext = {
  console,
  Date,
  Math,
  JSON,
  Array,
  Number,
  String,
  Object,
  P: {
    one: { attempts: 4, wrong: 3, lastWrongAt: now },
    two: { attempts: 2, wrong: 1 },
    three: { attempts: 5, wrong: 1, lastWrongAt: now },
  },
  Q: [
    { id: 'one', subject: '骨科疾病物理治療學', examYear: '115' },
    { id: 'two', subject: '骨科疾病物理治療學', examYear: '114' },
    { id: 'three', subject: '神經疾病物理治療學', examYear: '115' },
  ],
  S: ['骨科疾病物理治療學', '神經疾病物理治療學'],
  $: () => null,
  setpr: () => {},
  pr(question) { return wrongContext.P[question.id] || {}; },
  qSubject: question => question.subject || '',
  examBranch: () => '',
  esc: value => String(value || ''),
  toast: () => {},
  view: () => {},
  st: {},
  document: {
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener: () => {},
  },
  window: {
    scrollTo: () => {},
    PhysioAssessment: { startCustom: () => true },
  },
};
wrongContext.globalThis = wrongContext;
vm.createContext(wrongContext);
vm.runInContext(wrongFeature[0].replace(/<\/script>$/, ''), wrongContext);
assert.deepStrictEqual(
  JSON.parse(JSON.stringify(wrongContext.window.PhysioWrongMode.items('today').map(question => question.id))),
  ['one', 'three'],
);
assert.deepStrictEqual(
  JSON.parse(JSON.stringify(wrongContext.window.PhysioWrongMode.items('frequent').map(question => question.id))),
  ['one', 'two'],
);
assert.strictEqual(wrongContext.window.PhysioWrongMode.correctRate(wrongContext.Q[2]), 0.8);

console.log('PASS assessment flow: hidden answers, scoring, records, sync hooks, and wrong-mode filters');
