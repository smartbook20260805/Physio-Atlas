const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { File: BufferFile } = require('node:buffer');

// Execute the actual shared cropper, not a copied implementation.
const html = fs.readFileSync(path.join(__dirname, '../dist/index.html'), 'utf8');
const start = html.indexOf('var cropState=null,cropReturnFocus=null,closeBeforeCropFocus=close;');
const end = html.indexOf("$('#captureScreen').onclick=", start);
assert.ok(start >= 0 && end > start, 'the shared cropper source must be present');
const code = html.slice(start, end);
const FileClass = globalThis.File || BufferFile;
const photo = (name) => new FileClass(['source:' + name], name, { type: 'image/png' });

function harness() {
  const readers = [];
  const encoders = [];
  const sourceAssignments = [];
  const toasts = [];
  const recognized = [];
  const keys = new Map();
  const classes = new Set();
  const trigger = { focusCount: 0, focus() { this.focusCount++; } };
  const control = () => ({ disabled: false, textContent: '', focusCount: 0, focus() { this.focusCount++; } });
  const use = control();
  const cancel = control();
  const image = { style: {}, clientWidth: 100, clientHeight: 120, naturalWidth: 1000, naturalHeight: 1200 };
  Object.defineProperty(image, 'src', {
    get() { return sourceAssignments.at(-1); },
    set(value) { sourceAssignments.push(value); },
  });
  const modal = {
    classList: { add: (name) => classes.add(name), remove: (name) => classes.delete(name), contains: (name) => classes.has(name) },
    querySelectorAll: () => [cancel, use],
    contains: (node) => node === use || node === cancel,
  };
  const nodes = {
    '#cropmodal': modal, '#cropImage': image, '#cropUse': use, '#cropBox': { style: {} },
    '#cropStage': { getBoundingClientRect: () => ({ left: 0, top: 0, width: 100, height: 120 }), setPointerCapture() {} },
    '#cropmodal .dhead h2': control(), '#cropmodal .dhead p': control(),
    '#cropmodal [data-close="cropmodal"]': cancel, '#ocrMsg': control(),
  };
  const context = {
    File: FileClass, Blob, Promise, Date,
    FileReader: class {
      constructor() { readers.push(this); }
      readAsDataURL(file) { this.file = file; }
    },
    $: (selector) => nodes[selector],
    open: (id) => nodes['#' + id].classList.add('open'),
    close: (id) => nodes['#' + id].classList.remove('open'),
    toast: (text) => toasts.push(text),
    requestAnimationFrame: (callback) => callback(),
    recognizeQuestionImage: (file, source) => recognized.push({ file, source }),
    document: {
      activeElement: trigger,
      contains: (node) => node === trigger || node === cancel || node === use,
      querySelector: (selector) => nodes[selector],
      addEventListener: (type, callback) => keys.set(type, callback),
      createElement(tag) {
        assert.equal(tag, 'canvas');
        const encoder = { source: null };
        const canvas = {
          getContext: () => ({ drawImage: (source) => { encoder.source = source.src; } }),
          toBlob(callback) { encoder.resolve = callback; encoders.push(encoder); },
        };
        return canvas;
      },
    },
  };
  vm.createContext(context);
  vm.runInContext(code, context, { filename: 'dist/index.html shared cropper' });
  function load(index) {
    const reader = readers[index];
    reader.result = 'data:' + reader.file.name;
    reader.onload();
  }
  function decode() { image.onload(); }
  function resolve(index, value = new Blob(['encoded:' + encoders[index].source], { type: 'image/png' })) {
    encoders[index].resolve(value);
  }
  return {
    context, readers, encoders, sourceAssignments, toasts, recognized, use, image, trigger,
    load, decode, resolve, isOpen: () => classes.has('open'),
  };
}

const cases = [];
function test(name, run) { cases.push({ name, run }); }

test('reversed FileReader completion cannot overwrite a later option crop', async () => {
  const h = harness();
  const accepted = [];
  let canceledA = 0;
  h.context.openCropper(photo('A.png'), () => accepted.push('A'), () => canceledA++);
  h.context.openCropper(photo('B.png'), () => accepted.push('B'));
  assert.equal(canceledA, 1, 'superseding the first crop cancels its owner once');
  assert.equal(h.isOpen(), true, 'crop dialog opens before FileReader completes');
  assert.equal(h.use.disabled, true);
  h.load(1);
  h.load(0);
  assert.deepEqual(h.sourceAssignments, ['data:B.png']);
  h.decode();
  assert.equal(h.image.style.visibility, 'visible');
  assert.equal(h.use.disabled, false);
  const saving = h.use.onclick();
  assert.equal(h.encoders[0].source, 'data:B.png');
  h.resolve(0);
  await saving;
  assert.deepEqual(accepted, ['B']);
});

test('canceled reader callbacks neither reopen nor close the next crop', () => {
  const h = harness();
  let canceledA = 0;
  h.context.openCropper(photo('A.png'), () => {}, () => canceledA++);
  h.context.close('cropmodal');
  assert.equal(h.isOpen(), false);
  h.load(0);
  assert.deepEqual(h.sourceAssignments, []);
  assert.equal(h.isOpen(), false, 'late load must not reopen a canceled dialog');
  h.context.openCropper(photo('B.png'), () => {});
  h.readers[0].onerror();
  assert.equal(h.isOpen(), true, 'stale reader error must not close the new dialog');
  assert.deepEqual(h.toasts, []);
  h.load(1); h.decode();
  assert.equal(h.context.cropState.file.name, 'B.png');
  assert.equal(canceledA, 1);
});

test('an old image decode event cannot enable a new crop before its reader completes', () => {
  const h = harness();
  h.context.openCropper(photo('A.png'), () => {});
  h.load(0);
  // The HTMLImageElement is shared: a queued load of A may invoke the newly
  // installed B handler after the next crop is opened.
  h.context.openCropper(photo('B.png'), () => {});
  h.decode();
  assert.equal(h.use.disabled, true, 'B must remain unavailable until B has an assigned image source');
  assert.equal(h.image.style.visibility, 'hidden');
  h.load(1); h.decode();
  assert.equal(h.use.disabled, false);
  assert.equal(h.image.src, 'data:B.png');
});

test('pending old toBlob cannot invoke a new question callback or close its crop', async () => {
  const h = harness();
  const accepted = [];
  let canceledA = 0;
  h.context.openCropper(photo('question-1-A.png'), () => accepted.push('question-1-A'), () => canceledA++);
  h.load(0); h.decode();
  const firstSave = h.use.onclick();
  assert.equal(h.use.disabled, true);
  h.context.close('cropmodal');
  h.context.openCropper(photo('question-2-D.png'), () => accepted.push('question-2-D'));
  h.load(1); h.decode();
  h.resolve(0);
  await firstSave;
  assert.deepEqual(accepted, [], 'old encoding must not invoke either callback');
  assert.equal(canceledA, 1);
  assert.equal(h.isOpen(), true);
  assert.equal(h.context.cropState.file.name, 'question-2-D.png');
  assert.equal(h.use.disabled, false, 'old encoding must not disable the new crop');
  const secondSave = h.use.onclick();
  h.resolve(1);
  await secondSave;
  assert.deepEqual(accepted, ['question-2-D']);
});

test('accepted manual crop calls onUse exactly once and never calls onCancel', async () => {
  const h = harness();
  let accepted = 0, canceled = 0;
  let result;
  h.context.openCropper(photo('A.png'), (file) => { accepted++; result = file; }, () => canceled++);
  h.load(0); h.decode();
  const saving = h.use.onclick();
  const repeated = h.use.onclick();
  assert.equal(h.encoders.length, 1, 'double click must not create duplicate image writes');
  h.resolve(0);
  await Promise.all([saving, repeated]);
  assert.equal(accepted, 1);
  assert.equal(canceled, 0);
  assert.equal(result.type, 'image/png');
  assert.equal(h.isOpen(), false);
  assert.equal(h.context.cropState, null);
  h.context.close('cropmodal');
  assert.equal(canceled, 0, 'closing an already accepted dialog must not cancel its owner');
  assert.equal(h.trigger.focusCount, 1);
});

test('failed image encoding keeps the same crop available for retry', async () => {
  const h = harness();
  let accepted = 0, canceled = 0;
  h.context.openCropper(photo('A.png'), () => accepted++, () => canceled++);
  h.load(0); h.decode();
  const saving = h.use.onclick();
  h.resolve(0, null);
  await saving;
  assert.equal(h.isOpen(), true);
  assert.equal(h.use.disabled, false);
  assert.equal(accepted, 0);
  assert.equal(canceled, 0);
  assert.match(h.toasts[0], /無法建立/);
  const retry = h.use.onclick();
  h.resolve(1);
  await retry;
  assert.equal(accepted, 1);
  assert.equal(canceled, 0);
});

test('accepted OCR crop retains its original workflow without cancellation', async () => {
  const h = harness();
  let canceled = 0;
  h.context.openCropper(photo('ocr.png'), null, () => canceled++);
  h.load(0); h.decode();
  const saving = h.use.onclick();
  h.resolve(0);
  await saving;
  assert.equal(canceled, 0);
  assert.equal(h.recognized.length, 1);
  assert.equal(h.recognized[0].source, '截圖範圍');
  assert.equal(h.recognized[0].file, h.context.file);
});

(async () => {
  for (const entry of cases) {
    await entry.run();
    console.log('PASS ' + entry.name);
  }
  console.log(`PASS ${cases.length} shared-crop ownership regressions`);
})().catch((error) => { console.error(error); process.exitCode = 1; });
