const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const Parser = require('../dist/parser-pipeline.js');

const html = fs.readFileSync(path.join(__dirname, '../dist/index.html'), 'utf8');
const marker = '<script src="parser-pipeline.js"></script><script>';
const start = html.indexOf(marker) + marker.length;
const end = html.indexOf('</script><style>', start);
assert.ok(start >= marker.length && end >= 0, 'the actual PDF import controller is available');
const controller = html.slice(start, end);
const subjects = ['物理治療基礎學', '物理治療學概論', '物理治療技術學', '神經疾病物理治療學', '骨科疾病物理治療學', '心肺疾病與小兒疾病物理治療學'];
const copy = (value) => JSON.parse(JSON.stringify(value));
const compact = (value) => String(value).replace(/\s+/g, '');
function assertIonicChoices(answers) {
  ['Na⁺', 'Ca²⁺', 'K⁺', 'Cl⁻'].forEach((compound, index) => {
    assert.ok(answers[index].includes(compound), 'the ' + compound + ' compound stays contiguous in its own option');
  });
  assert.deepEqual(copy(answers.map(compact)), ['Na⁺通道', 'Ca²⁺釋放', 'K⁺通道', 'Cl⁻通道']);
}

// Stem transcribed from the user's screenshot. Its wording is intentionally
// retained verbatim, not clinically corrected. The screenshot supplied no
// official A-D choices or answer: every choice/answer below is synthetic and
// tests character ownership only, not the medical correctness of an answer.
const screenshotStem = '骨骼肌的興奮－收縮偶合（excitation-contraction coupling）過程的正確順序為何？①體運動神經元釋放乙醯膽鹼　②橫小管電位閘控Ca²⁺通道開啟　③肌漿網Ca²⁺釋放通道開啟　④肌漿膜電位閘控Na⁺通道開啟　⑤肌原纖維內Ca²⁺與旋轉素結合';
// Unlike the preceding screenshot, the user's later screenshot supplies these
// four actual choice strings. It still supplies no official correct answer.
const screenshotChoices = ['①③④②⑤', '①②③④⑤', '①④②③⑤', '①④③②⑤'];

function assertScreenshotChoices(question) {
  assert.equal(question.structureStatus, 'parsed');
  assert.deepEqual(copy(question.answers), screenshotChoices, 'each screenshot sequence is preserved exactly in its own A-D choice');
  assert.deepEqual(copy(question.parsedOptions), { A: screenshotChoices[0], B: screenshotChoices[1], C: screenshotChoices[2], D: screenshotChoices[3] });
}

function pdfText(str, x, y, width, height = 12, omitHeight = false) {
  const item = { str, width, transform: [height, 0, 0, height, x, y] };
  if (!omitHeight) item.height = height;
  return item;
}
function chargeRow(label, base, script, suffix, x, y, shift = 6, omitHeight = false) {
  const first = label + base;
  const width = first.length * 6;
  return [
    pdfText(first, x, y, width),
    pdfText(script, x + width, y + shift, script.length * 3.5, 7, omitHeight),
    pdfText(suffix, x + width + script.length * 3.5, y, suffix.length * 9),
  ];
}
function ionicQuestion(number = 1, x = 40, y = 730, shift = 6, omitHeight = false) {
  return chargeRow(number + '. ', 'Ca', '2+', '通道與離子移動，何者符合圖示？', x, y, shift, omitHeight).concat(
    chargeRow('A. ', 'Na', '+', '通道', x, y - 30, shift, omitHeight),
    chargeRow('B. ', 'Ca', '2+', '釋放', x, y - 60, shift, omitHeight),
    chargeRow('C. ', 'K', '+', '通道', x, y - 90, shift, omitHeight),
    chargeRow('D. ', 'Cl', '-', '通道', x, y - 120, shift, omitHeight),
  );
}
function circledQuestion(number = 1, raised = 4) {
  // Keep a genuine column gutter when two such short stems share a page.
  // This fixture targets circle ownership, not the existing gutter heuristic.
  const items = [pdfText(number + '. 過程的正確順序為何？', 40, 730, 180)];
  screenshotChoices.forEach((sequence, index) => {
    const baseline = 700 - index * 30;
    items.push(pdfText(String.fromCharCode(65 + index) + '.', 40, baseline, 14));
    Array.from(sequence).forEach((glyph, glyphIndex) => {
      items.push(pdfText(glyph, 54 + glyphIndex * 12, baseline + raised, 12));
    });
  });
  return items;
}
function groupedQuestion(items, expected = 1) {
  const grouped = Parser.groupPdfItemsIntoText(items, 600);
  const questions = Parser.parseQuestionPages([{ page: 1, text: grouped.text, items }], 'source-pdf', 'scientific-fixture.pdf', expected);
  return { grouped, questions };
}

function harness(sourcePages = [], options = {}) {
  const elements = new Map();
  const toasts = [];
  let saved = null;
  let workerTerminated = false;
  function $(selector) {
    if (!elements.has(selector)) elements.set(selector, { textContent: '', innerHTML: '', disabled: false, onclick: null });
    return elements.get(selector);
  }
  const pdf = {
    numPages: sourcePages.length,
    async getPage(number) {
      return {
        getTextContent: async () => ({ items: sourcePages[number - 1] }),
        getViewport: ({ scale }) => ({ width: 600 * scale, height: 800 * scale }),
        getOperatorList: async () => ({ fnArray: [], argsArray: [] }),
        // This is a text extraction fixture, not an actual PDF raster test.
        // Deliberately skip optional image crops while exercising readPdf's
        // real getTextContent → geometry → page cleanup code path.
        render: () => ({ promise: options.ocrResult ? Promise.resolve() : Promise.reject(new Error('Raster intentionally unavailable in text fixture')) }),
      };
    },
  };
  const context = {
    console, Promise, Set, Date, Math, Uint8Array, $,
    Q: [], S: subjects, importDraft: null, pdfQuestionFile: null, pdfAnswerFile: null,
    window: { PhysioPdfPipeline: Parser },
    document: {
      addEventListener() {}, querySelector: () => null,
      createElement: () => ({
        width: 0, height: 0,
        getContext: () => ({ getImageData: (x, y, width, height) => ({ data: new Uint8ClampedArray(width * height * 4).fill(255) }) }),
      }),
    },
    canonicalSubject: (value) => subjects.includes(value) ? value : subjects[0],
    qSubject: (item) => item.subject || subjects[0], qSession: (item) => String(item.examSession || ''), qKeywords: () => [],
    detectExamMeta: () => ({ subject: subjects[0], examYear: '115', examSession: '1', examName: '115-1' }),
    findExactDuplicate: () => null,
    loadPdfJs: async () => ({ OPS: {}, getDocument: () => ({ promise: Promise.resolve(pdf) }) }),
    loadTesseract: async () => {
      assert.ok(options.ocrResult, 'Text-based fixtures must not require OCR');
      return { createWorker: async () => ({ recognize: async () => options.ocrResult, terminate: async () => { workerTerminated = true; } }) };
    },
    saveAsset: async () => null,
    saveAll: () => { saved = JSON.stringify(context.Q); },
    renderBank() {}, renderSubjects() {}, renderSimilar() {}, renderTrack() {}, view() {},
    toast: (message) => toasts.push(message), esc: (value) => String(value),
  };
  context.window.window = context.window;
  vm.createContext(context);
  vm.runInContext(controller, context, { filename: 'scientific-real-import-controller.js' });
  context.renderImport = () => {};
  const api = context.window.__physioImportPipeline;
  assert.ok(api, 'the actual import pipeline API is exposed');
  function commit(questions, answerRecords) {
    const meta = { subject: subjects[0], subjectExplicit: true, examYear: '115', examSession: '1' };
    const items = questions.map((base) => api.buildImportItem(base, meta, answerRecords === undefined
      ? { letter: 'B', rawText: base.questionNumber + '.B', parsedAnswer: 'B' }
      : answerRecords[String(base.questionNumber)] || null));
    context.importDraft = { busy: false, selected: 0, items, answers: {}, meta };
    context.applyImport();
    return { items, bank: context.Q, stored: saved ? JSON.parse(saved) : [] };
  }
  return { context, api, commit, toasts, file: { name: 'synthetic-scientific.pdf', arrayBuffer: async () => new ArrayBuffer(8) }, get workerTerminated() { return workerTerminated; } };
}

const cases = [];
function test(name, run) { cases.push({ name, run }); }

test('screenshot stem and Unicode scientific symbols survive parsing, manual validation, and JSON storage', () => {
  const answers = ['①②③④⑤；Ca²⁺、Na⁺', '⑤④③②①；K⁺、Cl⁻', 'm²；m/s²；37 °C', '50 µA；50 μA；120 mmHg；CO₂'];
  const raw = '1. ' + screenshotStem + ' A. ' + answers[0] + ' B. ' + answers[1] + ' C. ' + answers[2] + ' D. ' + answers[3];
  const parsed = Parser.parseQuestionPages([{ page: 1, text: raw }], 'source-pdf', 'screenshot-transcript.pdf', 1);
  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].structureStatus, 'parsed');
  const stem = Parser.normalizeText(screenshotStem);
  assert.equal(parsed[0].q, stem);
  assert.deepEqual(copy(parsed[0].answers), answers);
  const h = harness();
  const result = h.commit(parsed);
  assert.equal(result.stored.length, 1);
  assert.equal(result.stored[0].q, stem);
  assert.deepEqual(result.stored[0].answers, answers);
  assert.equal(result.stored[0].parsedQuestion, stem);
  assert.deepEqual(result.stored[0].parsedOptions, { A: answers[0], B: answers[1], C: answers[2], D: answers[3] });
  for (const symbol of ['Ca²⁺', 'Na⁺', '①', '⑤']) assert.ok(result.stored[0].ocrRawText.includes(symbol), 'raw transcript retains ' + symbol);
});

test('PDF.js superscript charge fragments attach to their own stem and A-D choice instead of the previous row', () => {
  const items = ionicQuestion();
  const original = copy(items);
  const { grouped, questions } = groupedQuestion(items);
  assert.deepEqual(items, original, 'layout reconstruction must not mutate original PDF items');
  assert.equal(questions.length, 1);
  assert.equal(questions[0].structureStatus, 'parsed');
  assert.ok(questions[0].q.includes('Ca²⁺'), 'the leading stem charge is not sorted before and lost outside question 1');
  assertIonicChoices(questions[0].answers);
  assert.equal(grouped.lines.length, 5, 'five visual baselines remain five complete text rows');
  assert.ok(items.some((item) => item.str === '2+'), 'source glyphs remain plain 2+ before geometry-derived formatting');
});

test('small +3 baseline offsets and missing height still use reduced font geometry to restore superscripts', () => {
  const { questions } = groupedQuestion(ionicQuestion(2, 40, 730, 3, true), 2);
  assert.equal(questions.length, 1);
  assert.equal(questions[0].questionNumber, 2);
  assert.ok(questions[0].q.includes('Ca²⁺'));
  assertIonicChoices(questions[0].answers);
});

test('subscript gas notation and raised area/acceleration powers preserve their position and values', () => {
  const items = [pdfText('3. 氣體、面積與加速度的單位為何？', 40, 730, 240)].concat(
    chargeRow('A. ', 'CO', '2', '分壓', 40, 700, -4),
    chargeRow('B. ', 'O', '2', '濃度', 40, 670, -4),
    chargeRow('C. ', 'm', '2', '面積', 40, 640, 6),
    chargeRow('D. ', 'm/s', '2', '加速度', 40, 610, 6),
  );
  const { questions } = groupedQuestion(items, 3);
  assert.equal(questions.length, 1);
  assert.deepEqual(copy(questions[0].answers.map(compact)), ['CO₂分壓', 'O₂濃度', 'm²面積', 'm/s²加速度']);
  ['CO₂', 'O₂', 'm²', 'm/s²'].forEach((compound, index) => assert.ok(questions[0].answers[index].includes(compound), 'no whitespace is introduced inside ' + compound));
  assert.equal(questions[0].structureStatus, 'parsed');
});

test('normal-baseline numbers remain normal, quantity gaps remain spaces, and nearby real rows stay separate', () => {
  const items = [
    pdfText('4. 閱讀數值2+與單位？', 40, 730, 168),
    pdfText('A. 2+', 40, 700, 34), pdfText('原始普通數字', 75, 700, 90),
    pdfText('B. 35', 40, 670, 34), pdfText('mmHg', 80, 670, 35),
    pdfText('C. 37', 40, 640, 34), pdfText('°C', 80, 640, 15),
    pdfText('D. 0.5', 40, 610, 40), pdfText('µA', 85, 610, 15),
    pdfText('延續文字保持在D', 40, 592, 140),
  ];
  const { grouped, questions } = groupedQuestion(items, 4);
  assert.equal(questions.length, 1);
  assert.ok(questions[0].q.includes('數值2+'));
  assert.ok(!questions[0].q.includes('數值²⁺'), 'ordinary typeset 2+ must not be guessed into a superscript');
  assert.match(questions[0].answers[0], /^2\+\s*原始普通數字$/);
  assert.equal(questions[0].answers[1], '35 mmHg');
  assert.equal(questions[0].answers[2], '37 °C');
  assert.match(questions[0].answers[3], /^0\.5 µA\s+延續文字保持在D$/);
  assert.equal(grouped.lines.length, 6, 'an ordinary lower row is not misattached as a script');
});

test('two real question columns retain their own superscripts and never attach a right-column ion to the left', () => {
  const items = ionicQuestion(5, 30, 730).concat(ionicQuestion(6, 335, 730));
  const { grouped, questions } = groupedQuestion(items, 6);
  assert.equal(grouped.usedColumns, true);
  assert.deepEqual(copy(questions.map((question) => question.questionNumber)), [5, 6]);
  for (const question of questions) {
    assert.ok(question.q.includes('Ca²⁺'));
    assertIonicChoices(question.answers);
    assert.equal(question.structureStatus, 'parsed');
  }
});

test('two-column page keeps a markerless full A-D continuation before the next right-column question', () => {
  const items = [pdfText('跨頁接續題幹內容', 40, 700, 180), pdfText('22. 右欄新題？', 340, 700, 180)];
  ['甲', '乙', '丙', '丁'].forEach((choice, index) => {
    const y = 675 - index * 25;
    items.push(pdfText(String.fromCharCode(65 + index) + '. ' + choice, 40, y, 100));
    items.push(pdfText(String.fromCharCode(65 + index) + '. ' + ['一', '二', '三', '四'][index], 340, y, 100));
  });
  const original = copy(items), grouped = Parser.groupPdfItemsIntoText(items, 600);
  const firstPage = { page: 1, text: '21. 題幹跨頁，請選出正確敘述？' };
  const rowOrder = grouped.lines.slice().sort((a, b) => b.y - a.y || a.minX - b.minX).map((line) => line.text).join('\n');
  const broken = Parser.parseQuestionPages([firstPage, { page: 2, text: rowOrder }], null, 'row-order-continuation.pdf', 22);
  assert.notEqual(broken.find((question) => question.questionNumber === 21).structureStatus, 'parsed', 'visual row order is demonstrably wrong for independent cross-page columns');
  assert.equal(grouped.usedColumns, true, 'the continued left question needs no repeated number when both independent A-D streams are present');
  assert.deepEqual(items, original, 'column detection preserves the original PDF glyph geometry');
  const parsed = Parser.parseQuestionPages([firstPage, { page: 2, text: grouped.text, items }], null, 'continued-two-column.pdf', 22);
  assert.deepEqual(copy(parsed.map((question) => question.questionNumber)), [21, 22]);
  assert.ok(parsed.every((question) => question.structureStatus === 'parsed'));
  assert.ok(compact(parsed[0].q).endsWith('跨頁接續題幹內容'));
  assert.deepEqual(copy(parsed[0].answers), ['甲', '乙', '丙', '丁']);
  assert.deepEqual(copy(parsed[1].answers), ['一', '二', '三', '四']);
});

test('two-column C-D continuation retains the preceding page A-B choices and never leaks into the new right question', () => {
  const firstPage = { page: 1, text: '21. 題幹跨頁？ A. 甲 B. 乙' };
  const items = [
    pdfText('續行屬於B', 40, 730, 180), pdfText('C. 丙', 40, 700, 100), pdfText('D. 丁', 40, 670, 100),
    pdfText('22. 右欄新題？', 340, 730, 180),
    ...['一', '二', '三', '四'].map((choice, index) => pdfText(String.fromCharCode(65 + index) + '. ' + choice, 340, 700 - index * 30, 100)),
  ];
  const grouped = Parser.groupPdfItemsIntoText(items, 600);
  const rowOrder = grouped.lines.slice().sort((a, b) => b.y - a.y || a.minX - b.minX).map((line) => line.text).join('\n');
  const broken = Parser.parseQuestionPages([firstPage, { page: 2, text: rowOrder }], null, 'row-order-cd-continuation.pdf', 22);
  assert.notEqual(broken.find((question) => question.questionNumber === 21).structureStatus, 'parsed', 'row order loses the left C-D boundaries after the right question starts');
  assert.equal(grouped.usedColumns, true, 'a consecutive C-D continuation and independent full A-D stream are two real question columns');
  const parsed = Parser.parseQuestionPages([firstPage, { page: 2, text: grouped.text, items }], null, 'continued-cd-two-column.pdf', 22);
  assert.deepEqual(copy(parsed.map((question) => question.questionNumber)), [21, 22]);
  assert.ok(parsed.every((question) => question.structureStatus === 'parsed'));
  assert.deepEqual(copy(parsed[0].answers.map(compact)), ['甲', '乙續行屬於B', '丙', '丁']);
  assert.deepEqual(copy(parsed[1].answers), ['一', '二', '三', '四']);
});

test('single-column wide stems with short options and isolated right-side charge glyphs are not question columns', () => {
  const items = [22, 23].flatMap((number, index) => {
    const y = 730 - index * 200;
    return [
      pdfText(number + '. 題幹很長，包含Ca離子的描述與其他完整內容，何者正確？', 40, y, 500),
      pdfText('2+', 520, y - 10, 10, 9),
      ...['甲', '乙', '丙', '丁'].map((choice, option) => pdfText(String.fromCharCode(65 + option) + '. ' + choice, 40, y - 30 - option * 30, 100)),
    ];
  });
  const original = copy(items), grouped = Parser.groupPdfItemsIntoText(items, 600);
  assert.equal(grouped.usedColumns, false, 'geometric isolation of short choices and charges alone is insufficient column evidence');
  assert.deepEqual(items, original);
  assert.equal(grouped.lines.filter((line) => line.text === '2+').length, 2, 'distant charge glyphs stay raw instead of being assigned an invented owner');
  const parsed = Parser.parseQuestionPages([{ page: 1, text: grouped.text, items }], null, 'wide-single-column.pdf', 23);
  assert.deepEqual(copy(parsed.map((question) => question.questionNumber)), [22, 23]);
  assert.ok(parsed.every((question) => question.structureStatus === 'parsed'));
  parsed.forEach((question) => assert.deepEqual(copy(question.answers), ['甲', '乙', '丙', '丁']));
});

test('a single-question two-by-two A-C/B-D choice grid never becomes independent question columns', () => {
  for (const stemWidth of [240, 500]) {
    const items = [
      pdfText('21. 依圖片選出正確位置？', 40, 730, stemWidth),
      pdfText('A. 左上', 40, 675, 100), pdfText('B. 右上', 340, 675, 100),
      pdfText('C. 左下', 40, 625, 100), pdfText('D. 右下', 340, 625, 100),
    ];
    const grouped = Parser.groupPdfItemsIntoText(items, 600);
    assert.equal(grouped.usedColumns, false, 'A-C and B-D are halves of one option grid, not consecutive independent A-D streams');
    const parsed = Parser.parseQuestionPages([{ page: 1, text: grouped.text, items }], null, 'single-wide-choice-grid.pdf', 21);
    assert.equal(parsed.length, 1);
    assert.equal(parsed[0].questionNumber, 21);
    assert.equal(parsed[0].structureStatus, 'parsed');
    assert.deepEqual(copy(parsed[0].answers), ['左上', '右上', '左下', '右下']);
  }
});

test('circles, decimal quantities, Greek letters and scientific punctuation do not create phantom boundaries', () => {
  const text = '7. ①②③④⑤與16.0 mmHg、(3.5 m/s²)、37 °C、50 µA/μA如何表示？ A. ①③⑤ B. ②④ C. Ca²⁺/Na⁺ D. CO₂及O₂';
  const questions = Parser.parseQuestionPages([{ page: 1, text }], null, 'symbols-only.pdf', 7);
  assert.equal(questions.length, 1);
  assert.equal(questions[0].questionNumber, 7);
  assert.equal(questions[0].structureStatus, 'parsed');
  assert.ok(questions[0].q.includes('①②③④⑤'));
  assert.deepEqual(copy(questions[0].answers), ['①③⑤', '②④', 'Ca²⁺/Na⁺', 'CO₂及O₂']);
});

test('unit abbreviations followed by periods are content, not A/B/C option starts', () => {
  const text = '8. 比較37°C.、50µA.、50μA.、0.5mA.與20dB.的單位？ A. 35°C.溫度 B. 50µA.與0.5mA.電流 C. 20dB.聲壓 D. 120mmHg.壓力';
  assert.deepEqual(copy(Parser.findOptionMarkers(text).map((entry) => entry.letter)), ['A', 'B', 'C', 'D'], 'embedded C./A./B. unit suffixes must not become boundaries');
  const questions = Parser.parseQuestionPages([{ page: 1, text }], null, 'unit-punctuation.pdf', 8);
  assert.equal(questions.length, 1);
  assert.equal(questions[0].structureStatus, 'parsed');
  assert.ok(questions[0].q.includes('37°C.、50µA.、50μA.、0.5mA.與20dB.'));
  assert.deepEqual(copy(questions[0].answers), ['35°C.溫度', '50µA.與0.5mA.電流', '20dB.聲壓', '120mmHg.壓力']);
});

test('page cleanup removes genuine repeated chrome but preserves scientific symbols and repeated option contents', () => {
  const h = harness();
  assert.equal(typeof h.api.cleanPages, 'function');
  const pages = [1, 2].map((number) => ({
    page: number,
    text: ['物理治療師國考', '²⁺', number + '. 說明Ca²⁺與Na⁺？', 'A. Na⁺通道', '第二行內容', 'B. Ca²⁺釋放', 'C. K⁺通道', 'D. Cl⁻通道', '第' + number + '頁'].join('\n'),
    rawText: 'original page ' + number + ' ²⁺ Ca²⁺ Na⁺',
    lines: ['物理治療師國考', '²⁺', number + '. 說明Ca²⁺與Na⁺？', 'A. Na⁺通道', '第二行內容', 'B. Ca²⁺釋放', 'C. K⁺通道', 'D. Cl⁻通道', '第' + number + '頁'],
    items: [pdfText('2+', 80, 706, 7, 7)],
  }));
  const original = copy(pages);
  const cleaned = h.api.cleanPages(pages);
  assert.deepEqual(pages, original, 'cleanup does not mutate source pages or original PDF fragments');
  for (const page of cleaned) {
    assert.ok(!page.text.includes('物理治療師國考'), 'the repeated header is removed');
    assert.ok(!page.text.includes('第' + page.page + '頁'), 'the numbered footer is removed');
    assert.ok(page.text.includes('²⁺'), 'scientific symbols at an edge are retained');
    assert.ok(page.text.includes('A. Na⁺通道'));
    assert.ok(page.text.includes('D. Cl⁻通道'), 'identical scientific options are not mistaken for footers');
    assert.equal(page.rawText, original[page.page - 1].rawText);
    assert.equal(page.items[0].str, '2+');
  }
});

test('real PDF text-reading path keeps original plain glyphs, restores formatted compounds, and commits them intact', async () => {
  const items = ionicQuestion(9);
  const original = copy(items);
  const h = harness([items]);
  assert.equal(typeof h.api.readPdf, 'function');
  const data = await h.api.readPdf(h.file, 'question');
  assert.equal(data.pageCount, 1);
  assert.equal(data.pages.length, 1);
  assert.deepEqual(copy(data.pages[0].items), original, 'the raw PDF.js str/transform/height/width records remain available');
  assert.ok(data.pages[0].items.some((item) => item.str === '2+'), 'raw plain 2+ is not rewritten');
  assert.ok(data.pages[0].text.includes('Ca²⁺'));
  assert.ok(data.pages[0].rawText.includes('Ca²⁺'), 'reconstructed text preserves the complete ionic compound');
  const parsed = h.api.parseQuestionPdf(data, {}, 'source-pdf', h.file.name, 9);
  assert.equal(parsed.length, 1);
  const raw = parsed[0].ocrRawText;
  const result = h.commit(parsed);
  assert.equal(result.stored.length, 1);
  assert.ok(result.stored[0].q.includes('Ca²⁺'));
  assertIonicChoices(result.stored[0].answers);
  assert.deepEqual(result.stored[0].answers, copy(parsed[0].answers), 'storage retains the exact parsed option text, including any visual word spacing');
  assert.deepEqual(result.stored[0].parsedOptions, copy(parsed[0].parsedOptions));
  assert.equal(result.stored[0].ocrRawText, raw);
  assert.equal(result.stored[0].originalPdf.assetId, 'source-pdf');
  assert.equal(result.stored[0].originalPage, 1);
});

test('OCR word bounding boxes, rather than one flattened line, restore charges without inventing unrecognized symbols', async () => {
  const items = ionicQuestion(10);
  const scale = 1.8;
  const words = items.map((item) => ({
    text: item.str,
    bbox: {
      x0: item.transform[4] * scale, x1: (item.transform[4] + item.width) * scale,
      y0: (800 - item.transform[5] - item.height) * scale, y1: (800 - item.transform[5]) * scale,
    },
  }));
  const lines = Array.from({ length: 5 }, (_, index) => {
    const row = words.slice(index * 3, index * 3 + 3);
    return {
      text: row.map((word) => word.text).join(' '),
      bbox: { x0: row[0].bbox.x0, x1: row[row.length - 1].bbox.x1, y0: Math.min(...row.map((word) => word.bbox.y0)), y1: Math.max(...row.map((word) => word.bbox.y1)) },
      words: row,
    };
  });
  const rawOcr = lines.map((line) => line.text).join('\n');
  assert.ok(!rawOcr.includes('²') && !rawOcr.includes('⁺'), 'recognized characters really are plain 2+ and +');
  const ocrResult = { data: { text: rawOcr, blocks: [{ paragraphs: [{ lines }] }] } };
  const h = harness([[]], { ocrResult });
  const data = await h.api.readPdf(h.file, 'question');
  assert.equal(h.workerTerminated, true, 'the OCR worker is released after all pages');
  assert.equal(data.pages[0].items.length, words.length, 'original OCR word geometry is retained, not flattened into five lines');
  assert.ok(data.pages[0].items.some((item) => item.str === '2+'));
  assert.ok(data.pages[0].text.includes('Ca²⁺'));
  const parsed = h.api.parseQuestionPdf(data, {}, 'source-scan', h.file.name, 10);
  assert.equal(parsed.length, 1);
  assertIonicChoices(parsed[0].answers);
  const result = h.commit(parsed);
  assert.equal(result.stored.length, 1);
  assertIonicChoices(result.stored[0].answers);
  assert.deepEqual(result.stored[0].answers, copy(parsed[0].answers));
});

test('all 80 synthetic scientific questions survive 20-page extraction, cleanup, structural parsing, and JSON storage', async () => {
  const sourcePages = Array.from({ length: 20 }, (_, page) =>
    Array.from({ length: 4 }, (_, index) => ionicQuestion(page * 4 + index + 1, 40, 730 - index * 140)).flat(),
  );
  const original = copy(sourcePages);
  const h = harness(sourcePages);
  const data = await h.api.readPdf(h.file, 'question');
  assert.equal(data.pageCount, 20);
  assert.deepEqual(copy(data.pages.map((page) => page.items)), original, 'all 20 pages retain every original plain glyph record');
  const parsed = h.api.parseQuestionPdf(data, {}, 'eighty-source-pdf', h.file.name, 80);
  assert.equal(parsed.length, 80, 'the scientific notation repair is exercised on all 80 questions, not a sample');
  assert.deepEqual(copy(parsed.diagnostics.detectedQuestionNumbers), Array.from({ length: 80 }, (_, index) => index + 1));
  assert.deepEqual(copy(parsed.diagnostics.missingQuestionNumbers), []);
  for (const question of parsed) {
    assert.equal(question.structureStatus, 'parsed', 'question ' + question.questionNumber + ' passes validation');
    assert.ok(question.q.includes('Ca²⁺'), 'question ' + question.questionNumber + ' retains its stem charge');
    assertIonicChoices(question.answers);
  }
  const result = h.commit(parsed);
  assert.equal(result.stored.length, 80);
  assert.equal(new Set(result.stored.map((question) => question.id)).size, 80);
  for (const stored of result.stored) {
    const source = parsed.find((question) => String(question.questionNumber) === String(stored.questionNumber));
    assertIonicChoices(stored.answers);
    assert.equal(stored.q, source.q);
    assert.deepEqual(stored.answers, copy(source.answers));
    assert.equal(stored.ocrRawText, source.ocrRawText);
  }
});

test('the exact screenshot circled sequences parse on separate lines without inventing an official answer', () => {
  const h = harness();
  const text = '1. ' + screenshotStem + '\n' + screenshotChoices.map((choice, index) => String.fromCharCode(65 + index) + '.' + choice).join('\n');
  const parsed = h.api.parseQuestionPdf({ pages: [{ page: 1, text }] }, {}, 'circle-source', 'screenshot-choices.pdf', 1);
  assert.equal(parsed.length, 1);
  assert.equal(parsed[0].q, Parser.normalizeText(screenshotStem));
  assertScreenshotChoices(parsed[0]);
  const result = h.commit(parsed, {});
  assert.equal(result.stored.length, 1);
  assertScreenshotChoices(result.stored[0]);
  assert.equal(result.stored[0].correctAnswer, null, 'the screenshot provides no official answer');
  assert.equal(result.stored[0].correct, null);
  assert.equal(result.stored[0].answerStatus, 'needs_review');
  assert.equal(result.stored[0].answerRawText, null);
  assert.equal(result.stored[0].ocrRawText, parsed[0].ocrRawText);
});

test('same-line circled choices stay distinct from the stem and never become question numbers', () => {
  const h = harness();
  const raw = '12. ' + screenshotStem + ' ' + screenshotChoices.map((choice, index) => String.fromCharCode(65 + index) + '.' + choice).join(' ')
    + '\n13. 下一題含Ca²⁺、Na⁺和16.0 mmHg？ A. 一 B. 二 C. 三 D. 四';
  const parsed = h.api.parseQuestionPdf({ pages: [{ page: 1, text: raw }] }, {}, null, 'same-line-circles.pdf', 13);
  assert.deepEqual(copy(parsed.map((question) => question.questionNumber)), [12, 13], 'circle glyphs and decimal quantities do not create phantom question boundaries');
  assert.deepEqual(copy(parsed.diagnostics.markerQuestionNumbers), [12, 13]);
  assertScreenshotChoices(parsed[0]);
  assert.equal(parsed[0].q, Parser.normalizeText(screenshotStem));
  assert.equal(parsed[1].q, '下一題含Ca²⁺、Na⁺和16.0 mmHg？');
  assert.equal(parsed[1].structureStatus, 'parsed');
  const result = h.commit(parsed, {});
  assert.equal(result.stored.length, 2);
  const screenshotQuestion = result.stored.find((question) => String(question.questionNumber) === '12');
  assertScreenshotChoices(screenshotQuestion);
  assert.equal(screenshotQuestion.correctAnswer, null);
});

test('individual same-baseline PDF circled glyphs join into exact sequences instead of spaced-out options', () => {
  const items = circledQuestion(14, 0);
  const original = copy(items);
  const grouped = Parser.groupPdfItemsIntoText(items, 600);
  assert.deepEqual(items, original, 'raw PDF glyph strings and coordinates remain intact');
  assert.equal(grouped.lines.length, 5);
  screenshotChoices.forEach((sequence, index) => {
    assert.equal(grouped.lines[index + 1].minX, 40, 'the original A-D label remains the beginning of each reconstructed option row');
    assert.ok(grouped.lines[index + 1].text.includes(sequence), 'an adjacent circle run retains exact order and has no inserted spaces');
  });
  const parsed = Parser.parseQuestionPages([{ page: 1, text: grouped.text, items }], null, 'individual-circles.pdf', 14);
  assert.equal(parsed.length, 1);
  assertScreenshotChoices(parsed[0]);
});

test('same-size raised circled PDF glyphs remain on their option baseline and survive real read/parse/apply/save', async () => {
  const sourcePages = [circledQuestion(15, 4)];
  const original = copy(sourcePages);
  const h = harness(sourcePages);
  const data = await h.api.readPdf(h.file, 'question');
  assert.deepEqual(copy(data.pages.map((page) => page.items)), original, 'circle ownership repair does not mutate raw str/transform/height/width records');
  assert.equal(data.pages[0].lines.length, 5, 'font baseline differences inside an ordinary circled glyph do not create separate option rows');
  for (const sequence of screenshotChoices) assert.ok(data.pages[0].text.includes(sequence), 'reconstructed page retains exact circle sequence ' + sequence);
  const parsed = h.api.parseQuestionPdf(data, {}, 'raised-circle-source', h.file.name, 15);
  assert.equal(parsed.length, 1);
  assertScreenshotChoices(parsed[0]);
  const result = h.commit(parsed, {});
  assert.equal(result.stored.length, 1);
  assertScreenshotChoices(result.stored[0]);
  assert.equal(result.stored[0].correctAnswer, null);
  assert.equal(result.stored[0].ocrRawText, parsed[0].ocrRawText);
  assert.equal(result.stored[0].originalPdf.assetId, 'raised-circle-source');
});

test('same-size lowered circled glyphs align with their own A-D label without rewriting the glyphs', () => {
  const items = circledQuestion(20, -4);
  const original = copy(items);
  const grouped = Parser.groupPdfItemsIntoText(items, 600);
  assert.deepEqual(items, original);
  assert.equal(grouped.lines.length, 5);
  screenshotChoices.forEach((sequence, index) => {
    const line = grouped.lines[index + 1];
    assert.equal(line.minX, 40);
    assert.equal(line.y, 700 - index * 30, 'the label baseline, not the lowered circled font baseline, determines row order');
    assert.ok(line.text.includes(sequence));
  });
  const parsed = Parser.parseQuestionPages([{ page: 1, text: grouped.text, items }], null, 'lowered-circles.pdf', 20);
  assert.equal(parsed.length, 1);
  assertScreenshotChoices(parsed[0]);
});

test('circle baseline alignment does not steal a distant row or join two independent question columns', () => {
  const distant = [pdfText('A.', 40, 700, 14), ...Array.from('①③④②⑤').map((glyph, index) => pdfText(glyph, 360 + index * 12, 704, 12))];
  const distantOriginal = copy(distant);
  const distantGrouped = Parser.groupPdfItemsIntoText(distant, 600);
  assert.deepEqual(distant, distantOriginal);
  const labelLine = distantGrouped.lines.find((line) => line.text === 'A.');
  const circleLine = distantGrouped.lines.find((line) => line.text.includes('①③④②⑤'));
  assert.ok(labelLine && circleLine, 'a far-away circle run remains an independent row');
  assert.equal(labelLine.y, 700);
  assert.equal(labelLine.minX, 40);
  assert.equal(circleLine.y, 704, 'a right-column run is not snapped to a distant left-column label');
  assert.equal(circleLine.minX, 360);

  const items = circledQuestion(21, 4).concat(circledQuestion(22, -4).map((item) => ({ ...item, transform: item.transform.map((value, index) => index === 4 ? value + 300 : value) })));
  const original = copy(items);
  const grouped = Parser.groupPdfItemsIntoText(items, 600);
  assert.equal(grouped.usedColumns, true);
  assert.deepEqual(items, original);
  const parsed = Parser.parseQuestionPages([{ page: 1, text: grouped.text, items }], null, 'independent-circle-columns.pdf', 22);
  assert.deepEqual(copy(parsed.map((question) => question.questionNumber)), [21, 22]);
  parsed.forEach(assertScreenshotChoices);
});

test('repeated standalone circled sequence rows at page edges are choice content, not page chrome', () => {
  const h = harness();
  const pages = [16, 17].map((number, index) => {
    const lines = ['物理治療師國考', number + '. 過程的正確順序為何？'];
    screenshotChoices.forEach((sequence, optionIndex) => lines.push(String.fromCharCode(65 + optionIndex) + '.', sequence));
    lines.push('第' + (index + 1) + '頁');
    return { page: index + 1, text: lines.join('\n'), rawText: lines.join('\n'), lines, items: circledQuestion(number, 4) };
  });
  const original = copy(pages);
  const cleaned = h.api.cleanPages(pages);
  assert.deepEqual(pages, original, 'cleanup does not mutate standalone glyph source pages');
  cleaned.forEach((page, index) => {
    assert.ok(!page.text.includes('物理治療師國考'), 'the genuine repeated header is still removed');
    assert.ok(!page.text.includes('第' + (index + 1) + '頁'), 'the genuine footer is still removed');
    for (const sequence of screenshotChoices) assert.ok(page.text.includes(sequence), 'standalone circled sequence at page edge is not removed: ' + sequence);
    assert.equal(page.rawText, original[index].rawText);
    assert.deepEqual(copy(page.items), original[index].items);
  });
  const parsed = h.api.parseQuestionPdf({ pages: cleaned }, {}, null, 'repeated-edge-circles.pdf', 17);
  assert.deepEqual(copy(parsed.map((question) => question.questionNumber)), [16, 17]);
  parsed.forEach(assertScreenshotChoices);
  const result = h.commit(parsed, {});
  assert.equal(result.stored.length, 2);
  result.stored.forEach(assertScreenshotChoices);
  assert.ok(result.stored.every((question) => question.correctAnswer === null));
});

test('scientific raised numbers still restore Ca²⁺ while same-font circled sequences stay circled', () => {
  const items = ionicQuestion(18).concat(circledQuestion(19, 4).map((item) => ({ ...item, transform: item.transform.map((value, index) => index === 5 ? value - 180 : value) })));
  const original = copy(items);
  const grouped = Parser.groupPdfItemsIntoText(items, 600);
  assert.deepEqual(items, original);
  const parsed = Parser.parseQuestionPages([{ page: 1, text: grouped.text, items }], null, 'ions-plus-circles.pdf', 19);
  assert.deepEqual(copy(parsed.map((question) => question.questionNumber)), [18, 19]);
  assert.ok(parsed[0].q.includes('Ca²⁺'));
  assertIonicChoices(parsed[0].answers);
  assertScreenshotChoices(parsed[1]);
  assert.ok(!parsed[1].answers.some((answer) => /[¹²³⁴⁵]/.test(answer)), 'circled list items are not converted into scientific superscripts');
});

test('OCR word boxes preserve raised circled choices through real read/parse/apply/save without guessing missing glyphs', async () => {
  const items = circledQuestion(23, 4);
  const scale = 1.8;
  const words = items.map((item) => ({
    text: item.str,
    bbox: {
      x0: item.transform[4] * scale, x1: (item.transform[4] + item.width) * scale,
      y0: (800 - item.transform[5] - item.height) * scale, y1: (800 - item.transform[5]) * scale,
    },
  }));
  const rows = [words.slice(0, 1), ...Array.from({ length: 4 }, (_, index) => words.slice(1 + index * 6, 1 + (index + 1) * 6))];
  const lines = rows.map((row) => ({
    text: row.map((word) => word.text).join(' '),
    bbox: { x0: row[0].bbox.x0, x1: row[row.length - 1].bbox.x1, y0: Math.min(...row.map((word) => word.bbox.y0)), y1: Math.max(...row.map((word) => word.bbox.y1)) },
    words: row,
  }));
  const ocrResult = { data: { text: lines.map((line) => line.text).join('\n'), blocks: [{ paragraphs: [{ lines }] }] } };
  const h = harness([[]], { ocrResult });
  const data = await h.api.readPdf(h.file, 'question');
  assert.equal(h.workerTerminated, true);
  assert.equal(data.pages[0].items.length, words.length, 'OCR retains each circle word box, rather than using flattened line text');
  assert.equal(data.pages[0].lines.length, 5);
  assert.equal(data.pages[0].items.filter((item) => /^[①②③④⑤]$/.test(item.str)).length, 20, 'exactly the 20 recognized circle glyphs remain in the raw OCR records');
  const parsed = h.api.parseQuestionPdf(data, {}, 'circle-scan-source', h.file.name, 23);
  assert.equal(parsed.length, 1);
  assertScreenshotChoices(parsed[0]);
  const result = h.commit(parsed, {});
  assert.equal(result.stored.length, 1);
  assertScreenshotChoices(result.stored[0]);
  assert.equal(result.stored[0].correctAnswer, null);
});

test('all 80 synthetic circled-sequence questions retain exact A-D order through 20-page extraction and JSON storage', async () => {
  const sourcePages = Array.from({ length: 20 }, (_, pageIndex) => Array.from({ length: 4 }, (_, rowIndex) => {
    const questionNumber = pageIndex * 4 + rowIndex + 1;
    return circledQuestion(questionNumber, questionNumber % 2 ? 4 : -4).map((item) => ({
      ...item, transform: item.transform.map((value, index) => index === 5 ? value - rowIndex * 140 : value),
    }));
  }).flat());
  const original = copy(sourcePages);
  const h = harness(sourcePages);
  const data = await h.api.readPdf(h.file, 'question');
  assert.equal(data.pageCount, 20);
  assert.deepEqual(copy(data.pages.map((page) => page.items)), original);
  const parsed = h.api.parseQuestionPdf(data, {}, 'eighty-circle-source', h.file.name, 80);
  assert.equal(parsed.length, 80);
  assert.deepEqual(copy(parsed.diagnostics.detectedQuestionNumbers), Array.from({ length: 80 }, (_, index) => index + 1));
  assert.deepEqual(copy(parsed.diagnostics.missingQuestionNumbers), []);
  parsed.forEach(assertScreenshotChoices);
  const result = h.commit(parsed, {});
  assert.equal(result.stored.length, 80);
  assert.equal(new Set(result.stored.map((question) => question.id)).size, 80);
  result.stored.forEach((question) => {
    assertScreenshotChoices(question);
    assert.equal(question.correctAnswer, null, 'no official answer was supplied for this fixture');
    assert.equal(question.answerStatus, 'needs_review');
    const source = parsed.find((parsedQuestion) => String(parsedQuestion.questionNumber) === String(question.questionNumber));
    assert.equal(question.ocrRawText, source.ocrRawText);
  });
});

(async () => {
  let passed = 0;
  for (const entry of cases) {
    try {
      await entry.run();
      passed++;
      console.log('PASS ' + entry.name);
    } catch (error) {
      process.exitCode = 1;
      console.error('FAIL ' + entry.name);
      console.error(error);
    }
  }
  console.log(`${passed === cases.length ? 'PASS' : 'FAIL'} ${passed}/${cases.length} scientific-text import regressions (synthetic geometry, not a real uploaded PDF)`);
})().catch((error) => { console.error(error); process.exitCode = 1; });
