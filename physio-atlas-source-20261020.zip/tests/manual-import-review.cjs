const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { File: BufferFile } = require('node:buffer');
const Parser = require('../dist/parser-pipeline.js');

const html = fs.readFileSync(path.join(__dirname, '../dist/index.html'), 'utf8');
const marker = '<script src="parser-pipeline.js"></script><script>';
const start = html.indexOf(marker) + marker.length;
const end = html.indexOf('</script><style>', start);
assert.ok(start >= marker.length && end >= 0, 'the real PDF import controller must be present');
const controller = html.slice(start, end);
const media = fs.readFileSync(path.join(__dirname, '../dist/option-media.js'), 'utf8');
const multipleStart = html.indexOf('/* 最後一層的題庫操作：不再讓舊的事件處理互相攔截。 */');
const multipleEnd = html.indexOf('</script>', multipleStart);
assert.ok(multipleStart >= 0 && multipleEnd > multipleStart, 'the real multiple-answer wrapper must be present');
const multipleAnswers = html.slice(multipleStart, multipleEnd);
const FileClass = globalThis.File || BufferFile;
const copy = (value) => JSON.parse(JSON.stringify(value));
const tick = async () => { for (let index = 0; index < 8; index++) await Promise.resolve(); };
const subjects = ['物理治療基礎學', '物理治療學概論', '物理治療技術學', '神經疾病物理治療學', '骨科疾病物理治療學', '心肺疾病與小兒疾病物理治療學'];

function harness() {
  const listeners = new Map();
  const fields = [];
  const toasts = [];
  const elements = new Map();
  const statuses = new Map();
  const zones = [];
  const crops = [];
  let savePolicy = null;
  let rebuildFromStored = false;
  let renders = 0;
  let saves = 0;
  function node() {
    const classes = new Set();
    return {
      textContent: '', innerHTML: '', value: '', dataset: {}, disabled: false,
      classList: { add: (value) => classes.add(value), remove: (value) => classes.delete(value), contains: (value) => classes.has(value), toggle: (value, force) => force === false ? classes.delete(value) : classes.add(value) },
      querySelector: () => null, querySelectorAll: () => [], closest: () => null,
      setAttribute() {}, removeAttribute() {}, insertAdjacentHTML() {},
    };
  }
  function $(selector) {
    if (!elements.has(selector)) elements.set(selector, node());
    return elements.get(selector);
  }
  const editor = node();
  editor.dataset = { draftEditor: '1', questionId: '' };
  editor.querySelectorAll = (selector) => selector.includes('data-draft-field') ? fields : [];
  editor.querySelector = (selector) => {
    const match = /data-draft-field="([^"]+)"/.exec(selector);
    return match ? fields.find((field) => field.dataset.draftField === match[1]) || null : null;
  };
  const structureMessage = node();
  const parsedCount = node();
  const failedCount = node();
  const failedNumbers = node();
  const summaryStats = Array.from({ length: 5 }, () => {
    const stat = node();
    const small = node();
    const b = node();
    stat.querySelector = (selector) => selector === 'small' ? small : selector === 'b' ? b : null;
    stat.small = small;
    stat.b = b;
    return stat;
  });
  summaryStats[1].b = parsedCount;
  summaryStats[1].querySelector = (selector) => selector === 'b' ? parsedCount : selector === 'small' ? summaryStats[1].small : null;
  summaryStats[2].b = failedCount;
  summaryStats[2].querySelector = (selector) => selector === 'b' ? failedCount : selector === 'small' ? summaryStats[2].small : null;
  summaryStats[1].small.textContent = '結構完成';
  summaryStats[2].small.textContent = '選項解析失敗';
  const summary = node();
  summary.querySelectorAll = (selector) => selector === '.summary-stat' ? summaryStats : [];
  summary.querySelector = (selector) => selector === '[data-import-structure-issues]' ? failedNumbers : null;
  const result = $('#importResult');
  function select(selector) {
    if (selector === '#importResult' || selector === '.import-result') return result;
    if (selector.includes('.preview-editor')) return selector.includes('.lead') ? structureMessage : editor;
    if (selector.includes('data-import-structure-message')) return structureMessage;
    if (selector.includes('data-import-parsed-count')) return parsedCount;
    if (selector.includes('data-import-failed-count')) return failedCount;
    if (selector.includes('data-import-failed-numbers')) return failedNumbers;
    if (selector.includes('.import-summary')) return summary;
    if (selector.startsWith('#')) return elements.get(selector) || null;
    return null;
  }
  function selectAll(selector) {
    if (selector.includes('data-draft-field')) return fields;
    if (selector.includes('.summary-stat')) return summaryStats;
    if (selector.includes('data-draft-select') || selector.includes('.preview-item')) return Array.from(statuses.values());
    if (selector.includes('data-option-media-context')) return zones;
    return [];
  }
  result.querySelector = select;
  result.querySelectorAll = selectAll;
  const context = {
    console, Promise, Set, WeakMap, Date, Math, Blob, File: FileClass,
    MutationObserver: class { observe() {} },
    $,
    Q: [], S: subjects, st: {}, importDraft: null, pdfQuestionFile: null, pdfAnswerFile: null,
    canonicalSubject: (value) => subjects.includes(value) ? value : subjects[0],
    qSubject: (item) => item.subject || item.topic || subjects[0],
    qSession: (item) => String(item.examSession || ''),
    qKeywords: (item) => Array.isArray(item.keywords) ? item.keywords : [],
    detectExamMeta: () => ({ subject: subjects[4], examYear: '115', examSession: '1', examName: '115-1 骨科疾病物理治療學' }),
    findExactDuplicate: (item) => context.Q.find((existing) => String(existing.questionNumber) === String(item.questionNumber) && existing.q === item.q) || null,
    loadPdfJs: async () => { throw new Error('not used'); },
    loadTesseract: async () => { throw new Error('not used'); },
    saveAsset: (file, kind) => savePolicy ? savePolicy(file, kind) : Promise.resolve(null),
    openCropper: (file, use) => { crops.push({ file, use }); },
    saveAll: () => { saves++; }, renderBank() {}, renderSubjects() {}, renderSimilar() {}, renderTrack() {}, renderBranchLanding() {}, view() {}, qmodal() {}, answer() {}, cur: () => null,
    toast: (message) => toasts.push(message), esc: (value) => String(value),
    document: {
      body: { dataset: { bankAccess: 'admin' } },
      addEventListener(type, listener) {
        if (!listeners.has(type)) listeners.set(type, []);
        listeners.get(type).push(listener);
      },
      querySelector: select,
      querySelectorAll: selectAll,
      getElementById: (id) => elements.get('#' + id) || null,
    },
    window: { PhysioPdfPipeline: Parser },
  };
  context.window.window = context.window;
  vm.createContext(context);
  vm.runInContext(controller, context, { filename: 'real-import-controller.js' });
  const api = context.window.__physioImportPipeline;
  assert.ok(api, 'the real import API is exported');
  // The real input/change listeners remain registered. Rendering is counted,
  // because edits must refresh status without replacing the focused fields.
  context.renderImport = () => {
    renders++;
    const selected = context.importDraft && context.importDraft.items[Number(context.importDraft.selected || 0)];
    if (rebuildFromStored && selected) installFields(selected);
  };
  vm.runInContext(multipleAnswers, context, { filename: 'real-multiple-answer-controller.js' });
  vm.runInContext(media, context, { filename: 'real-option-media.js' });

  function installFields(item) {
    fields.splice(0);
    editor.dataset.questionId = String(item.id);
    editor.dataset.draftEditorId = String(item.id);
    const values = { questionNumber: String(item.questionNumber), q: item.q, correct: item.correct === null ? '' : String(item.correct), subject: item.subject, examYear: item.examYear, examSession: item.examSession, why: item.why, duplicateAction: 'skip' };
    [0, 1, 2, 3].forEach((index) => { values['answer' + index] = item.answers[index]; });
    for (const [name, value] of Object.entries(values)) {
      const field = node();
      field.dataset.draftField = name;
      field.value = value || '';
      field.closest = (selector) => selector.includes('data-draft-field') ? field : selector.includes('.preview-editor') ? editor : null;
      field.matches = (selector) => selector === '[data-draft-field]' || selector.includes('data-draft-field=');
      fields.push(field);
    }
    context.document.activeElement = fields[0];
    return fields;
  }
  function setDraft(items, selected = 0) {
    context.importDraft = { busy: false, selected, items, answers: {}, meta: { subject: subjects[4], examYear: '115', examSession: '1', subjectExplicit: true }, expectedQuestionCount: items.length };
    statuses.clear();
    items.forEach((item, index) => {
      const button = node();
      const status = node();
      button.dataset.draftSelect = String(index);
      button.querySelector = (selector) => selector === 'small' ? status : null;
      button.status = status;
      statuses.set(String(index), button);
    });
    installFields(items[selected]);
    return context.importDraft;
  }
  function field(name) { return fields.find((entry) => entry.dataset.draftField === name); }
  function dispatch(type, target) {
    const event = { target, preventDefault() {}, stopPropagation() {}, stopImmediatePropagation() {} };
    for (const listener of listeners.get(type) || []) listener(event);
  }
  function edit(name, value, event = 'input') {
    const target = field(name);
    assert.ok(target, 'editable field ' + name + ' exists');
    target.value = value;
    context.document.activeElement = target;
    dispatch(event, target);
    return target;
  }
  function item(number, answers = ['甲', '乙', '丙', '丁']) {
    const raw = number + '. 原始第 ' + number + ' 題？ A. OCR甲 B. OCR乙 C. OCR丙 D. OCR丁';
    const parsed = api.parseQuestionPdf({ pages: [{ page: 1, text: raw }] }, {}, null, 'fixture.pdf');
    const entry = api.buildImportItem(parsed[0], { subject: subjects[4], subjectExplicit: true, examYear: '115', examSession: '1' }, { letter: 'B', rawText: number + '.B', parsedAnswer: 'B' });
    entry.answers = answers.slice();
    entry.structureStatus = Parser.validateQuestionStructure(entry.q, entry.answers, entry.optionImages).ok ? 'parsed' : 'option_parse_failed';
    return entry;
  }
  function previewZone(index) {
    const preview = { innerHTML: '', querySelectorAll: () => [] };
    const input = {
      value: '', files: [], matches: (selector) => selector === '[data-option-media-file]',
      closest: (selector) => selector === '[data-option-media-context]' ? zone : null,
      click() {},
    };
    const zone = {
      dataset: { optionMediaContext: 'import', optionMediaIndex: String(index) },
      querySelector: (selector) => selector === '[data-option-media-file]' ? input : selector === '.option-media-preview' ? preview : null,
      querySelectorAll: () => [],
      closest: (selector) => selector === '[data-option-media-context]' ? zone : null,
      input, preview,
    };
    zones.push(zone);
    return zone;
  }
  function imageZone(index) {
    const zone = previewZone(index);
    const input = zone.input;
    const button = { dataset: { optionMediaAction: 'pick' }, closest: (selector) => selector === '[data-option-media-action]' ? button : selector === '[data-option-media-context]' ? zone : null };
    dispatch('click', button);
    input.files = [new FileClass(['image bytes'], 'source.png', { type: 'image/png' })];
    dispatch('change', input);
    const crop = crops.shift();
    assert.ok(crop, 'the real option-media upload starts cropping');
    crop.use(new FileClass(['cropped image bytes'], 'cropped.png', { type: 'image/png' }));
  }
  return { context, api, setDraft, installFields, field, edit, dispatch, item, imageZone, previewZone, rebuildPreviewFromStored: () => { rebuildFromStored = true; }, setSavePolicy: (policy) => { savePolicy = policy; }, toasts, fields, statuses, parsedCount, failedCount, failedNumbers, get renders() { return renders; }, get saves() { return saves; } };
}

const cases = [];
function test(name, run) { cases.push({ name, run }); }

test('real input handlers validate manual correction immediately without rebuilding the focused editor', async () => {
  const h = harness();
  const item = h.item(9, ['', '', '', '']);
  const raw = item.ocrRawText;
  h.setDraft([item]);
  const initialFields = h.fields.slice();
  const before = h.renders;
  h.edit('q', '手動校對後的任務導向評估題？');
  h.edit('answer0', '功能性動作策略');
  h.edit('answer1', '功能限制');
  h.edit('answer2', '忽略環境');
  const focused = h.edit('answer3', '觀察代償');
  assert.equal(item.structureStatus, 'parsed', 'manual content clears the stale parse-failed flag');
  assert.deepEqual(copy(item.structureIssues), []);
  assert.equal(item.parsedQuestion, '手動校對後的任務導向評估題？');
  assert.deepEqual(copy(item.parsedOptions), { A: '功能性動作策略', B: '功能限制', C: '忽略環境', D: '觀察代償' });
  assert.equal(item.ocrRawText, raw, 'manual correction does not overwrite source OCR');
  assert.equal(h.renders, before, 'typing must not re-render the entire import preview');
  assert.equal(h.context.document.activeElement, focused);
  assert.deepEqual(h.fields, initialFields, 'the live input nodes remain intact');
  assert.equal(String(h.failedCount.textContent), '0', 'failure summary is refreshed immediately');
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 1, 'the final image-aware applyImport commits the corrected item');
  assert.equal(h.context.importDraft, null);
  assert.equal(h.context.Q[0].ocrRawText, raw);
});

test('change events also apply corrections, while removing a required choice restores a real failure', async () => {
  const h = harness();
  const item = h.item(12, ['甲', '乙', '丙', '']);
  h.setDraft([item]);
  h.edit('answer3', '丁', 'change');
  assert.equal(item.structureStatus, 'parsed');
  h.edit('answer1', '   ');
  assert.equal(item.structureStatus, 'option_parse_failed');
  assert.ok(item.structureIssues.some((issue) => /B/.test(issue)), 'the actual missing letter is reported');
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 0);
  assert.equal(h.context.importDraft.items[0], item, 'a still-invalid item remains editable after attempted import');
  assert.ok(h.toasts.some((message) => /12/.test(message)), 'failed import reports the question number');
  assert.match(h.failedNumbers.textContent, /12.*B/, 'the summary identifies that question\'s missing choice');
});

test('mixed text and image-only choices validate and import without inventing text', async () => {
  const h = harness();
  const item = h.item(31, ['文字 A', '', '文字 C', '']);
  item.optionImages = [[], [{ assetId: 'image-B', assignment: 'manual' }], [], [{ assetId: 'image-D', assignment: 'manual' }]];
  item.structureStatus = 'option_parse_failed';
  h.setDraft([item]);
  h.edit('q', '請依圖選擇正確移位方法？');
  assert.equal(item.structureStatus, 'parsed');
  assert.deepEqual(copy(item.parsedOptions), { A: '文字 A', B: '', C: '文字 C', D: '' });
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 1);
  assert.deepEqual(copy(h.context.Q[0].answers), ['文字 A', '', '文字 C', '']);
  assert.equal(h.context.Q[0].optionImages[1][0].assetId, 'image-B');
  assert.equal(h.context.Q[0].optionImages[3][0].assetId, 'image-D');
});

test('four image-only choices clear a stale failure at final import even without a text edit', async () => {
  const h = harness();
  const item = h.item(33, ['', '', '', '']);
  item.optionImages = ['A', 'B', 'C', 'D'].map((letter) => [{ assetId: 'choice-' + letter, assignment: 'manual' }]);
  item.structureStatus = 'option_parse_failed';
  h.setDraft([item]);
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 1, 'commit validates actual image contents instead of trusting the stale badge');
  assert.equal(h.context.Q[0].structureStatus, 'parsed');
  assert.deepEqual(copy(h.context.Q[0].answers), ['', '', '', '']);
  assert.deepEqual(copy(h.context.Q[0].optionImages.map((slot) => slot[0].assetId)), ['choice-A', 'choice-B', 'choice-C', 'choice-D']);
});

test('diagram references 圖(A) through 圖(D) in a manually corrected stem are not confused with option boundaries', async () => {
  const h = harness();
  const item = h.item(41);
  h.setDraft([item]);
  h.edit('q', '觀察圖(A)、圖(B)、圖(C)及圖(D)，哪一種移位方式最安全？');
  assert.equal(item.structureStatus, 'parsed', 'legitimate figure labels remain valid after real input processing');
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 1);
  assert.ok(h.context.Q[0].q.includes('圖(A)'));
});

test('commit flushes the latest unblurred DOM values before its final structural validation', async () => {
  const h = harness();
  const item = h.item(46, ['甲', '乙', '丙', '']);
  h.setDraft([item]);
  h.field('q').value = '尚未失焦的完整題幹？';
  h.field('answer3').value = '尚未觸發 change 的 D 選項';
  h.context.document.activeElement = h.field('answer3');
  assert.equal(item.answers[3], '', 'the test intentionally leaves the stored draft stale');
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 1, 'confirmation must not discard valid current DOM edits');
  assert.equal(h.context.Q[0].q, '尚未失焦的完整題幹？');
  assert.equal(h.context.Q[0].answers[3], '尚未觸發 change 的 D 選項');
  assert.equal(h.context.Q[0].parsedOptions.D, '尚未觸發 change 的 D 選項');
});

test('a full 80-item draft commits 78 valid items and retains two failures, then commits only the corrected remainder', async () => {
  const h = harness();
  const items = Array.from({ length: 80 }, (_, index) => h.item(index + 1, index >= 78 ? ['甲', '乙', '丙', ''] : undefined));
  const rawByNumber = new Map(items.map((entry) => [String(entry.questionNumber), entry.ocrRawText]));
  h.setDraft(items);
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 78, 'all valid items, not just the selected item, are committed');
  assert.deepEqual(copy(h.context.importDraft.items.map((entry) => Number(entry.questionNumber))), [79, 80]);
  assert.ok(h.toasts.some((message) => /79/.test(message) && /80/.test(message)), 'the remaining failures are identified by question number');
  const remaining = h.context.importDraft.items;
  h.context.importDraft.selected = 0;
  h.installFields(remaining[0]);
  h.edit('answer3', '第79題手動 D');
  h.context.importDraft.selected = 1;
  h.installFields(remaining[1]);
  h.edit('answer3', '第80題手動 D');
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 80, 'correcting the retained two produces exactly 80 records');
  assert.equal(new Set(h.context.Q.map((entry) => entry.id)).size, 80, 'every imported question keeps a unique ID');
  assert.equal(new Set(h.context.Q.map((entry) => String(entry.questionNumber))).size, 80, 'previously committed questions are not duplicated');
  assert.equal(h.context.importDraft, null);
  for (const entry of h.context.Q) assert.equal(entry.ocrRawText, rawByNumber.get(String(entry.questionNumber)), 'all 80 source OCR records remain available');
});

test('batch imports allocate unique IDs even when the clock and random candidate are identical', async () => {
  const h = harness();
  const existing = h.item(81);
  existing.id = 1000000;
  h.context.Q.push(existing);
  const items = [h.item(1), h.item(2), h.item(3)];
  h.context.Date = class extends Date { static now() { return 1000000; } };
  h.context.Math = Object.assign(Object.create(Math), { random: () => 0 });
  h.setDraft(items);
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 4);
  assert.equal(new Set(h.context.Q.map((entry) => String(entry.id))).size, 4, 'duplicate candidate IDs cannot overwrite bank records or progress');
  assert.equal(existing.id, 1000000, 'previous IDs remain stable');
});

test('invalid answer-only updates leave an existing question untouched; successful multi-answer updates preserve every official answer', async () => {
  const h = harness();
  const existing = h.item(57);
  existing.correct = 1;
  existing.correctAnswer = 'B';
  existing.correctAnswers = [1];
  existing.answerStatus = 'matched';
  h.context.Q.push(existing);
  const original = copy(existing);
  const item = h.item(57, ['甲', '', '丙', '丁']);
  item.duplicateAction = 'answer';
  item.correct = null;
  item.correctAnswer = 'A、C';
  item.correctAnswers = [0, 2];
  item.answerStatus = 'confirmed_manually';
  h.setDraft([item]);
  await h.context.applyImport();
  assert.deepEqual(copy(existing), original, 'a failed draft must not mutate official answers before validation');
  assert.equal(h.context.importDraft.items[0], item);
  h.installFields(item);
  h.edit('answer1', '已校對 B');
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 1, 'answer-only updates do not create a new bank question');
  assert.deepEqual(copy(existing.correctAnswers), [0, 2]);
  assert.equal(existing.correctAnswer, 'A、C');
  assert.equal(existing.correct, null);
  const accepted = h.item(57);
  accepted.duplicateAction = 'answer';
  accepted.correct = null;
  accepted.correctAnswer = null;
  accepted.correctAnswers = [0, 1, 2, 3];
  accepted.allAnswersAccepted = true;
  accepted.answerStatus = 'all_answers_accepted';
  h.setDraft([accepted]);
  await h.context.applyImport();
  assert.equal(existing.allAnswersAccepted, true, 'official all-accepted corrections survive a validated update');
  assert.deepEqual(copy(existing.correctAnswers), [0, 1, 2, 3]);
});

test('final async import waits for an option-image asset before revalidating and committing its original draft', async () => {
  const h = harness();
  const item = h.item(62, ['甲', '乙', '丙', '']);
  h.setDraft([item]);
  let resolveImage;
  h.setSavePolicy((file, kind) => kind === 'option-image-source' ? Promise.resolve('source-D') : new Promise((resolve) => { resolveImage = resolve; }));
  h.imageZone(3);
  await tick();
  assert.equal(typeof resolveImage, 'function', 'the upload is waiting on its real asynchronous asset write');
  let settled = false;
  const importing = h.context.applyImport().then(() => { settled = true; });
  await tick();
  assert.equal(settled, false, 'confirmation cannot finish ahead of a pending choice image');
  assert.equal(h.context.Q.length, 0, 'the incomplete draft is not committed before the image is saved');
  resolveImage('saved-D');
  await importing;
  assert.equal(h.context.Q.length, 1);
  assert.equal(h.context.Q[0].structureStatus, 'parsed');
  assert.equal(h.context.Q[0].optionImages[3][0].assetId, 'saved-D');
  assert.equal(h.context.importDraft, null);
});

test('releasing two retained visited image drafts refreshes only the selected question preview', async () => {
  const h = harness();
  const first = h.item(79, ['甲', '', '丙', '丁']);
  const second = h.item(80, ['甲', '', '丙', '丁']);
  first.optionImages = [[{ assetId: 'first-A' }], [], [], []];
  second.optionImages = [[{ assetId: 'second-A' }], [], [], []];
  h.setDraft([first, second]);
  const visible = h.previewZone(0);
  h.context.renderImport(); // Creates the first question's real media owner.
  h.context.importDraft.selected = 1;
  h.installFields(second);
  h.context.renderImport(); // Creates a separate owner for the second question.
  h.context.importDraft.selected = 0;
  h.installFields(first);
  h.context.renderImport();
  await h.context.applyImport();
  assert.equal(h.context.Q.length, 0);
  assert.equal(h.context.importDraft.items.length, 2);
  assert.equal(h.context.importDraft.selected, 0);
  assert.match(visible.preview.innerHTML, /first-A/, 'selected first-question images stay in its preview after all owners are released');
  assert.doesNotMatch(visible.preview.innerHTML, /second-A/, 'the inactive second owner cannot repaint the visible first question');
  assert.equal(first.optionImages[0][0].assetId, 'first-A');
  assert.equal(second.optionImages[0][0].assetId, 'second-A');
});

test('DOM-only corrections are captured before a pending image render rebuilds inputs from stored draft values', async () => {
  const h = harness();
  const item = h.item(70, ['甲', '乙', '', '']);
  const raw = item.ocrRawText;
  h.setDraft([item]);
  h.rebuildPreviewFromStored();
  let resolveImage;
  h.setSavePolicy((file, kind) => kind === 'option-image-source' ? Promise.resolve('source-C') : new Promise((resolve) => { resolveImage = resolve; }));
  h.imageZone(2);
  await tick();
  const latestStem = '已手動校對，但尚未失焦的題幹？';
  const latestD = '已手動校對，但尚未觸發事件的 D 選項';
  h.field('q').value = latestStem;
  h.field('answer3').value = latestD;
  assert.equal(item.answers[3], '', 'the stored draft deliberately remains stale before confirmation');
  const before = h.renders;
  const importing = h.context.applyImport();
  await tick();
  resolveImage('pending-C');
  await importing;
  assert.ok(h.renders > before, 'image completion really rebuilds inputs from the stored draft in this harness');
  assert.equal(h.context.Q.length, 1, 'pending image completion must not erase the last DOM-only choice correction');
  assert.equal(h.context.Q[0].q, latestStem);
  assert.equal(h.context.Q[0].answers[3], latestD);
  assert.equal(h.context.Q[0].parsedOptions.D, latestD);
  assert.equal(h.context.Q[0].optionImages[2][0].assetId, 'pending-C');
  assert.equal(h.context.Q[0].ocrRawText, raw);
  assert.equal(h.context.importDraft, null);
});

(async () => {
  for (const entry of cases) {
    await entry.run();
    console.log('PASS ' + entry.name);
  }
  console.log(`PASS ${cases.length} manual-import regressions through real input/change and final commit handlers`);
})().catch((error) => { console.error(error); process.exitCode = 1; });
