/* The published bank is the only source of shared questions. Personal memory
   remains account-scoped and never overwrites it. Server routes enforce writes. */
(function () {
  "use strict";

  const legacyKey = "physio-atlas-legacy-bank-draft";
  const migratedKey = "physio-atlas-legacy-bank-migrated";
  const bankPath = "/api/bank";
  const assetPath = "/api/bank/assets/";
  const initialQuestions = Array.isArray(Q) ? Q.slice() : [];
  let savedLegacy = [];
  try { savedLegacy = JSON.parse(localStorage.getItem(legacyKey) || "[]"); } catch (_) {}
  if (!Array.isArray(savedLegacy)) savedLegacy = [];

  const state = {
    isAdmin: false,
    authenticated: false,
    ready: false,
    loading: true,
    publishing: false,
    applying: false,
    dirty: false,
    error: "",
    revision: null,
    publishedAt: null,
    publishedFingerprint: "",
    legacyQuestions: [],
    legacyChecked: false,
    timer: null,
    remoteAssetPromises: new Map(),
    captureLegacyQuestions(items) {
      if (localStorage.getItem(migratedKey) === "yes") return;
      if (!Array.isArray(items) || !items.length) return;
      const byId = new Map(this.legacyQuestions.map((item) => [String(item.id), item]));
      items.forEach((item) => {
        if (item && item.id && item.q && Array.isArray(item.answers) && item.answers.length === 4) {
          byId.set(String(item.id), item);
        }
      });
      this.legacyQuestions = Array.from(byId.values());
      try { localStorage.setItem(legacyKey, JSON.stringify(this.legacyQuestions)); } catch (_) {}
      renderAdmin();
    },
  };
  window.PhysioBankState = state;
  state.captureLegacyQuestions(savedLegacy);
  state.captureLegacyQuestions(initialQuestions);
  Q = [];

  const baseRenderBank = renderBank;
  renderBank = function () {
    const result = baseRenderBank.apply(this, arguments);
    if (!state.isAdmin) {
      const emptyMessage = document.querySelector("#qpane .empty p");
      if (emptyMessage) emptyMessage.textContent = "目前沒有公開題目，請稍後再查看。";
    }
    return result;
  };

  function repaint() {
    if (typeof renderSubjects === "function") renderSubjects();
    if (typeof renderBank === "function") renderBank();
    if (typeof renderSimilar === "function") renderSimilar();
    if (typeof renderTrack === "function") renderTrack();
  }
  repaint();

  function subjectOf(question) { return String(question.subject || question.topic || "未分類"); }
  function sessionOf(question) { return String(question.examSession || "").trim(); }
  function sourceOf(question) {
    if (typeof examBranch === "function") return examBranch(question);
    const year = String(question.examYear || "").trim();
    const session = sessionOf(question);
    return year && session ? year + "-" + session : "未分類考試來源";
  }
  function safeText(value) { return typeof esc === "function" ? esc(value) : String(value || ""); }
  function pendingLegacy() {
    const existing = new Set(Q.map((item) => String(item.id)));
    return state.legacyQuestions.filter((item) => !existing.has(String(item.id)));
  }

  function mountAdmin() {
    if (document.getElementById("admin")) return;
    const nav = document.getElementById("nav");
    if (nav) nav.insertAdjacentHTML("beforeend", '<button type="button" data-v="admin"><span class="ico">⚙</span>題庫後台</button>');
    const page = document.querySelector(".page");
    if (!page) return;
    page.insertAdjacentHTML("beforeend", '<section class="view" id="admin"><div class="head admin-head"><div><p class="eyebrow">OWNER WORKSPACE</p><h1>題庫後台</h1><p class="lead">只有你的帳號能匯入、更新、修改、刪除及發布公開題庫。</p></div></div><div id="adminStatus" class="admin-status"></div><div id="adminLegacy"></div><div class="admin-actions"><button type="button" class="primary" data-admin-action="import">匯入 PDF 題目</button><button type="button" class="secondary" data-admin-action="new">建立／圖片辨識單題</button><button type="button" class="secondary" data-admin-action="publish">立即同步上網站</button><button type="button" class="secondary" data-admin-action="reload">重新讀取網站題庫</button></div><div id="adminSummary" class="admin-summary"></div><div class="card"><div class="toolbar"><h2>管理題目</h2><span class="admin-hint">修改、刪除後會自動發布；失敗時保留此裝置草稿。</span></div><div class="srow"><input id="adminSearch" class="search" type="search" placeholder="搜尋題號、科目或題幹" aria-label="搜尋管理題目"></div><div id="adminQuestionList" class="admin-list"></div></div></section>');
  }

  function updateSignInLink() {
    const actions = document.querySelector(".top .actions");
    if (!actions) return;
    let link = document.getElementById("bankOwnerSignIn");
    if (state.isAdmin) { if (link) link.remove(); return; }
    if (!link) {
      link = document.createElement("a");
      link.id = "bankOwnerSignIn";
      link.className = "secondary";
      link.target = "_top";
      actions.appendChild(link);
    }
    if (state.authenticated) {
      link.href = "/signout-with-chatgpt?return_to=%2F";
      link.textContent = "非管理者 · 切換帳號";
      link.setAttribute("aria-label", "目前登入帳號沒有題庫後台權限，切換帳號");
    } else {
      link.href = "/signin-with-chatgpt?return_to=%2F";
      link.textContent = "管理者登入";
      link.setAttribute("aria-label", "使用網站擁有者的 ChatGPT 帳號登入");
    }
  }

  const baseView = view;
  view = function (name) {
    if ((name === "admin" || name === "import") && (!state.ready || !state.isAdmin)) {
      if (typeof toast === "function") toast("只有題庫管理者可使用此功能。");
      return;
    }
    const result = baseView.apply(this, arguments);
    if (name === "admin") {
      const crumb = document.getElementById("crumb");
      if (crumb) crumb.textContent = "題庫後台";
      renderAdmin();
    }
    return result;
  };

  const mutationSelector = [
    '#pdfImport', '#newQ', '#imageQ', '#emptyNew', '#saveQ', '#confirmImport',
    '#saveQuestionEdit', '#saveExamSetEdit', '#deleteConfirmAction', '#reliableDeleteConfirm',
    '[data-v="import"]', '[data-a="new"]', '[data-a="delete"]', '[data-na="gen"]',
    '[data-question-edit]', '[data-reliable-delete-question]', '[data-exam-edit]',
    '[data-exam-delete]', '[data-reliable-delete-exam]', '[data-option-image-pick]',
    '[data-option-image-remove]', '[data-explanation-remove-image]',
    '[data-option-media-action]',
  ].join(",");
  document.addEventListener("click", function (event) {
    if (!event.target.closest || !event.target.closest(mutationSelector)) return;
    if (state.ready && state.isAdmin) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (typeof toast === "function") toast("只有題庫管理者可新增或修改題目。");
  }, true);

  function renderAdminList() {
    const root = document.getElementById("adminQuestionList");
    if (!root || !state.isAdmin) return;
    const input = document.getElementById("adminSearch");
    const query = String(input && input.value || "").trim().toLowerCase();
    const matching = Q.filter((question) => {
      const text = [question.questionNumber, subjectOf(question), sourceOf(question), question.q].join(" ").toLowerCase();
      return !query || text.includes(query);
    });
    const ordered = matching.slice().sort((a, b) => {
      const s = subjectOf(a).localeCompare(subjectOf(b), "zh-Hant");
      if (s) return s;
      const y = Number(b.examYear || 0) - Number(a.examYear || 0);
      if (y) return y;
      const session = Number(b.examSession || 0) - Number(a.examSession || 0);
      return session || Number(a.questionNumber || 0) - Number(b.questionNumber || 0);
    });
    root.innerHTML = ordered.length ? ordered.slice(0, 150).map((question) => {
      const id = safeText(question.id);
      const number = safeText(question.questionNumber || "—");
      const title = safeText(String(question.q || "").slice(0, 125));
      return '<article class="admin-row"><div><b>第 ' + number + ' 題｜' + title + '</b><small>' + safeText(subjectOf(question)) + ' · ' + safeText(sourceOf(question)) + '</small></div><div class="admin-row-actions"><button type="button" class="secondary" data-admin-open="' + id + '">查看</button><button type="button" class="secondary" data-question-edit="' + id + '">修改</button><button type="button" class="danger" data-admin-delete="' + id + '">刪除</button></div></article>';
    }).join("") + (ordered.length > 150 ? '<p class="admin-hint">顯示前 150 題，請用搜尋縮小範圍（共 ' + ordered.length + ' 題）。</p>' : "") : '<p class="admin-hint">沒有符合的題目。</p>';
  }

  function renderAdmin() {
    if (!state.isAdmin) return;
    mountAdmin();
    const status = document.getElementById("adminStatus");
    if (status) {
      let message = state.loading ? "正在載入公開題庫…" : state.publishing ? "正在同步題目與圖片到網站…" : state.error ? state.error : state.dirty ? "此裝置有尚未發布的修改，正在準備同步。" : state.revision ? "網站題庫已同步。其他使用者重新開啟網站即可看到最新版。" : "網站尚未有公開題庫；可匯入或導入原有題目後發布。";
      status.textContent = message;
      status.className = "admin-status " + (state.error ? "error" : state.revision && !state.dirty && !state.publishing ? "ready" : "");
    }
    const legacy = document.getElementById("adminLegacy");
    if (legacy) {
      const pending = pendingLegacy();
      legacy.innerHTML = pending.length ? '<div class="admin-legacy"><b>找到 ' + pending.length + ' 題舊裝置／記憶模式題目</b><p>這些題目尚未進入公開題庫。確認後可合併，並由你發布給其他人使用。</p><button type="button" class="secondary" data-admin-action="migrate">合併舊題目並發布</button></div>' : "";
    }
    const summary = document.getElementById("adminSummary");
    if (summary) {
      const groups = new Set(Q.map((item) => subjectOf(item) + "|" + sourceOf(item)));
      const time = state.publishedAt ? new Date(state.publishedAt).toLocaleString("zh-TW") : "尚未發布";
      summary.innerHTML = '<div><small>公開題目</small><b>' + Q.length + ' 題</b></div><div><small>科目／年度梯次</small><b>' + groups.size + ' 組</b></div><div><small>上次發布</small><b style="font-size:14px">' + safeText(time) + '</b></div>';
    }
    renderAdminList();
  }

  function assetIds(value, found, seen) {
    if (!value || typeof value !== "object" || seen.has(value)) return found;
    seen.add(value);
    if (Array.isArray(value)) { value.forEach((item) => assetIds(item, found, seen)); return found; }
    Object.keys(value).forEach((key) => {
      const child = value[key];
      if (/assetId$/i.test(key) && typeof child === "string" && /^[A-Za-z0-9._-]{1,220}$/.test(child)) found.add(child);
      assetIds(child, found, seen);
    });
    return found;
  }
  async function localAsset(id) {
    const db = await getAssetDb();
    if (!db) return null;
    return new Promise((resolve) => {
      try {
        const request = db.transaction("assets", "readonly").objectStore("assets").get(id);
        request.onsuccess = () => resolve(request.result || null);
        request.onerror = () => resolve(null);
      } catch (_) { resolve(null); }
    });
  }
  async function cacheAsset(record) {
    const db = await getAssetDb();
    if (!db) return;
    await new Promise((resolve) => {
      try {
        const tx = db.transaction("assets", "readwrite");
        tx.objectStore("assets").put(record);
        tx.oncomplete = resolve;
        tx.onerror = resolve;
      } catch (_) { resolve(); }
    });
  }
  window.PhysioPublishedAssetRecord = function (id) {
    if (!id || !/^[A-Za-z0-9._-]{1,220}$/.test(id)) return Promise.resolve(null);
    if (state.remoteAssetPromises.has(id)) return state.remoteAssetPromises.get(id);
    const promise = fetch(assetPath + encodeURIComponent(id), { credentials: "same-origin", cache: "no-store" })
      .then(async (response) => {
        if (!response.ok) return null;
        const blob = await response.blob();
        let name = response.headers.get("x-bank-asset-name") || id;
        try { name = decodeURIComponent(name); } catch (_) {}
        const record = { id, name, type: blob.type, blob, createdAt: Date.now() };
        await cacheAsset(record);
        return record;
      }).catch(() => null).then((record) => {
        if (!record) state.remoteAssetPromises.delete(id);
        return record;
      });
    state.remoteAssetPromises.set(id, promise);
    return promise;
  };

  async function uploadAssets(questions) {
    const ids = Array.from(assetIds(questions, new Set(), new WeakSet()));
    const missing = [];
    for (let index = 0; index < ids.length; index += 4) {
      await Promise.all(ids.slice(index, index + 4).map(async (id) => {
        const path = assetPath + encodeURIComponent(id);
        const head = await fetch(path, { method: "HEAD", credentials: "same-origin", cache: "no-store" });
        if (head.ok) return;
        if (head.status !== 404) throw new Error("題圖同步檢查失敗，請重試。");
        const record = await localAsset(id);
        if (!record || !record.blob) { missing.push(id); return; }
        const response = await fetch(path, { method: "PUT", credentials: "same-origin", headers: { "content-type": record.type || record.blob.type || "application/octet-stream", "x-bank-asset-name": encodeURIComponent(record.name || id) }, body: record.blob });
        if (!response.ok) throw new Error(response.status === 403 ? "目前帳號沒有題圖發布權限。" : "題圖上傳失敗，請重試。");
      }));
    }
    return missing;
  }

  async function publish(force, allowEmpty) {
    if (!state.ready || !state.isAdmin || state.publishing) return;
    const questions = JSON.parse(JSON.stringify(Q));
    const fingerprint = JSON.stringify(questions);
    if (!force && fingerprint === state.publishedFingerprint) { state.dirty = false; renderAdmin(); return; }
    if (!questions.length && !allowEmpty) {
      state.error = "公開題庫不能自動清空；若確定要清空，請按「立即同步」並再次確認。";
      renderAdmin(); return;
    }
    state.publishing = true; state.error = ""; renderAdmin();
    try {
      const missing = await uploadAssets(questions);
      const response = await fetch(bankPath, { method: "PUT", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ questions, baseRevision: state.revision, allowEmpty: !!allowEmpty }) });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || "公開題庫同步失敗，請再試一次。");
      state.revision = result.revision;
      state.publishedAt = result.publishedAt;
      state.publishedFingerprint = fingerprint;
      state.dirty = JSON.stringify(Q) !== fingerprint;
      state.legacyQuestions = [];
      try { localStorage.removeItem(legacyKey); localStorage.setItem(migratedKey, "yes"); } catch (_) {}
      state.error = missing.length ? "題庫已發布，但有 " + missing.length + " 個舊附件不在此裝置或網站上，相關圖片需由原裝置重新上傳。" : "";
      if (typeof toast === "function") toast(missing.length ? "題庫已發布；部分舊圖片未找到。" : "公開題庫已同步上網站。");
    } catch (error) {
      state.dirty = true;
      state.error = error && error.message || "公開題庫同步失敗，修改仍保留在此裝置。";
      if (typeof toast === "function") toast(state.error);
    } finally {
      state.publishing = false;
      renderAdmin();
      if (state.dirty && !state.error) schedulePublish();
    }
  }
  function schedulePublish() {
    if (!state.ready || !state.isAdmin || state.error) return;
    clearTimeout(state.timer);
    state.timer = setTimeout(() => publish(false, false), 1200);
  }

  const baseSaveAll = saveAll;
  saveAll = function () {
    const preserveLegacyLocal = !state.revision && Q.length === 0 && state.legacyQuestions.length > 0;
    const previousLocal = preserveLegacyLocal ? localStorage.getItem("physio-custom-questions") : null;
    const result = baseSaveAll.apply(this, arguments);
    if (preserveLegacyLocal && previousLocal) {
      try { localStorage.setItem("physio-custom-questions", previousLocal); } catch (_) {}
    }
    if (state.ready && state.isAdmin && !state.applying) {
      const nextDirty = JSON.stringify(Q) !== state.publishedFingerprint;
      if (nextDirty || state.dirty) {
        state.dirty = nextDirty;
        if (state.dirty) { state.error = ""; schedulePublish(); }
        renderAdmin();
      }
    }
    return result;
  };

  async function loadBank(allowDiscard) {
    if (state.dirty && !allowDiscard) return;
    const hadBank = state.ready;
    state.loading = true; state.error = ""; renderAdmin();
    try {
      const [roleResponse, bankResponse] = await Promise.all([
        fetch("/api/admin/me", { credentials: "same-origin", cache: "no-store" }),
        fetch(bankPath, { credentials: "same-origin", cache: "no-store" }),
      ]);
      if (!roleResponse.ok || !bankResponse.ok) throw new Error("公開題庫暫時無法載入，請稍後重試。");
      const role = await roleResponse.json();
      const bank = await bankResponse.json();
      const questions = bank.snapshot && bank.snapshot.questions;
      if (questions != null && !Array.isArray(questions)) throw new Error("公開題庫格式不正確，已停止載入。");
      state.isAdmin = role.isAdmin === true;
      state.authenticated = role.authenticated === true;
      document.body.dataset.bankAccess = state.isAdmin ? "admin" : "reader";
      updateSignInLink();
      if (state.isAdmin) mountAdmin();
      else if (document.querySelector(".view.on")?.id === "admin" || document.querySelector(".view.on")?.id === "import") baseView("bank");
      if (state.isAdmin && !state.legacyChecked) {
        state.legacyChecked = true;
        fetch("/api/admin/legacy-bank", { credentials: "same-origin", cache: "no-store" })
          .then((response) => response.ok ? response.json() : { questions: [] })
          .then((result) => state.captureLegacyQuestions(result.questions || []))
          .catch(() => {});
      }
      if (state.ready && state.revision === (bank.revision || null)) return;
      state.applying = true;
      Q = Array.isArray(questions) ? questions : [];
      state.revision = bank.revision || null;
      state.publishedAt = bank.publishedAt || bank.snapshot?.publishedAt || null;
      state.dirty = false;
      st.id = null;
      st.ans = null;
      st.examKey = null;
      repaint();
      state.publishedFingerprint = JSON.stringify(Q);
      state.ready = true;
      state.applying = false;
      if (state.revision) {
        try { localStorage.setItem("physio-custom-questions", JSON.stringify(Q)); } catch (_) {}
      }
    } catch (error) {
      state.error = error && error.message || "公開題庫載入失敗。";
      state.applying = false;
      if (!hadBank) { state.ready = false; Q = []; repaint(); }
    } finally {
      state.loading = false;
      renderAdmin();
    }
  }

  document.addEventListener("click", function (event) {
    const action = event.target.closest && event.target.closest("[data-admin-action]");
    if (action) {
      event.preventDefault();
      if (!state.ready || !state.isAdmin) return;
      switch (action.dataset.adminAction) {
        case "import": view("import"); break;
        case "new": document.getElementById("newQ")?.click(); break;
        case "publish": {
          const allowEmpty = Q.length === 0 && window.confirm("確定要把網站公開題庫清空嗎？此操作會移除所有公開題目。");
          if (Q.length || allowEmpty) publish(true, allowEmpty);
          break;
        }
        case "reload":
          if (!state.dirty || window.confirm("此裝置有尚未同步的修改。確定放棄修改，改讀取網站版本嗎？")) {
            clearTimeout(state.timer); state.dirty = false; loadBank(true);
          }
          break;
        case "migrate": {
          const pending = pendingLegacy();
          if (!pending.length || !window.confirm("把 " + pending.length + " 題舊題目合併到公開題庫並同步上網站？")) break;
          Q = Q.concat(pending.map((item) => JSON.parse(JSON.stringify(item))));
          saveAll(); repaint(); renderAdmin();
          break;
        }
      }
      return;
    }
    const open = event.target.closest && event.target.closest("[data-admin-open]");
    if (open && state.isAdmin) {
      const question = Q.find((item) => String(item.id) === open.dataset.adminOpen);
      if (!question) return;
      st.sub = subjectOf(question); st.examKey = sourceOf(question);
      st.id = question.id; st.ans = null; view("bank"); renderBank();
      return;
    }
    const remove = event.target.closest && event.target.closest("[data-admin-delete]");
    if (remove && state.isAdmin) {
      event.preventDefault();
      const question = Q.find((item) => String(item.id) === remove.dataset.adminDelete);
      if (question && window.__physioReliableQuestionActions) window.__physioReliableQuestionActions.requestDelete("question", question.id, subjectOf(question));
    }
  });
  document.addEventListener("input", function (event) {
    if (event.target && event.target.id === "adminSearch") renderAdminList();
  });
  window.addEventListener("focus", () => { if (state.ready && !state.dirty && !state.publishing && !document.querySelector("#questioneditmodal.open,#examsetmodal.open,#qmodal.open")) loadBank(false); });
  window.addEventListener("online", () => { if (state.ready && !state.dirty && !state.publishing) loadBank(false); });
  loadBank(true);
})();
