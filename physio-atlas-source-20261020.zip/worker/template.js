const page = __INDEX_HTML__;
const parserPipeline = __PARSER_PIPELINE__;
const optionMedia = __OPTION_MEDIA__;
const adminClient = __ADMIN_CLIENT__;
const appManifest = __APP_MANIFEST__;
const appIcons = __APP_ICONS__;

const textHeaders = { "content-type": "text/plain; charset=utf-8", "cache-control": "no-store" };
const jsonHeaders = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" };

function json(value, status = 200) {
  return new Response(JSON.stringify(value), { status, headers: jsonHeaders });
}

function userIdFor(request) {
  const value = request.headers.get("oai-authenticated-user-id");
  return value && value.trim() ? value.trim() : "";
}

function isAdminRequest(request, env) {
  // The account ID in Sites metadata is not the Site-scoped visitor ID in this header.
  // Compare the platform-verified sign-in email to the configured owner instead.
  const ownerEmail = String(env?.ADMIN_OWNER_EMAIL || "").trim().toLowerCase();
  const visitorEmail = String(request.headers.get("oai-authenticated-user-email") || "").trim().toLowerCase();
  return !!userIdFor(request) && !!ownerEmail && visitorEmail === ownerEmail;
}

function memoryPrefix(userId) {
  return "memory/" + encodeURIComponent(userId);
}

function snapshotKey(userId) {
  return memoryPrefix(userId) + "/snapshot.json";
}

function assetKey(userId, assetId) {
  return memoryPrefix(userId) + "/assets/" + encodeURIComponent(assetId);
}

function validAssetId(assetId) {
  return /^[A-Za-z0-9._-]{1,220}$/.test(assetId);
}

function sharedBankKey() {
  return "published-bank/snapshot.json";
}

function sharedBankAssetKey(assetId) {
  return "published-bank/assets/" + encodeURIComponent(assetId);
}

function bankUnavailable(env) {
  return !env?.BUCKET;
}

function safeAssetNameHeader(value) {
  const source = String(value || "asset");
  try {
    return encodeURIComponent(decodeURIComponent(source));
  } catch {
    return encodeURIComponent(source);
  }
}

function memoryUnavailable(env) {
  return !env?.DB || !env?.BUCKET;
}

async function loadSnapshot(env, userId) {
  const row = await env.DB
    .prepare("SELECT snapshot_key, updated_at, revision FROM memory_profiles WHERE user_id = ?")
    .bind(userId)
    .first();
  if (!row) return { snapshot: null, updatedAt: null, revision: 0 };
  const object = await env.BUCKET.get(row.snapshot_key);
  if (!object) return { snapshot: null, updatedAt: row.updated_at, revision: row.revision || 0 };
  try {
    return { snapshot: JSON.parse(await object.text()), updatedAt: row.updated_at, revision: row.revision || 0 };
  } catch {
    return { snapshot: null, updatedAt: row.updated_at, revision: row.revision || 0 };
  }
}

async function handleMemory(request, env, userId) {
  if (memoryUnavailable(env)) return json({ error: "記憶模式暫時無法使用" }, 503);
  if (request.method === "GET") return json(await loadSnapshot(env, userId));
  if (request.method !== "PUT") return new Response("Method not allowed", { status: 405, headers: textHeaders });

  let payload;
  try {
    payload = await request.json();
  } catch {
    return json({ error: "同步資料格式無法讀取" }, 400);
  }
  if (!payload || typeof payload.snapshot !== "object" || Array.isArray(payload.snapshot)) {
    return json({ error: "同步資料格式不正確" }, 400);
  }
  const serialized = JSON.stringify(payload.snapshot);
  if (serialized.length > 20 * 1024 * 1024) return json({ error: "同步資料過大，請先分批整理筆記或附件" }, 413);

  const key = snapshotKey(userId);
  const updatedAt = new Date().toISOString();
  await env.BUCKET.put(key, serialized, { httpMetadata: { contentType: "application/json; charset=utf-8" } });
  await env.DB
    .prepare("INSERT INTO memory_profiles (user_id, snapshot_key, updated_at, revision) VALUES (?, ?, ?, 1) ON CONFLICT(user_id) DO UPDATE SET snapshot_key = excluded.snapshot_key, updated_at = excluded.updated_at, revision = memory_profiles.revision + 1")
    .bind(userId, key, updatedAt)
    .run();
  return json({ ok: true, updatedAt });
}

async function handleAsset(request, env, userId, encodedId) {
  if (memoryUnavailable(env)) return json({ error: "記憶模式暫時無法使用" }, 503);
  let assetId;
  try {
    assetId = decodeURIComponent(encodedId);
  } catch {
    return new Response("Not found", { status: 404, headers: textHeaders });
  }
  if (!validAssetId(assetId)) return new Response("Not found", { status: 404, headers: textHeaders });
  const key = assetKey(userId, assetId);
  if (request.method === "HEAD") {
    const object = await env.BUCKET.head(key);
    return new Response(null, { status: object ? 200 : 404, headers: object ? { "content-type": object.httpMetadata?.contentType || "application/octet-stream" } : textHeaders });
  }
  if (request.method === "GET") {
    const object = await env.BUCKET.get(key);
    if (!object) return new Response("Not found", { status: 404, headers: textHeaders });
    return new Response(object.body, {
      headers: {
        "content-type": object.httpMetadata?.contentType || "application/octet-stream",
        "x-memory-asset-name": safeAssetNameHeader(object.customMetadata?.name || assetId),
        "cache-control": "private, no-store",
      },
    });
  }
  if (request.method !== "PUT" || !request.body) return new Response("Method not allowed", { status: 405, headers: textHeaders });
  const name = safeAssetNameHeader(request.headers.get("x-memory-asset-name") || assetId);
  const contentType = request.headers.get("content-type") || "application/octet-stream";
  await env.BUCKET.put(key, request.body, {
    httpMetadata: { contentType },
    customMetadata: { name: name.slice(0, 255) },
  });
  return new Response(null, { status: 201, headers: { "cache-control": "no-store" } });
}

async function handleSharedBank(request, env) {
  if (bankUnavailable(env)) return json({ error: "題庫服務暫時無法使用" }, 503);
  if (request.method === "GET") {
    const object = await env.BUCKET.get(sharedBankKey());
    if (!object) return json({ snapshot: null, publishedAt: null, revision: null });
    try {
      const snapshot = JSON.parse(await object.text());
      if (!snapshot || !Array.isArray(snapshot.questions)) throw new Error("invalid bank snapshot");
      return json({ snapshot, publishedAt: snapshot.publishedAt || null, revision: snapshot.revision || null });
    } catch { return json({ error: "公開題庫資料無法讀取，請聯絡管理者" }, 500); }
  }
  if (request.method !== "PUT") return new Response("Method not allowed", { status: 405, headers: textHeaders });
  if (!isAdminRequest(request, env)) return json({ error: "只有管理者可以更新公開題庫" }, 403);
  let payload;
  try { payload = await request.json(); } catch { return json({ error: "題庫資料格式無法讀取" }, 400); }
  if (!payload || !Array.isArray(payload.questions)) return json({ error: "題庫資料格式不正確" }, 400);
  if (!payload.questions.length && payload.allowEmpty !== true) return json({ error: "不可意外發布空白題庫" }, 400);
  if (payload.questions.some((question) => !question || typeof question !== "object" || !question.id || typeof question.q !== "string" || !question.q.trim() || !Array.isArray(question.answers) || question.answers.length !== 4)) {
    return json({ error: "部分題目缺少題幹、題號或四個選項欄位" }, 400);
  }
  const previous = await env.BUCKET.get(sharedBankKey());
  let previousRevision = null;
  if (previous) {
    try { previousRevision = JSON.parse(await previous.text()).revision || null; }
    catch { return json({ error: "既有公開題庫資料無法讀取，已停止覆蓋" }, 500); }
  }
  if ((payload.baseRevision || null) !== previousRevision) return json({ error: "公開題庫已在其他裝置更新，請重新載入後再修改", revision: previousRevision }, 409);
  const snapshot = { version: 1, revision: crypto.randomUUID(), publishedAt: new Date().toISOString(), questions: payload.questions };
  const serialized = JSON.stringify(snapshot);
  if (serialized.length > 20 * 1024 * 1024) return json({ error: "公開題庫資料過大" }, 413);
  await env.BUCKET.put(sharedBankKey(), serialized, { httpMetadata: { contentType: "application/json; charset=utf-8" } });
  return json({ ok: true, revision: snapshot.revision, publishedAt: snapshot.publishedAt, questionCount: snapshot.questions.length });
}

async function handleSharedBankAsset(request, env, encodedId) {
  if (bankUnavailable(env)) return json({ error: "題庫服務暫時無法使用" }, 503);
  let assetId;
  try { assetId = decodeURIComponent(encodedId); } catch { return new Response("Not found", { status: 404, headers: textHeaders }); }
  if (!validAssetId(assetId)) return new Response("Not found", { status: 404, headers: textHeaders });
  const key = sharedBankAssetKey(assetId);
  if (request.method === "GET" || request.method === "HEAD") {
    const object = request.method === "HEAD" ? await env.BUCKET.head(key) : await env.BUCKET.get(key);
    if (!object) return new Response("Not found", { status: 404, headers: textHeaders });
    const headers = { "content-type": object.httpMetadata?.contentType || "application/octet-stream", "x-bank-asset-name": safeAssetNameHeader(object.customMetadata?.name || assetId), "cache-control": "no-store" };
    return request.method === "HEAD" ? new Response(null, { status: 200, headers }) : new Response(object.body, { headers });
  }
  if (request.method !== "PUT" || !request.body) return new Response("Method not allowed", { status: 405, headers: textHeaders });
  if (!isAdminRequest(request, env)) return json({ error: "只有管理者可以更新公開題庫圖片" }, 403);
  const name = safeAssetNameHeader(request.headers.get("x-bank-asset-name") || assetId);
  const contentType = request.headers.get("content-type") || "application/octet-stream";
  await env.BUCKET.put(key, request.body, { httpMetadata: { contentType }, customMetadata: { name: name.slice(0, 255) } });
  return new Response(null, { status: 201, headers: { "cache-control": "no-store" } });
}

async function handleApi(request, env) {
  const path = new URL(request.url).pathname;
  try {
    if (path === "/api/admin/me") return json({ authenticated: !!userIdFor(request), isAdmin: isAdminRequest(request, env) });
    if (path === "/api/admin/legacy-bank") {
      if (request.method !== "GET") return new Response("Method not allowed", { status: 405, headers: textHeaders });
      if (!isAdminRequest(request, env)) return json({ error: "只有管理者可以讀取舊題庫" }, 403);
      if (memoryUnavailable(env)) return json({ error: "舊題庫暫時無法讀取" }, 503);
      const legacy = await loadSnapshot(env, userIdFor(request));
      return json({ questions: Array.isArray(legacy.snapshot?.questions) ? legacy.snapshot.questions : [] });
    }
    if (path === "/api/bank") return await handleSharedBank(request, env);
    const bankAssetPrefix = "/api/bank/assets/";
    if (path.startsWith(bankAssetPrefix) && !path.slice(bankAssetPrefix.length).includes("/")) return await handleSharedBankAsset(request, env, path.slice(bankAssetPrefix.length));
    const userId = userIdFor(request);
    if (!userId) return json({ error: "請以同一個 ChatGPT 帳號登入後再使用記憶模式" }, 401);
    if (path === "/api/memory") return await handleMemory(request, env, userId);
    const prefix = "/api/memory/assets/";
    if (path.startsWith(prefix) && !path.slice(prefix.length).includes("/")) return await handleAsset(request, env, userId, path.slice(prefix.length));
    return new Response("Not found", { status: 404, headers: textHeaders });
  } catch (error) {
    console.error("site-api-error", error instanceof Error ? error.message : "unknown");
    return json({ error: "服務暫時無法使用，請稍後再試" }, 500);
  }
}
export default {
  async fetch(request, env, ctx) {
    void ctx;
    const path = new URL(request.url).pathname;
    if (path === "/api/memory" || path.startsWith("/api/memory/") || path === "/api/bank" || path.startsWith("/api/bank/") || path === "/api/admin/me" || path === "/api/admin/legacy-bank") return handleApi(request, env);
    if (path === "/" || path === "/index.html") {
      return new Response(page, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
    }
    if (path === "/parser-pipeline.js") {
      return new Response(parserPipeline, { headers: { "content-type": "application/javascript; charset=utf-8", "cache-control": "no-store" } });
    }
    if (path === "/option-media.js") {
      return new Response(optionMedia, { headers: { "content-type": "application/javascript; charset=utf-8", "cache-control": "no-store" } });
    }
    if (path === "/admin-client.js") {
      return new Response(adminClient, { headers: { "content-type": "application/javascript; charset=utf-8", "cache-control": "no-store" } });
    }
    if (path === "/site.webmanifest") {
      return new Response(appManifest, { headers: { "content-type": "application/manifest+json; charset=utf-8", "cache-control": "no-store" } });
    }
    if (Object.hasOwn(appIcons, path)) {
      const bytes = Uint8Array.from(atob(appIcons[path]), (character) => character.charCodeAt(0));
      return new Response(bytes, { headers: { "content-type": "image/png", "cache-control": "public, max-age=3600" } });
    }
    return new Response("Not found", { status: 404, headers: textHeaders });
  },
};
