CREATE TABLE IF NOT EXISTS memory_profiles (
  user_id TEXT PRIMARY KEY NOT NULL,
  snapshot_key TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_memory_profiles_updated_at
ON memory_profiles(updated_at);

PRAGMA optimize;
